#!/usr/bin/env node
import { execSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const changelogPath = resolve(__dirname, "../client/src/data/changelog.ts");

const existingContent = readFileSync(changelogPath, "utf-8");
const dateMatch = existingContent.match(/date:\s*"(\d{4}-\d{2}-\d{2})"/);
const lastDate = dateMatch ? dateMatch[1] : "1970-01-01";

const sinceDate = new Date(lastDate);
sinceDate.setDate(sinceDate.getDate() + 1);
const since = sinceDate.toISOString().slice(0, 10);

const log = execSync(
  `git log --after="${since}T00:00:00" --format="%ad|%s" --date=short`,
  { encoding: "utf-8" },
).trim();

if (!log) {
  console.log("No new commits since", lastDate);
  process.exit(0);
}

const prefixMap = {
  feat: "追加",
  fix: "修正",
  refactor: "改善",
  perf: "最適化",
};

const lines = log.split("\n").filter(Boolean);
const byDate = new Map();

for (const line of lines) {
  const [date, ...rest] = line.split("|");
  const message = rest.join("|");
  if (/^(docs|chore|ci|test|Checkpoint|Merge pull request)/.test(message)) continue;
  const match = message.match(/^(feat|fix|refactor|perf)(?:\(.*?\))?:\s*(.+)/);
  const label = match ? `${prefixMap[match[1]] || "更新"}: ${match[2]}` : message;
  if (!byDate.has(date)) byDate.set(date, []);
  byDate.get(date).push(label);
}

if (byDate.size === 0) {
  console.log("No meaningful commits to add.");
  process.exit(0);
}

const newEntries = [...byDate.entries()]
  .sort((a, b) => b[0].localeCompare(a[0]))
  .map(([date, changes]) => ({
    date,
    title: `${date} の更新`,
    changes,
  }));

const insertMarker = "export const changelog: ChangelogEntry[] = [";
const insertIndex = existingContent.indexOf(insertMarker);
if (insertIndex === -1) {
  console.error("Could not find insertion point in changelog.ts");
  process.exit(1);
}

const insertPos = insertIndex + insertMarker.length;
const newEntriesStr = newEntries
  .map(
    (entry) =>
      `\n  {\n    date: "${entry.date}",\n    title: "${entry.title}",\n    changes: [\n${entry.changes.map((c) => `      "${c.replace(/"/g, '\\"')}",`).join("\n")}\n    ],\n  },`,
  )
  .join("");

const updated = existingContent.slice(0, insertPos) + newEntriesStr + existingContent.slice(insertPos);
writeFileSync(changelogPath, updated);
console.log(`Added ${newEntries.length} new changelog entries.`);
