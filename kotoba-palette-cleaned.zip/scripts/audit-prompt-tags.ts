import { readdirSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { categories as baseCategories } from "../client/src/lib/prompt-data";
import { mergeExtraCategories } from "../client/src/lib/prompt-data-merge";

const libDir = resolve(process.cwd(), "client/src/lib");
const files = readdirSync(libDir)
  .filter((name) =>
    name === "prompt-data.ts" ||
    name === "prompt-data-recipes.ts" ||
    name.startsWith("prompt-data-extra-")
  )
  .filter((name) => name.endsWith(".ts") && !name.endsWith(".test.ts"))
  .sort();

type Entry = {
  file: string;
  sourceCategoryHint: string | null;
  optionIdPrefixHint: string | null;
  en: string;
  ja: string;
};

const entries: Entry[] = [];
const pairPattern = /\[\s*"((?:[^"\\]|\\.)*)"\s*,\s*"((?:[^"\\]|\\.)*)"\s*\]/g;
const wordsMarkerPattern = /words\(\s*"([^"]+)"/g;
// PromptCategory objects in this repository consistently declare a literal id
// immediately before label. This intentionally ignores PromptOption ids and
// the first argument of words(), which may only be an option-id prefix.
const sourceCategoryMarkerPattern = /\bid\s*:\s*"([^"]+)"\s*,\s*label\s*:/g;

for (const file of files) {
  const source = readFileSync(resolve(libDir, file), "utf8");
  const optionIdPrefixMarkers = [...source.matchAll(wordsMarkerPattern)].map((match) => ({
    index: match.index ?? 0,
    value: match[1],
  }));
  const sourceCategoryMarkers = [...source.matchAll(sourceCategoryMarkerPattern)].map((match) => ({
    index: match.index ?? 0,
    value: match[1],
  }));

  let optionIdPrefixMarkerIndex = 0;
  let sourceCategoryMarkerIndex = 0;
  let currentOptionIdPrefix: string | null = null;
  let currentSourceCategory: string | null = null;

  for (const match of source.matchAll(pairPattern)) {
    const matchIndex = match.index ?? 0;
    while (
      optionIdPrefixMarkerIndex < optionIdPrefixMarkers.length &&
      optionIdPrefixMarkers[optionIdPrefixMarkerIndex].index < matchIndex
    ) {
      currentOptionIdPrefix = optionIdPrefixMarkers[optionIdPrefixMarkerIndex].value;
      optionIdPrefixMarkerIndex += 1;
    }
    while (
      sourceCategoryMarkerIndex < sourceCategoryMarkers.length &&
      sourceCategoryMarkers[sourceCategoryMarkerIndex].index < matchIndex
    ) {
      currentSourceCategory = sourceCategoryMarkers[sourceCategoryMarkerIndex].value;
      sourceCategoryMarkerIndex += 1;
    }

    const [, en, ja] = match;
    entries.push({
      file,
      sourceCategoryHint: currentSourceCategory,
      optionIdPrefixHint: currentOptionIdPrefix,
      en,
      ja,
    });
  }
}

const runtimeNorm = (value: string) => value.toLowerCase().replace(/\s+/g, "");
const exactEnglishNorm = (value: string) => value.normalize("NFKC").toLowerCase().trim();
const looseNorm = (value: string) => value.normalize("NFKC").toLowerCase().replace(/[^a-z0-9]+/g, "");
const meaningNorm = (value: string) => value.normalize("NFKC").trim();

function groupBy<T>(items: T[], keyOf: (item: T) => string) {
  const groups = new Map<string, T[]>();
  for (const item of items) {
    const key = keyOf(item);
    if (!key) continue;
    const bucket = groups.get(key) ?? [];
    bucket.push(item);
    groups.set(key, bucket);
  }
  return groups;
}

const runtimeDuplicates = [...groupBy(entries, (entry) => runtimeNorm(entry.en)).entries()]
  .filter(([, items]) => items.length > 1)
  .map(([key, items]) => ({ key, items }));

const runtimeMeaningConflicts = runtimeDuplicates.filter(
  ({ items }) => new Set(items.map((item) => meaningNorm(item.ja))).size > 1,
);
const runtimeSameMeaningDuplicates = runtimeDuplicates.filter(
  ({ items }) => new Set(items.map((item) => meaningNorm(item.ja))).size === 1,
);
const runtimeEnglishFormCollisions = runtimeDuplicates.filter(
  ({ items }) => new Set(items.map((item) => exactEnglishNorm(item.en))).size > 1,
);
const runtimeEnglishFormSemanticCollisions = runtimeEnglishFormCollisions.filter(
  ({ items }) => new Set(items.map((item) => meaningNorm(item.ja))).size > 1,
);
const exactEnglishMeaningConflicts = runtimeMeaningConflicts.filter(
  ({ items }) => new Set(items.map((item) => exactEnglishNorm(item.en))).size === 1,
);

const mergedCategories = mergeExtraCategories(baseCategories);
const runtimeCategoryCounts = mergedCategories.map((category) => ({
  id: category.id,
  mode: category.mode ?? "sfw",
  count: category.options.length,
}));
const runtimeMergedOptions = mergedCategories.flatMap((category) =>
  category.options.map((option) => ({ categoryId: category.id, option })),
);
const runtimeSfwOptions = mergedCategories
  .filter((category) => category.mode !== "nsfw")
  .flatMap((category) => category.options);
const runtimeNsfwOptions = mergedCategories
  .filter((category) => category.mode === "nsfw")
  .flatMap((category) => category.options);

function runtimeWinnerForKey(key: string) {
  const winner = runtimeMergedOptions.find(({ option }) => runtimeNorm(option.en) === key);
  if (!winner) return null;
  return {
    categoryId: winner.categoryId,
    optionId: winner.option.id,
    en: winner.option.en,
    ja: winner.option.ja,
  };
}

const exactEnglishMeaningConflictSummary = exactEnglishMeaningConflicts.map(({ key, items }) => {
  const sourceCategoryHints = [
    ...new Set(items.map((item) => item.sourceCategoryHint).filter((value): value is string => Boolean(value))),
  ];
  const optionIdPrefixHints = [
    ...new Set(items.map((item) => item.optionIdPrefixHint).filter((value): value is string => Boolean(value))),
  ];

  return {
    key,
    en: items[0].en.trim(),
    ja: [...new Set(items.map((item) => meaningNorm(item.ja)))],
    // Keep categoryHints for report compatibility, but its meaning is now the
    // actual source PromptCategory id rather than words()'s option-id prefix.
    categoryHints: sourceCategoryHints,
    sourceCategoryHints,
    optionIdPrefixHints,
    files: [...new Set(items.map((item) => item.file))],
    runtimeWinner: runtimeWinnerForKey(key),
  };
});

// This is intentionally a review queue, not an automatic semantic verdict.
// Same English text + different Japanese meanings + different source category
// ids is where hidden polysemy is most likely. Option-id prefixes do not decide
// whether a candidate is cross-category.
const crossCategoryMeaningReviewCandidates = exactEnglishMeaningConflictSummary.filter(
  (candidate) => candidate.sourceCategoryHints.length > 1,
);
const sameCategoryTranslationReviewCandidates = exactEnglishMeaningConflictSummary.filter(
  (candidate) => candidate.sourceCategoryHints.length <= 1,
);

const looseCandidates = [...groupBy(entries, (entry) => looseNorm(entry.en)).entries()]
  .filter(([, items]) => items.length > 1)
  .filter(([, items]) => new Set(items.map((item) => runtimeNorm(item.en))).size > 1)
  .map(([key, items]) => ({ key, items }));

const sameJapaneseCandidates = [...groupBy(entries, (entry) => meaningNorm(entry.ja)).entries()]
  .filter(([, items]) => new Set(items.map((item) => runtimeNorm(item.en))).size > 1)
  .map(([ja, items]) => ({ ja, items }));

const whitespaceCandidates = entries.filter(
  (entry) => entry.en !== entry.en.trim() || entry.ja !== entry.ja.trim(),
);

const sourceCategoryVsOptionIdPrefixDifferences = entries
  .filter((entry) =>
    entry.sourceCategoryHint &&
    entry.optionIdPrefixHint &&
    entry.sourceCategoryHint !== entry.optionIdPrefixHint
  )
  .map((entry) => ({
    file: entry.file,
    en: entry.en,
    sourceCategoryHint: entry.sourceCategoryHint,
    optionIdPrefixHint: entry.optionIdPrefixHint,
  }));

console.log(JSON.stringify({
  generatedAt: new Date().toISOString(),
  policy: "REPORT_ONLY_NO_MUTATION",
  scannedFiles: files.length,
  extractedPairs: entries.length,
  runtimeMergedCategoryCount: mergedCategories.length,
  runtimeMergedOptionCount: runtimeMergedOptions.length,
  runtimeSfwOptionCount: runtimeSfwOptions.length,
  runtimeNsfwOptionCount: runtimeNsfwOptions.length,
  runtimeNegativeOptionCount: runtimeMergedOptions.filter(({ option }) => option.negative).length,
  runtimeNormalizedDuplicateGroups: runtimeDuplicates.length,
  runtimeSameMeaningDuplicateGroups: runtimeSameMeaningDuplicates.length,
  runtimeMeaningConflictGroups: runtimeMeaningConflicts.length,
  exactEnglishMeaningConflictGroups: exactEnglishMeaningConflicts.length,
  crossCategoryMeaningReviewCandidateGroups: crossCategoryMeaningReviewCandidates.length,
  sameCategoryTranslationReviewCandidateGroups: sameCategoryTranslationReviewCandidates.length,
  runtimeEnglishFormCollisionGroups: runtimeEnglishFormCollisions.length,
  runtimeEnglishFormSemanticCollisionGroups: runtimeEnglishFormSemanticCollisions.length,
  looseNormalizationCandidateGroups: looseCandidates.length,
  sameJapaneseDifferentEnglishGroups: sameJapaneseCandidates.length,
  leadingOrTrailingWhitespaceCandidates: whitespaceCandidates.length,
  sourceCategoryVsOptionIdPrefixDifferenceCount: sourceCategoryVsOptionIdPrefixDifferences.length,
  crossCategoryMeaningReviewCandidates,
  sameCategoryTranslationReviewCandidates,
  exactEnglishMeaningConflictSummary,
  runtimeEnglishFormSemanticCollisions,
  runtimeMeaningConflicts,
  runtimeSameMeaningDuplicates,
  looseCandidates,
  sameJapaneseCandidates,
  whitespaceCandidates,
  sourceCategoryVsOptionIdPrefixDifferences,
  runtimeCategoryCounts,
}, null, 2));
