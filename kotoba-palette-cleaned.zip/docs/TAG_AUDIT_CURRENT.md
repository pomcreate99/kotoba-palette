# ことばパレット タグ監査 — Current Checkpoint

更新日: 2026-08-25 JST

この文書は、過去の監査経緯を残した `TAG_AUDIT_RESULTS.md` / `TAG_AUDIT_PHASE2.md` を全置換せず、**今後の作業で使う最新の確定基準だけ**をまとめる。

## Checkpointのコードbase

- checkpoint作成時のランタイム影響main: `0747ccbad805330415e38e16d7cd5f2442e9733d`（style MR merge。keyword ingest merge後に更新）
- GitLab Pages: runtime/build入力が変わったmain pushだけ実行する節約構成へ変更済み（MR !24）

この文書自身のmergeなど、runtimeへ影響しないdocs-only commitでmain SHAが進んでも、下記runtime基準値は変わらない。

## 現在のruntime基準値

現行mainの回帰テストで固定する基準値。style MR（5,029）の上に Danbooru/X keyword ingest +339 を加算した値。

- runtime tags: 5,368
- SFW: 4,070
- NSFW: 1,298
- Negative: 59
- audited category aliases: 74

内訳:

- MR !42 furry: 4,952 / SFW 3,692 / NSFW 1,260 / Negative 12
- 2026-08-25 style MR (`0747ccba`): 5,029 / SFW 3,769 / NSFW 1,260 / Negative 12（SFW +77）
- 本keyword ingest: 5,368 / SFW 4,070 / NSFW 1,298 / Negative 59（SFW +254 / NSFW +38 / Negative +47）
- Negative 12 → 59 のため `avoid` に dictionarySafeTaxonomy を追加
- `count.gendered` に 3girls / 3boys / multiple girls / multiple boys / 1other / 2others / 3others、`count.focus` を追加

意図しないruntime件数減少があればmerge・公開を停止する。

## 最新のフルtag audit指標

下記は MR !42 のfinal tag audit `#16057551929`（pipeline `#2783889724`）実測値。style MR と本keyword ingestでは専用フルaudit jobの数値を更新していない。runtime基準値とは混同しない。

- scanned files: 43
- extracted EN/JA pairs: 5,739
- runtime categories: 87
- runtime tags: 4,952
- SFW: 3,692
- NSFW: 1,260
- Negative: 12
- normalization duplicate groups: 757
- same-meaning duplicate groups: 595
- meaning-conflict groups: 162
- exact-English meaning-conflict groups: 140
- cross-category review groups: 117
- same-category translation review groups: 23
- English-form collision groups: 91
- English-form semantic collision groups: 22
- loose-normalization candidates: 8
- same-Japanese/different-English groups: 192
- leading/trailing-whitespace candidates: 2
- source category / option ID prefix differences: 63 entries

MR !38からMR !42までの指標変動は、furry extra ファイル追加と `leopard` / `wool` のSEMANTIC_DISTINCT共存に対応するもの。

フル監査の詳細指標を更新するときは、runtime基準値と混同せず、専用audit jobの実測値で更新する。

## 監査ロジックの重要な補正

MR !23で、監査スクリプトのカテゴリ判定を修正した。

旧仕様では `words("...")` の第1引数を `categoryHint` としていたが、これは実PromptCategory IDではなくoption ID prefixの場合がある。

現在は以下を分離して出力する。

- `sourceCategoryHint`: PromptCategoryの実sourceカテゴリID
- `optionIdPrefixHint`: `words()` がoption ID生成に使うprefix
- `categoryHints`: 互換性維持のため残すが、内容は `sourceCategoryHint`

cross-category判定は `sourceCategoryHint` のみを使う。

この補正により、自動監査キューは以下へ変化した。

- cross-category: 116 → 115
- same-category translation: 22 → 23

これはタグ消失ではなく、`nipple clamps` が誤ってcross-category扱いされていた分類補正によるもの。

## 完了済みのタグ整合性対応

### Positive / Negative polarity

同じEnglishでもPositive / Negativeを別dedupe identityとして保持する。Negative `blur`, `cropped`, `noise`, `frame` は復元済み。Negative基準値は12（keyword ingest後のruntime Negativeは59。追加分は `avoid` の `negative: true`）。

### `SEMANTIC_DISTINCT` 35件

同じEnglishでもカテゴリ意味が異なる35件は、semantic identityを分離して共存できるよう対応済み。

代表例:
- `glass`: グラス / ガラス
- `ripped`: 筋肉が浮き出た / 裂け
- `back`: 背中 / 背面
- `pastel`: 色調 / 画材 / style
- `warm`: 暖色 / 温かい雰囲気
- `mouse`: 鼠 / PCマウス
- `leopard`: ヒョウ（animals） / レオパード柄（patterns）
- `wool`: ウール素材（material） / 羊毛質（creature-features）

### `CATEGORY_ALIAS`

runtimeタグは複製せず、canonical option IDを複数カテゴリから参照する。現行回帰でにaudited alias 74件を固定している。

代表例:
- `temple`: setting / architecture
- `watercolor`: medium / style
- `socks`: footwear / adult-wardrobe
- `phoenix`: animals / species
- `leather`: material / adult-wardrobe
- `lamp`: object / scenery

お気に入り・履歴・選択・prompt出力はcanonical IDを再利用する。

`balcony` は元のPhase 2 CATEGORY_ALIAS群には追加せず、MR !35のlegacy typo correction referenceとして別管理する。

### `TRANSLATION_VARIANT` 2件

MR !22で対応済み。

- `nipple clamps`: `ニップルクランプ`をcanonical表示として維持し、`乳首クリップ`を日本語検索aliasとして保持。実runtimeカテゴリは `adult-wardrobe` のみ。`adult-goods` はoption ID prefixでありカテゴリではない。
- `mandarin collar`: `スタンドカラー`をcanonical表示として維持し、`マンダリンカラー`系を日本語検索aliasとして保持。`clothing-detail` / `clothing` の両カテゴリから同じcanonical IDへ到達できる。

runtime occurrenceはいずれも1件のまま。

### `leaves` / `petals`

MR !26で、既存IDを維持したまま意味差を復元済み。

- nature `leaves` = `葉`
- optics `falling leaves` = `葉舞い`（ID `optics-leaves` 維持）
- nature `petals` = `花びら`
- optics `falling petals` = `花びら舞い`（ID `optics-petals` 維持）

### `yoga` / `private` / `mansion`

MR !28で、source文脈と外部根拠が揃った3語を既存ID維持のruntime補正で分離済み。

- style `yoga / 洋画風` → `western-style painting`（ID `style-yoga` 維持）
- adult-scene `private / 私室` → `private room`（ID `adult-scene-private` 維持）
- architecture `mansion / 洋館` → `western-style house`（ID `architecture-mansion` 維持）

元の別意味も維持している。

- pose `yoga` = `ヨガポーズ`
- adult-mood `private` = `私的`
- setting `mansion` = `豪邸`

### `leather`

現行mainでは意味差を以下で固定済み。

- material `leather` = `革`
- patterns `leather texture` = `レザー柄`（ID `patterns-leather` 維持）
- adult-wardrobeからはCATEGORY_ALIASとしてcanonical `leather`へ参照可能

回帰テストで `leather` runtime occurrence 1件、`leather texture` runtime occurrence 1件を固定している。

### `balony` → `balcony`

MR !35で、単純置換による保存データ破損を避けながら修正済み。

- source `setting-balony / balony / バルコニー` はruntime integrityで `balcony`へ補正
- global dedupe後は既存canonical `interior-balcony` 1件へ統合
- setting / architecture / interior の辞書から同じcanonical `interior-balcony`へ到達可能
- runtime `balony`: 0件
- runtime `balcony`: 1件

旧localStorage互換のため、UI state読込前に共通migrationを実行する。

- favorites: `setting-balony` → `interior-balcony`
- history: option ID / Englishをcanonicalへ移行し、prompt文字列を再生成
- V2 custom presets: option ID / Englishをcanonicalへ移行
- migrationは冪等
- JSONが壊れている場合は削除せずそのまま保持

最終pipeline `#2783275651`:
- verify SUCCESS
- `pnpm check` SUCCESS
- Vitest 40/40 SUCCESS
- build SUCCESS
- tag_audit SUCCESS

main Pages `#2783277197`: SUCCESS。

### `strawberry blonde`

2026-08-24の再調査で `VALID_GENERIC_PROMPT` と判定。runtimeタグ本文は変更しない。

根拠:
- 標準英語として定着した髪色名 `strawberry blonde` であり、日本語 `ストロベリーブロンド` と意味が一致
- PixAIの2026年実生成promptで `strawberry blonde` / `strawberry-blonde` の使用例を複数確認
- NovelAI公式資料でV4/V4.5がタグだけでなく自然言語promptをサポートし、V4.5では自然言語理解を明示的に強化していることを確認

結論:
- prompt単語帳に置く一般英語表現としては有効
- `hair-color` の暖色分類も妥当
- 特定モデルの「既知タグとして登録されている」とは断定しない
- model-native tag status未確認だけを理由にruntimeから削除・置換しない

### `lamp`

MR !38で監査キューの最後の主要未確定項目を解決済み。

source:
- object `lamp` = `ランプ`
- scenery `lamp` = `スタンドライト`

調査結果では、日本語の「スタンドライト」は特定の `floor lamp` / `desk lamp` / `table lamp` だけへ一意に限定できる表現ではなく、置き型照明を広く指し得る。AI画像生成側でもbare `lamp` と具体的な `desk lamp` 等は必要に応じて使い分けられるため、scenery側を推測で特定器具へ書き換えない。

実装:
- canonical runtime optionは既存 `object-lamp / lamp / ランプ`
- sceneryからも同じ `object-lamp` IDへCATEGORY_ALIASとして到達
- 旧scenery日本語 `スタンドライト` は検索aliasとして保持
- runtime `lamp`: 1件のまま
- audited CATEGORY_ALIAS: 73 → 74
- raw prompt-data / option ID / UI / CSSは変更なし

最終pipeline `#2783299437`:
- `pnpm check`: SUCCESS
- Vitest: 40/40 SUCCESS
- build: SUCCESS
- tag_audit: SUCCESS
- runtime: 4,756 / SFW 3,496 / NSFW 1,260 / Negative 12
- その他の監査指標は不変

main Pages `#2783302385`: SUCCESS。

### furry / kemonoタグと adult-usable count

MR !42で、Prompt Atlas SFW furry/kemono（2026-08-19）と leftover X SFW（2026-08-17）、および danbooru式 `1girl` / `1boy` / `2girls` / `2boys` をSFW countとして追加済み。

実装:
- 新規extra `prompt-data-extra-grok-20260824-furry.ts` を `prompt-data-merge.ts` へ登録
- leftover X: `full bangs`, `empty hands`, `delicate pose`, `white gloves`, `silver earrings`
- SEMANTIC_DISTINCT +2: `leopard`（animals vs patterns）、`wool`（material vs creature-features）
- CATEGORY_ALIAS +0, TRANSLATION_VARIANT +0
- youth `boy` / `girl`（男の子 / 女の子, audience:youth）は再分類しない
- `cat boy` ja = 猫男子（猫少年にしない）
- `1girl` / `1boy` ja = 女性1人 / 男性1人
- ID変更なし / localStorage migrationなし / UI・CSS変更なし

runtime:
- 4,756 → 4,952（SFW 3,496 → 3,692 / NSFW 1,260 / Negative 12）
- デルタ +196 SFW（furry extra 191 + leftover X 5）

辞書小分類:
- `count.gendered` を先頭
- `species.furry` を先頭
- `creature-features` に countershade / pattern-markings / fur-texture / fur-color / body-color / anatomy-furry を先行し、general-markings を末尾

最終pipeline `#2783889724`:
- `pnpm check`: SUCCESS
- Vitest: 49/49 SUCCESS
- build: SUCCESS
- tag_audit `#16057551929`: SUCCESS

main Pages `#2783892646`: SUCCESS。

未追加（既存または同義）:
- bunny animal ears / fluffy tail
- rim lighting（rimlightの同義）
- half closed eyes（halfclosedの同義）
- gray fur（grey fur 済追加）

### 2026-08-25 style / coloring ingest

style MR（`feat/add-prompt-tags-20260825-style` → main `0747ccba`）で Prompt Atlas SFW 画風・塗り・媒体タグを追加済み。

- 新規extra `prompt-data-extra-grok-20260825-style.ts`
- runtime 4,952 → 5,029（SFW 3,692 → 3,769 / NSFW 1,260 / Negative 12）
- デルタ +77 SFW
- ID変更なし / localStorage migrationなし / UI・CSS変更なし / NSFW削除なし

### 2026-08-25 Danbooru / X keyword ingest

横断収集ユニーク 1,046件 + X調査シートから、既存runtime・同義・安全スキップを除いた 339件を追加する。

実装:
- 新規extra 3ファイルを `prompt-data-merge.ts` へ登録
  - `prompt-data-extra-grok-20260825-keywords.ts`（part A: quality〜expression）
  - `prompt-data-extra-grok-20260825-keywords-b.ts`（part B: pose〜world）
  - `prompt-data-extra-grok-20260825-keywords-c.ts`（part C: adult-* + avoid）
- 日本語ラベルを新規付与（シートは英語のみ）
- NSFWカテゴリは `mode: "nsfw"`、avoid は `negative: true`
- `hair bow` / `hair ornament` / `halo` / `witch hat` は headwear
- `yuri` / `yaoi` は world SFW
- `futanari` は adult-body NSFW
- `crossdressing` は clothing SFW
- `covering breasts` は adult-pose NSFW（ownershipは adult-pose から breasts を奪わない）
- `indoor` / `outdoor` は既存 `indoors` / `outdoors` と SEMANTIC_DISTINCT 扱い（Danbooru表記）
- CATEGORY_ALIAS +0, TRANSLATION_VARIANT +0, ID変更なし / localStorage migrationなし / UI・CSS変更なし
- NSFW既存タグは削除していない

runtime:
- 5,029 → 5,368（SFW 3,769 → 4,070 / NSFW 1,260 → 1,298 / Negative 12 → 59）
- デルタ +339（SFW +254 / NSFW +38 / Negative +47）

辞書小分類:
- `avoid` に quality / displeasing / anatomy / artifacts（13件超になったため必須）
- `count.gendered` 拡張と `count.focus`
- quality semantic に grade/resolution/render/era
- expression positive/negative 拡張
- world genre / dystopia / utopia / gothic fantasy / magical girl
- adult-pose sexual / restraint 拡張

追加の代表例:
- quality: `score_9`, `great quality`, `sensitive`, `year 2024`〜`year 2026`
- count: `3girls`, `3boys`, `male focus`
- eye-shape: `tsurime`, `tareme`
- expression: `doyagao`
- clothing: `hawaiian shirt`（X調査）, `classic lolita`（ファッション）
- world: `yuri`, `yaoi`, `slice of life`
- NSFW: `futanari`, `penis`, `sex`

未追加（安全・同義・既存）:
- loli / shota / toddler / kid / teen / young / trap / shemale
- nsfw / explicit（SFW品質辞書を汚染するため）
- smile（既存 smiling）
- spread legs（既存 legs spread）
- gothic lolita / sweet lolita / cheerleader 等の既存ファッション
- masterpiece / best quality / 1girl / 8k / 4k 等の既存定番

## 辞書taxonomy監査 — MR !31〜!33

タグ本文の監査とは別に、V2単語帳で「どの小分類へ表示されるか」を全runtimeカテゴリへ対して三巡監査した。

### MR !31 — 意味ベースtaxonomyの全面導入

- 大規模カテゴリを意味ベースの専用taxonomyへ移行
- `coloring`: 影 / 線画 / 塗り / 仕上げ等を分離
- `eye-shape`: 形 / まぶた・まつ毛 / 視線 / 状態 / 特殊表現を分離
- quality / physique / skin / face-detail / headwear / creature-features / design / medium / mood / interior / scenery / lighting-detail / optics / adult系などを意味分類
- 12件以下のカテゴリは原則 `すべて` 1タブにして過剰分類を回避
- 辞書から漏れていた `eyes`, `pupils`, `adult-anatomy` を到達可能にした
- `recipe-style` はレシピ専用として辞書除外を維持

回帰:
- 全runtimeカテゴリが辞書から到達可能（recipe-style除外）
- 全optionが小分類へちょうど1回所属
- 大規模カテゴリが機械的なbasic/detail chunkへ落ちない

### MR !32 — 旧ID substring分類の排除

専用taxonomy外に残っていた大規模カテゴリもsafe taxonomyへ移行した。

- 意味判定にcategory/option IDを使わない
- `option.en`を正規化して判定
- 短語はtoken/prefix、複合語はphraseで判定
- 13件以上の全runtimeカテゴリは eye-color専用 / override / semantic / safe taxonomy のいずれかを必須化
- `woman` が `man` に誤一致するようなsubstring衝突を回帰で防止
- `composition` の背景演出混在、`adult-wardrobe` の成人向けグッズ混在を明示分類

最終verify: 35/35 tests SUCCESS、type check / build SUCCESS。

### MR !33 — 巨大混在カテゴリのOther偏重を改善

追加chunkが大量に混在していた以下4カテゴリを実データまで再精査した。

- `clothing`: 帽子 / 靴・腺 / バッグ / 小物 / 伝統衣装 / 制服・職業服 / アウター / ワンピース・セット / トップス / ボトムス / 衣服細部
- `pose`: 姿勢 / 手サイン / 持ち物 / 身仕度 / 日常・創作 / 運動 / 演技・撮影 / 戦闘 / 休息・季節
- `adult-wardrobe`: 成人向けグッズ / 拘束具 / ピアス・身体装飾 / 下着 / 靴下・靴 / ボディウェア / 水着 / 素材・透け / 衣服状態 / フィット・カットアウト / 牛モチーフ / 小物
- `adult-pose`: 拘束 / 玩具・セルフタッチ / 成人向け体位 / 接触 / 脱衣・露出 / 反応・事後 / 場所 / 姿勢

初回verifyで `drawing sword` が日常動作の一般語 `drawing` に先に一致する問題を検出したためmergeを停止。一般語 `drawing` を日常動作ルールから外し、再verify後にmergeした。

最終verify `#2783265284`:
- `pnpm check`: SUCCESS
- Vitest: 39/39 SUCCESS
- build: SUCCESS

main Pages `#2783266274`: SUCCESS。

## 現在の未確定状態

監査キューの主要未確定として残していた `lamp` / `balony` / `strawberry blonde` はすべて結論まで到達した。

MR !42で残した `NEEDS_RESEARCH` は以下3件。runtimeには追加していない。

- `fur dataset`
- `no hat`
- `no earrings`

これは「リポジトリ内に今後見つかり得る監査候補がゼロ」という意味ではない。新しい候補やモデル仕様変更が見つかった場合は、同じ監査手順で別途扱う。

## 現在の安全ルール

1. 4,000件超の一括置換・全置換をしない。
2. 同じEnglishという理由だけで削除しない。
3. NSFW等の内容を理由に削除・無害化しない。
4. option IDとlocalStorage互換性を可能な限り維持する。
5. CATEGORY_ALIASはruntime複製ではなく参照で扱う。
6. semantic meaning、category/search reference、polarityを別概念として扱う。
7. 不明なタグは `NEEDS_RESEARCH` のまま保持する。
8. CI失敗・件数異常があればmergeしない。
9. branch作業中は `[skip ci]` を活用し、最終確認に必要なRunnerだけ使う。
10. docs/scripts-only main変更ではPagesを起動しない。
11. 大規模辞書カテゴリをoption ID substringで意味分類しない。
12. 全runtime optionが辞書小分類へちょうど1回所属する回帰を維持する。
13. 既存IDをcanonical IDへ統合する場合は、favorites / history / presets等の旧保存データmigrationを同じ変更で用意する。
14. `VALID_GENERIC_PROMPT` とmodel-native known tagを区別し、既知タグでない可能性だけを理由に標準英語promptを削除しない。

## 次の調査対象

残す `NEEDS_RESEARCH` は `fur dataset` / `no hat` / `no earrings` の3件だけ。

新規候補が発見された場合のみ、根拠確認 → 専用branch → 回帰テスト → 最終CI → MRの順で再開する。
