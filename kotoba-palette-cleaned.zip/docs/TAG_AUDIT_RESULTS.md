# ことばパレット タグ監査結果 — Phase 1 / Phase 2

作成日: 2026-08-23
最終更新: 2026-08-23

## 結論

監査は **候補抽出・分類を先に行い、根拠のある小さな修正だけを別MRで反映する**。不適切・成人向け・センシティブという理由で既存タグを削除・無害化しない。

最優先は大量置換ではなく、**意味の異なるタグを誤って同一扱いしないこと**。

Phase 2で116件のcross-category候補を全件一次分類した結果、単純な「同じEnglish = 1タグ」では扱えないことを確認した。一方で、116件すべてを別タグとして復元するのも誤りである。

詳細分類は `docs/TAG_AUDIT_PHASE2.md` を参照。

## 現在の自動監査ベースライン

最新mainへrebase後、MR !8 pipeline `#2783080771` / `tag_audit` job `#16053093016` で確認。

- 走査ファイル: 42
- ソースから抽出した EN/JA ペア: 5,543
- 実行時マージ後カテゴリ: 87
- 実行時マージ後タグ: 4,717
- SFW: 3,467
- NSFW: 1,250
- Negative: 12
- 現行 normalization で同一キーになるグループ: 755
- うち日本語表記まで同一: 595
- 同一キーだが日本語表記が異なる: 160
- exact English が同一で日本語が異なる候補: 138
- 複数カテゴリにまたがるレビュー候補: 116
- 同一カテゴリ中心の訳語レビュー候補: 22
- 空白等を残した英語表記自体が異なる衝突: 91
- そのうち日本語上も意味差がある候補: 22
- loose normalization候補: 8
- 同じ日本語に異なる英語が割り当てられている候補: 191
- EN/JA の先頭末尾空白候補: 2

160件・116件はいずれも「即修正件数」ではない。監査スクリプトは自動修正せずレビューキューとして出力する。

## Negative dedupe不具合 — 修正済み

旧 `fix/preserve-negative-tags` のFAILEDはテスト不備ではなく、正しい回帰テストが既存バグを検出した状態だった。

旧状態:

- Negative期待値: 12
- 実際: 8
- runtime期待値: 4,717
- 実際: 4,713

消失していたNegative:

- `blur`
- `cropped`
- `noise`
- `frame`

原因は、global dedupeが同じEnglishのPositive/Negativeを同一identityとして扱っていたこと。

MR !18でdedupe identityへpolarityを追加し、以下を確認済み。

- Negative: 8 → 12
- runtime: 4,713 → 4,717
- SFW: 3,463 → 3,467
- NSFW: 1,250のまま
- Positive版4件も維持
- option ID変更なし
- check / regression tests / build / tag_audit成功

テスト期待値を8へ下げる修正はしていない。

## 22件の英語表記衝突

英語表記自体が異なる22件を確認し、明確に別意味なのに旧normalizationで同じキーへ潰れていたものは2件。

- `cow girl`（牛娘） / `cowgirl`（別概念）
- `fish tail`（魚の尾） / `fishtail`（髪型）

残りは `wide eyes` / `wideeyes`、`looking at viewer` / `lookingatviewer`、`soft shading` / `softshading`、`arms crossed` / `armscrossed` 等、主としてスペース差や表記揺れだった。

したがって、`norm()` から空白除去を一律で外さず、2件だけを明示的なsemantic例外として共存させている。

## 高確度のソース不備・補正状況

| 元の値 | 元の日本語 | 現在の判定 |
| --- | --- | --- |
| `balony` | バルコニー | TYPO。ただし別カテゴリに既存 `balcony` があり単純補正するとID消失リスクがあるため未変更 |
| `greyeneyes` | 灰色の目 | `grey eyes` へruntime補正済み。既存ID維持 |
| `dragonsprit` | 龍の精霊 | `dragon spirit` へruntime補正済み。既存ID維持 |
| `practicalight` | 実用照明 | `practical lighting` へruntime補正済み。既存ID維持 |
| `balconette` | バルコニー | `バルコネットブラ` へ表示補正済み |
| adult-mood `sticky` | ` sticky` | `べたつく` へ表示補正済み |
| adult-mood `tender` | ` tender` | `優しい` へ表示補正済み |
| `on knees oral` | `膝立ちで口 technic` | `膝立ちでオーラル` へ表示補正済み |
| `cleavage` | 胸元 | `胸の谷間` へ表示補正済み |
| pose `profile` | 横向き | `横顔` へ表示補正済み |
| `spooning` | スプーン | `側位（スプーニング）` へ表示補正済み |

## Phase 2: 116件 cross-category一次分類

最新監査結果を全件確認し、以下へ分類した。

- `SEMANTIC_DISTINCT`: 33
- `CATEGORY_ALIAS`: 72
- `TRANSLATION_VARIANT`: 2
- `POLARITY_DISTINCT`: 1
- `SOURCE_MISMATCH`: 3
- `NEEDS_RESEARCH`: 5
- 合計: 116

### `SEMANTIC_DISTINCT`

同じEnglishでも明確に別概念。例:

- `ripped`: 筋肉が浮き出た / 裂け
- `oiled`: オイルを塗った / オイル仕上げ
- `back`: 背中 / 背面
- `pencil`: 鉛筆 / 鉛筆画
- `painting`: 描く / 絵画
- `bridge`: 橋 / ブリッジ
- `lotus`: 蓮 / 座位
- `glass`: グラス / ガラス
- `pastel`: 色調 / 画材
- `warm`: 暖色 / 温かい雰囲気
- `mouse`: 鼠 / PCマウス

このグループをglobal dedupeで片方だけ残す設計は不適切。

### `CATEGORY_ALIAS`

同じprompt tokenでよいが、複数カテゴリから検索・選択できる必要があるもの。

例:

- `temple`: setting / architecture
- `watercolor`: medium / style
- `socks`: footwear / adult-wardrobe
- `phoenix`: species / animals

同じEnglishをプロンプトへ2回出すのではなく、1 identityに複数category referenceを持たせる方が適する。

### `POLARITY_DISTINCT`

`cropped` はPositive構図とNegative除外で用途が異なる。Negative側はMR !18で復元済み。

### `SOURCE_MISMATCH` / `NEEDS_RESEARCH`

推測修正しない。

特に:

- `yoga`: style側 `洋画風` は意味不一致。本来のEnglishが未確定
- `private`: `私的` / `私室` の意図差を要確認
- `mansion`: `豪邸` / `洋館`
- `leaves`: `葉` / `葉舞い`
- `petals`: `花びら` / `花びら舞い`
- `lamp`: `ランプ` / `スタンドライト`
- `leather`: material / pattern / wardrobe の意図を要調査

詳細な116件一覧は `docs/TAG_AUDIT_PHASE2.md` に記録する。

## NovelAI / PixAI 互換性の確認結果

### 人物人数タグ

NovelAI公式は人物生成の開始タグとして `1boy`, `1girl`, `1other` を明示し、複数人物にも `2girls`, `2boys`, `2others` 等を案内している。PixAIも人物プロンプトで `1girl` / `1boy` を使う構成を案内している。

現在の `person`, `human`, `solo`, `duo` 等を削除せず、将来の `preferredByModel` / alias メタデータでモデル別推奨を持たせる。

分類: **MODEL_SPECIFIC**

### 品質タグ

NovelAI / PixAIで推奨品質タグが異なるため、「全モデル共通の正解」へ一括置換しない。

分類: **MODEL_SPECIFIC**

### スペース・ハイフンを含む既知タグ

NovelAI公式では `art nouveau`, `ukiyo-e`, `traditional media`, `anime coloring`, `chromatic aberration`, `depth of field` 等の空白・ハイフンを含むタグが使われる。PixAIもDanbooruの `_` 表記よりプロンプトではスペースを使う方式を案内している。

現在の `artnouveau`, `ukiyoe`, `depthoffield` 等は即削除せず、モデル別の安定表記候補として監査する。

分類: **MODEL_AMBIGUOUS / MODEL_SPECIFIC**

### `strawberry blonde`

自然言語としては正しいが、確認済み資料だけでは各モデルで一貫して単一概念として扱われることまでは確認できない。

分類: **NEEDS_RESEARCH / MODEL_AMBIGUOUS**

現時点では変更禁止。

## 参照した一次・公式資料

- NovelAI Tagging: https://docs.novelai.net/en/image/tags/
- NovelAI Character Creation: https://docs.novelai.net/en/image/tutorial-charactercreation/
- NovelAI Multiple Characters: https://docs.novelai.net/en/image/multiplecharacters/
- NovelAI Quality Tags: https://docs.novelai.net/en/image/qualitytags/
- NovelAI Art Styles: https://docs.novelai.net/en/image/tutorial-artstyles/
- PixAI Prompt Cheatsheet: https://docs.pixai.art/docs/prompts/prompt-cheatsheet
- PixAI General Guide of Writing Prompts: https://support.pixai.art/en/articles/11822794-general-guide-of-writing-prompts
- PixAI Generation Help: https://support.pixai.art/en/articles/11822691-generation
- PixAI Male Character Tag Cheat Sheet: https://blog.pixai.art/en/pixai-sdxl-prompting-guide-foundations-male-character-tag-cheat-sheet/
- Danbooru grey eyes wiki: https://safebooru.donmai.us/wiki_pages/grey_eyes
- Black Forest Labs Prompting Guide: https://docs.bfl.ml/guides/prompting_unified_style

## 今後の設計方針

116件の分類結果から、global dedupeを全面廃止するのではなく、最低限以下を分離する必要がある。

1. prompt出力identity
2. semantic meaning
3. category/search reference
4. Positive / Negative polarity
5. model-specific alias / preferred form

## 次工程

1. MR !8はreport-onlyの監査MRとして完了させる。
2. `SEMANTIC_DISTINCT` 33件を対象に、semantic identity / category reference設計を別MRで作る。
3. `CATEGORY_ALIAS` 72件は同じprompt tokenを重複出力せず複数カテゴリから到達できる構造にする。
4. `SOURCE_MISMATCH` / `NEEDS_RESEARCH`は意味確認後の小さい別MRへ分離する。
5. `balony` は既存 `balcony` と衝突するため、semantic identity設計後に扱う。
6. 今後の基準値は `runtime 4,717 / SFW 3,467 / NSFW 1,250 / Negative 12`。意図しない減少があれば作業停止。
