# ことばパレット タグ監査 — Phase 2

作成日: 2026-08-23
最終更新: 2026-08-23

## 目的

Phase 1 後も残る `runtimeMeaningConflictGroups = 160` を、単なる日本語訳の揺れと、本当に別概念・別カテゴリの意味が同じ英語キーへ潰れているケースに分ける。

この文書は **監査結果のみ** を記録する。Phase 2 監査ブランチではタグ本文を変更・削除しない。

## 現在のベースライン

最新mainへrebase後、MR !8 pipeline `#2783080771` / `tag_audit` job `#16053093016` で確認。

- 実行時カテゴリ: 87
- 実行時タグ: 4,717
- SFW: 3,467
- NSFW: 1,250
- negative: 12
- normalization 重複候補: 755 groups
- 日本語差異あり: 160 groups
- exact English が同じで日本語差異あり: 138 groups
- cross-category review候補: 116 groups
- same-category translation候補: 22 groups
- 英語表記自体が異なる衝突: 91 groups
- 英語表記差 + 日本語差異あり: 22 groups
- loose normalization候補: 8 groups
- 同じ日本語・違う英語: 191 groups
- 先頭末尾空白: 2 candidates

### Negative修正による基準値更新

MR !18 で Positive / Negative を別dedupe identityとして扱うように修正した。

- runtime: 4,713 → 4,717
- SFW: 3,463 → 3,467
- NSFW: 1,250 → 1,250
- Negative: 8 → 12

復元されたNegative:

- `blur`
- `cropped`
- `noise`
- `frame`

これはテスト期待値を変更したものではなく、正しい回帰テストが発見した既存dedupe不具合を修正した結果である。

## 外部モデル仕様の確認

### NovelAI

NovelAI公式ドキュメントでは、画像モデルはタグ知識を持ち、入力時に既知タグ候補と知識量の指標を表示すると説明されている。タグ形式はモデル制御上重要で、モデルごとにタグ順序の影響もある。

参照:
- https://docs.novelai.net/en/image/tags/
- https://docs.novelai.net/en/image/tutorial-imgintro/

### PixAI

PixAI公式ヘルプでは、プロンプトは descriptive tags / short phrases をカンマ区切りで書く方式を推奨し、追加のタグ発想源として Danbooru を案内している。

参照:
- https://support.pixai.art/en/articles/11822691-generation
- https://support.pixai.art/en/articles/11822794-general-guide-of-writing-prompts

したがって、PixAI / NovelAI 共通で使う語彙監査では「英単語として意味が通る」だけでなく、カテゴリ上の意図、モデル側での解釈、既存ID互換性を分けて扱う。

## Phase 2 分類ルール

116件のcross-category候補を、以下の6分類へ保守的に分けた。

### `SEMANTIC_DISTINCT`

同じEnglishでも、カテゴリごとの意図が明確に別概念。グローバルdedupeで一方を消すべきではない。

将来は semantic identity / category-aware identity 等で別意味を保持する候補。

### `CATEGORY_ALIAS`

出力するEnglish自体は同一概念でよいが、複数カテゴリから検索・選択できる必要がある候補。

同じEnglishをプロンプトへ重複出力する必要はなく、カテゴリ参照・aliasを複数持たせる設計が適する。

### `TRANSLATION_VARIANT`

意味差はなく、日本語訳の言い換えが中心。ランタイムタグを増やす理由にはしない。

### `POLARITY_DISTINCT`

Positive / Negativeで用途が異なるもの。MR !18 でpolarityをdedupe identityへ含める修正を適用済み。

### `SOURCE_MISMATCH`

元データのEnglishと日本語またはカテゴリ意図が一致していない候補。推測置換せず、意図が確定したものだけ別MRで直す。

### `NEEDS_RESEARCH`

カテゴリの意図またはモデル上の解釈が断定できない。変更禁止。

## 116件 cross-category 一次分類

### 1. `SEMANTIC_DISTINCT` — 33件

同じEnglishだが、カテゴリごとに明確に別の意味を持つ。

`oiled`, `back`, `ripped`, `fragile`, `polished`, `pencil`, `tall`, `delicate`, `amber`, `wide`, `painting`, `hiding`, `bridge`, `lotus`, `glass`, `pastel`, `warm`, `layered`, `marble`, `stone`, `diamond`, `intimate`, `wave`, `sun`, `moon`, `tiger`, `snake`, `mouse`, `giraffe`, `zebra`, `mosaic`, `rough`, `short`

代表例:

| EN | 意味1 | 意味2 |
| --- | --- | --- |
| `ripped` | physique: 筋肉が浮き出た | surface: 裂け |
| `oiled` | adult-skin: オイルを塗った | surface: オイル仕上げ |
| `back` | anatomy: 背中 | pose: 背面 |
| `pencil` | object: 鉛筆 | medium: 鉛筆画 |
| `painting` | action: 描く | scenery: 絵画 |
| `bridge` | setting/architecture: 橋 | adult-pose: ブリッジ |
| `lotus` | nature: 蓮 | adult-pose: 座位 |
| `glass` | object: グラス | material: ガラス |
| `pastel` | tone: パステル色 | medium/material: パステル画材 |
| `warm` | tone: 暖色 | mood: 温かい |
| `layered` | composition: 重層 | hair-detail: レイヤー |
| `mouse` | animal: 鼠 | machines: マウス |
| `rough` | surface: 粗い | adult-mood: 荒々しい |
| `intimate` | mood: 親密 | placement: 近接 |

この33件は「同じ英語だから1個へ統合」で済ませてはいけない。

ただし、bare Englishをそのまま2回プロンプトへ出す設計が最適とは限らない。カテゴリ意味を保持しつつ、モデル別に具体語を出す設計も含めて次段で検討する。

### 2. `CATEGORY_ALIAS` — 72件

同一またはほぼ同一のプロンプト概念だが、カテゴリごとの検索経路・表示文脈を残すべき候補。

`coral`, `braid`, `athletic`, `toned`, `bentover`, `latex gloves`, `couple`, `headshot`, `pale skin`, `fair skin`, `light skin`, `medium skin`, `tan skin`, `dark skin`, `porcelain skin`, `glossy skin`, `ornamental`, `clean lineart`, `detailed`, `realistic`, `portrait`, `mentor`, `companion`, `library`, `backpack`, `shy`, `laughing`, `crying`, `gentle`, `fierce`, `headphones`, `feather`, `standing`, `pointing`, `kissing`, `hugging`, `profile`, `embracing`, `beach`, `underwater`, `temple`, `shrine`, `castle`, `fog`, `mist`, `gothic`, `brutalist`, `clock`, `fisheye`, `minimal`, `illustration`, `watercolor`, `oilpainting`, `charcoal`, `gouache`, `chibi`, `cozy`, `nostalgic`, `silk`, `dreamy`, `playful`, `yearning`, `smoke`, `particles`, `glitch`, `socks`, `phoenix`, `plaid`, `foam`, `sticky`, `distant`, `shiny`

例:

- `temple`: setting と architecture の両方から探せる価値はあるが、出力語は同じ `temple` でよい。
- `watercolor`: medium / style の両方から探せるが、同じEnglishを重複出力する必要はない。
- `socks`: footwear / adult-wardrobe の双方から見つけられるべきだが、プロンプト上は1回でよい。
- `phoenix`: species / animals のどちらからも到達できる方がUI上自然。

このグループは、現在の「winner以外をカテゴリから消すglobal dedupe」より、**1つのprompt identityに複数category referenceを持たせる方式**が適する。

### 3. `TRANSLATION_VARIANT` — 2件

- `nipple clamps`: `乳首クリップ` / `ニップルクランプ`
- `mandarin collar`: `スタンドカラー` / `マンダリンカラー/スタンドカラー`

別identityを増やさず、表示語の統一または検索aliasで扱う候補。

### 4. `POLARITY_DISTINCT` — 1件

- `cropped`

用途:

- composition: `トリミング` — Positive
- adult-scene: Positive構図
- avoid: `切れ` — Negative

Negative側が消えていた問題はMR !18で修正済み。

今後はPositive同士のカテゴリ経路を`CATEGORY_ALIAS`相当として扱い、Negativeだけは別polarity identityとして保持する。

### 5. `SOURCE_MISMATCH` — 3件

#### `cleavage`

ソースの `胸元` は意味が広すぎる。runtime表示は `胸の谷間` へ補正済み。英語タグ・既存IDは維持。

#### `yoga`

style側の `yoga` → `洋画風` は意味不一致。pose側の `yoga` → `ヨガポーズ` は自然。

style側で本来意図したEnglishは確定できないため、推測修正しない。

#### `private`

adult-moodでは `私的`、adult-sceneでは `私室` になっている。bare `private` だけでは「私室」という場所名まで確定できないため、元データ意図の再確認対象とする。

### 6. `NEEDS_RESEARCH` — 5件

- `mansion`: `豪邸` / `洋館` — Englishと日本語の粒度がずれており、どちらを意図したデータか未確定
- `leaves`: `葉` / `葉舞い` — bare `leaves` に「舞う」動作まで含める意図か未確定
- `petals`: `花びら` / `花びら舞い` — 同上
- `lamp`: `ランプ` / `スタンドライト` — 総称と特定形状の差をどう扱うか未確定
- `leather`: `革` / `レザー柄` / `レザー` — material / pattern / wardrobeの意図は異なるが、bare `leather` を分離するか具体語へ寄せるか要調査

この5件は根拠が増えるまで変更しない。

## 116件分類の結論

- `SEMANTIC_DISTINCT`: 33
- `CATEGORY_ALIAS`: 72
- `TRANSLATION_VARIANT`: 2
- `POLARITY_DISTINCT`: 1
- `SOURCE_MISMATCH`: 3
- `NEEDS_RESEARCH`: 5
- 合計: 116

この結果から、今後の設計を「global dedupeを全部解除」にするのは不適切。

必要なのは少なくとも次の分離である。

1. prompt出力上のidentity
2. semantic meaning
3. category/search reference
4. polarity
5. model-specific alias / preferred form

## 既に確認済みの個別事項

### `yoga` — STYLE_SOURCE_MISMATCH

- `prompt-data-extra-style.ts`: `yoga` → `洋画風`
- `prompt-data.ts` pose: `yoga` → `ヨガポーズ`

判定: **高確度のソース不備**。

style側で本来意図していた英語タグが確定できないため、推測置換しない。

### `on knees oral` — CORRUPTED_JA

- `膝立ちで口 technic`
- `膝立ちでオーラル`

Phase 2Aでruntime表示のみ `膝立ちでオーラル` へ限定修正済み。英語タグ・option ID・件数は変更していない。

### `sticky` / `tender` — CORRUPTED_JA_SOURCE

Phase 2Aで adult-mood のruntime表示のみ修正済み。

- `sticky` → `べたつく`
- `tender` → `優しい`

別カテゴリの同じEnglishは変更していない。

### `spooning`

同じEnglishの中に一般的な抱き合い姿勢と成人向け体位の文脈がある。削除・片方への強制統一は行わない。

Danbooru系確認:
- https://safebooru.donmai.us/wiki_pages/spooning?z=2

### `hand fan`

`hand fan` は `扇子` / `うちわ` のどちらか一方へ固定するより、総称表示と `folding fan` / `uchiwa` 等の個別語を分ける方が安全。

runtime表示は `手持ち扇` へ補正済み。

### `cleavage`

runtime表示は `胸の谷間` へ補正済み。

英語 `cleavage` と既存option IDは変更していない。

## Phase 2 の安全方針

1. 116件すべてを修正対象にしない。
2. `CATEGORY_ALIAS`をランタイム重複タグとして増やさない。
3. `SEMANTIC_DISTINCT`をglobal dedupeで一方削除し続けない。
4. semantic identity設計を作るまでは大量mutationしない。
5. `SOURCE_MISMATCH`は本来の意図が確定したものだけ小さな別MRで修正する。
6. `NEEDS_RESEARCH`は変更禁止。
7. NSFW等の内容を理由に削除・無害化しない。
8. option IDをできる限り維持し、localStorage互換性を壊さない。
9. 今後の件数基準は `4,717 / SFW 3,467 / NSFW 1,250 / Negative 12`。
10. 想定外の件数減少があれば公開・mergeを停止する。

## 次工程

1. この監査MRはreport-onlyのまま完了させる。
2. `SEMANTIC_DISTINCT` 33件を対象に、semantic identity / category reference設計を別MRで実装する。
3. `CATEGORY_ALIAS` 72件は、同じprompt tokenを重複出力せず複数カテゴリから到達できる構造を設計する。
4. `SOURCE_MISMATCH` / `NEEDS_RESEARCH`はデータ変更と分離する。
5. `balony` は既存 `balcony` と衝突するため、semantic identity設計後に扱う。
6. `strawberry blonde` は引き続き `NEEDS_RESEARCH / MODEL_AMBIGUOUS` とし、根拠なしに変更しない。
