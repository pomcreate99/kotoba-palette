# 辞書カテゴリ所有権仕様

作成日: 2026-08-24 JST  
対象: ことばパレット / 単語帳（Word Book）  
基準実装: MR !40「辞書カテゴリの責任重複を全体整理」  
基準merge commit: `0804fb33cf787b57954058916259f10f7306db0a`

## 1. 目的

ことばパレットの単語帳では、同じ意味領域を「上位カテゴリ内の小分類」と「専用の兄弟カテゴリ」の両方が担当すると、タグが不自然な場所へ表示されたり、同じ概念が複数カテゴリに重複して見えたりする。

この仕様は、辞書表示上の各タグについて「どのカテゴリが責任を持つか」を明確にし、今後の追加・修正で同じ問題を再発させないための基準とする。

## 2. 最重要原則

### 2.1 runtimeデータと辞書表示を分離する

カテゴリ整理は原則として**辞書表示専用のownership層**で行う。

次のものは、カテゴリ表示整理だけを理由に変更しない。

- runtime category ID
- PromptOption ID
- 英語タグ本文
- 日本語訳
- prompt出力
- お気に入り、履歴、プリセット等のlocalStorage互換性

既存PromptOptionオブジェクトを再利用し、表示上の所属のみを整理する。

### 2.2 専用カテゴリを優先する

ある概念に専用カテゴリが存在する場合、旧来の広域カテゴリの小分類に同じ責任を持たせない。

例:

- 帽子 → `headwear`
- 靴 → `footwear`
- バッグ・装身具 → `accessory`
- 衣服の襟・袖・装飾 → `clothing-detail`
- ジェスチャー → `gesture`
- 人物間の交流 → `interaction`
- 撮影距離 → `shot-distance`
- カメラ技術 → `camera-tech`

### 2.3 曖昧な自動分類を禁止する

ownership判定はexact token / phrase一致を基本とする。

禁止例:

- `cap` を含むという理由だけで `capelet` を帽子へ移す
- `old` を含むという理由だけで `gold eyes` を別分類する
- category IDのprefixを意味判定に利用する

単語境界を無視したsubstring分類は禁止する。

## 3. CATEGORY_ALIASとの関係

CATEGORY_ALIASは、同一PromptOptionを複数の辞書カテゴリから意図的に参照できる仕組みとして維持する。

ただし、過去のsource配置や日本語訳の差だけを理由にカテゴリ重複を復活させない。

特にTRANSLATION_VARIANTは検索互換のための別名であり、原則として「別カテゴリにも同じタグを表示する根拠」にはしない。

例:

- `mandarin collar` は日本語の検索別名を維持する
- しかし辞書上は `clothing-detail` が責任を持ち、旧`clothing`への二重表示は行わない

## 4. 現在のownership整理

### 4.1 人物

旧広域カテゴリから専用カテゴリへ整理する。

- `subject` → `count` : 人数
- `subject` → `shot-distance` : headshot / bust / half body / full body等
- `subject` → `angle` : profile / three-quarter / from behind等
- `subject` → `composition` : silhouette等
- `physique` → `skin` : 肌色・肌質・freckles等
- `hair` → `hair-color` : 髪色
- `hair` → `hair-style` : 髪型
- `hair-detail` → `hair-style` : 旧髪型細分
- `eyes` → `eye-color` : 瞳色
- `eyes` → `eye-shape` : 目の形・視線等
- `face-detail` → `expression` : 表情概念

旧`hair` / `hair-detail` / `eyes`がownership移動後に空になった場合、辞書タブには表示しない。

### 4.2 機械・物

- `machines` → `transport` : helicopter / jet等
- `machines` → `object` : camera / lens / tripod / microphone / headphones等

### 4.3 衣装

- `clothing` → `headwear` : 帽子・頭部装備
- `clothing` → `footwear` : 靴・ブーツ・ソックス等
- `clothing` → `accessory` : バッグ、ベルト、スカーフ、手袋、装身具等
- `clothing` → `school-hobby-props` : 弁当箱、スケッチブック等
- `clothing` → `object` : thermos / water bottle等
- `clothing` → `clothing-detail` : 袖、襟、neckline、lace、frill、ruffle等
- `clothing-detail` → `clothing` : tshirt、blouse、cardigan等の衣服そのもの
- `accessory` → `headwear` : hat / crown / veil等
- `accessory-detail` → `headwear` : hairpin等
- `accessory-detail` → `accessory` : bracelet / brooch / watch / ring / handbag等

原則: 「衣服そのもの」「衣服の細部」「頭部装備」「履物」「アクセサリー」を兄弟カテゴリとして分担させる。

### 4.4 ポーズ・動き

- `action` → `pose` : standing / sitting / kneeling等の姿勢
- `action` → `gesture` : waving / pointing等
- `action` → `interaction` : kissing / hugging等
- `pose` → `gesture` : peace / wave / pointing等
- `pose` → `interaction` : fist bump / incoming hug等
- `pose` → `hobby-sport` : yoga / skateboard / ballet / acrobatic等

`action`や`pose`を「何でも入るカテゴリ」に戻さない。

### 4.5 画面・撮影

旧`camera`を専用カテゴリへ分解する。

- `camera` → `shot-distance`
- `camera` → `camera-tech`
- `camera` → `composition`

また、構図カテゴリに混入していた明確な背景・光学概念も専用カテゴリへ移す。

- `composition` → `sky`
- `composition` → `optics`
- `composition` → `nature`
- `composition` → `scenery`
- `composition` → `interior`

ownership移動後に旧`camera`が空になった場合は辞書タブから非表示とする。

### 4.6 品質・仕上げ

`quality`は「品質」そのものに限定し、他カテゴリの責任を持たせない。

- `quality` → `composition` : beautiful composition
- `quality` → `lighting-detail` : perfect lighting
- `quality` → `surface` : texture detail
- `quality` → `camera-tech` : sharp focus / soft focus

### 4.7 NSFW

分割済みの専用カテゴリを優先し、旧`adult-anatomy`をcatch-allとして残さない。

- `adult-anatomy` → `adult-chest`
- `adult-anatomy` → `adult-skin`
- `adult-anatomy` → `adult-body`
- `adult-skin` → `adult-body` : navel / torso / back / shoulders / hips / thighs等
- `adult-body` → `adult-pose` : pose概念
- `adult-pose` → `adult-scene` : 場所・シーン概念

ownership後に`adult-anatomy`が空になった場合、辞書タブから非表示にする。

## 5. 空カテゴリの扱い

ownership移動の結果optionsが0件になったlegacyカテゴリは、辞書表示から除外する。

UI側では現在選択中カテゴリが消えた場合、同グループ内の先頭の有効カテゴリへ自動補正する。

空カテゴリを「0件のタブ」として残さない。

## 6. 保存則

カテゴリ整理ではタグを消失させてはならない。

旧カテゴリから移動する場合は、移動前のPromptOption ID集合が、移動後のownerカテゴリ群にすべて存在することをテストする。

代表文字列だけでなく**ID集合の保存則**を優先して検証する。

この方式により、runtime dedupeや表記canonicalの違いに影響されず、タグ消失を検出できる。

## 7. 回帰テスト要件

最低限、次を自動検証する。

1. runtime inventoryをownership処理が変更していないこと
2. 衣装の兄弟カテゴリ責任が分離されていること
3. `cap`が`capelet`へ誤爆しないこと
4. 旧PeopleカテゴリのIDが専用ownerへ失われず移っていること
5. Action / PoseがGesture / Interaction / Hobby-Sportを飲み込まないこと
6. 旧Cameraカテゴリの全IDが専用ownerへ保存されること
7. QualityがComposition / Lighting / Surface / Camera Techを飲み込まないこと
8. 旧adult-anatomyの全IDが分割ownerへ保存されること
9. NSFWの場所タグが`adult-scene`へ所属すること
10. CATEGORY_ALIAS・検索別名が必要な互換性を維持すること

2026-08-24の基準検証:

- `pnpm check`: SUCCESS
- Vitest: 47 / 47 SUCCESS
- `pnpm build`: SUCCESS
- MR pipeline `#2783731243`: SUCCESS
- 基準runtime inventory: 4756 options

※ 4756はこの時点のベースラインであり、将来の正規なタグ追加により増加してよい。カテゴリ整理だけを理由に不自然に減少してはならない。

## 8. 実装上のSource of Truth

現在の主要実装:

- `client/src/lib/prompt-dictionary-ownership.ts`
  - 辞書表示専用ownershipルール
- `client/src/lib/prompt-category-aliases.ts`
  - CATEGORY_ALIAS展開後にownership正規化を適用
- `client/src/lib/prompt-dictionary-ownership.test.ts`
  - ownership回帰テスト
- `client/src/lib/prompt-search.test.ts`
  - 現行verify対象からownership回帰テストを実行
- `client/src/components/kotoba-v2/dictionaryUx.ts`
  - カテゴリ内の小分類生成
- `client/src/components/kotoba-v2/dictionarySemanticTaxonomy.ts`
  - 意味ベース小分類
- `client/src/components/kotoba-v2/KotobaV2Workspace.tsx`
  - 辞書グループ・カテゴリ表示・空カテゴリ選択補正

## 9. 禁止事項

以下は行わない。

- 「整理」のためにruntime IDを一括変更する
- 同じ英語だからという理由だけでタグを削除する
- 全カテゴリを機械的substring検索だけで再分類する
- category ID prefixを意味判定に使う
- 専用カテゴリがあるのに旧広域カテゴリへ同じ小分類を新設する
- 日本語訳の違いだけで同一タグを複数カテゴリへ復活させる
- ownership修正と無関係なUI・デザイン・文章を同時変更する
- テスト失敗、件数異常、想定外の大量差分がある状態でmergeする

## 10. 新規タグ・新規カテゴリ追加時の判断順序

新しいタグを追加する場合は次の順で決める。

1. その概念専用の既存カテゴリがあるか確認する
2. あれば専用カテゴリをownerにする
3. 複数カテゴリから参照する合理的理由がある場合だけCATEGORY_ALIASを検討する
4. 単なる翻訳差・sourceファイル由来の重複ならalias表示を増やさない
5. 小分類はカテゴリ内の意味分類にのみ使い、兄弟カテゴリの役割を奪わない
6. ID保存・runtime件数・既存検索・prompt出力を回帰確認する

## 11. 変更履歴

### 2026-08-24

MR !40でカテゴリ責任重複を全体監査し、辞書表示専用ownership層を導入。

主な対象:

- 人物
- 機械・物
- 衣装
- ポーズ・動き
- 画面・撮影
- 品質
- NSFW

runtimeデータを直接移動せず、表示責任のみを正規化する方式を正式仕様とした。
