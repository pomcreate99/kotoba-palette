# Prompt Atlas — 単語キーワード分類体系

Prompt Atlasでは、選択候補を文章ではなく、原則として**一語の英語キーワード**と日本語の補助表記として提供する。選んだキーワードはカンマ区切りで並び、生成サービス固有の表記はユーザーが必要に応じて追加する。これは、短く明確なキーワードを主題・環境・光・色・スタイル・構図などの観点から選べるようにするための設計である。[1] [2] [3]

| 領域 | カテゴリ | 収録する語の品詞・役割 | 例 |
|---|---|---|---|
| 被写体 | 品質、主題、体格、髪、目、表情 | 名詞・形容詞 | `fox`, `curly`, `serene` |
| 人物設計 | 服装、アクセサリー、動作、ポーズ | 名詞・動詞・状態 | `kimono`, `walking`, `profile` |
| 場面設計 | 背景、自然・天候、建築、オブジェクト、時間 | 名詞 | `forest`, `rain`, `gothic`, `lantern`, `twilight` |
| 視覚設計 | 光、色、トーン、カメラ、構図 | 名詞・形容詞・撮影タグ | `rimlight`, `blue`, `muted`, `closeup`, `symmetry` |
| 表現設計 | 媒体、画風、素材、雰囲気、効果 | 名詞・形容詞・慣用タグ | `watercolor`, `surrealism`, `velvet`, `mysterious`, `filmgrain` |
| 補助 | 除外要素 | 名詞 | `text`, `logo`, `watermark` |

> **設計上の制約：** 辞書の候補には「soft morning light」などの複合フレーズを収録せず、`soft`、`morning`、`light`のように個別に選択可能な語へ分解する。`watercolor`、`closeup`、`filmgrain`のように画像生成で一つの慣用タグとして使われる表記は一語として扱う。

## 追加する単語カテゴリ

| カテゴリ | 辞書の狙い | 追加する単語の例 |
|---|---|---|
| 眉・瞳孔 | 表情の微調整を単語で行う | `thickbrows`, `archedbrows`, `slitpupils`, `starpupils` |
| 顔の細部 | 顔のアクセントを加える | `freckles`, `facepaint`, `eyepatch`, `sunglasses` |
| 足元 | 衣装を靴・靴下まで分解する | `boots`, `sneakers`, `sandals`, `barefoot` |
| 飲食物 | 日常・カフェ・食卓の小物を増やす | `coffee`, `ramen`, `pastry`, `bento` |
| 職業・役割 | 被写体の物語性を強める | `artist`, `chef`, `detective`, `scientist` |
| 種族・生物 | ファンタジー・SFの主題を増やす | `elf`, `android`, `mermaid`, `kitsune` |
| 人数 | 人物構成を簡潔に指定する | `solo`, `duo`, `couple`, `crowd` |
| 背景の構成物 | 場面の密度を名詞で調整する | `bookshelf`, `stairs`, `streetlamp`, `fountain` |
| アニメーション表現 | アニメ風の画面処理を選ぶ | `celshading`, `lineart`, `chibi`, `vector` |

> **安全な収録範囲：** 成人向けの語彙は「成人」「架空人物」を前提とし、未成年を表す語や、未成年を性的に描写し得る語は、SFW・NSFWを問わず収録しない。

## 参考文献

[1] [Midjourney — Prompt Basics](https://docs.midjourney.com/hc/en-us/articles/32023408776205-Prompt-Basics)

[2] [Runway — Gen-4 Image Prompting Guide](https://help.runwayml.com/hc/en-us/articles/35694045317139-Gen-4-Image-Prompting-Guide)

[3] [Adobe Firefly — Writing effective text prompts](https://helpx.adobe.com/firefly/web/work-with-images/generate-images/writing-effective-text-prompts.html)
