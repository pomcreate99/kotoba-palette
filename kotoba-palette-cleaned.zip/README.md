# ことばパレット

AI画像プロンプト単語帳「ことばパレット」。

- React + TypeScript + Vite
- GitHub Pagesで公開
- プロンプトデータの意味・分類を保ったまま管理
- 既存データを推測で削除・統合しない方針

## 開発

```bash
pnpm install
pnpm check
pnpm test
pnpm build
```

## 公開

GitHub Actions で `main` への変更を検証・ビルドし、GitHub Pagesへデプロイします。
