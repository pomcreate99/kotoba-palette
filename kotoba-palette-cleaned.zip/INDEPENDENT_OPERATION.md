# AI画像プロンプト単語帳：独立運用・復旧ガイド

このリポジトリは、**Manusが利用できない場合でもGitHubと一般的なNode.js環境だけでビルド・公開・保守できる構成**です。Manus固有のViteランタイム、デバッグ収集、ストレージ代理処理には依存しません。

| 項目 | 保管・運用先 |
| --- | --- |
| ソースコード | GitHub: `pomcreate99/prompt-atlas` |
| 公開画面 | GitHub Pages（画面）と Cloudflare Workers（問い合わせAPI） |
| 利用者データ | 端末内のローカルデータ。問い合わせはCloudflare Workerへ送信されます。 |
| 独立ビルド | Node.js 20以上、pnpm、Vite |

## Manusなしでのビルド

Node.js 20以上とpnpmを用意し、任意のPCまたはCI環境で次を実行します。

```bash
git clone https://github.com/pomcreate99/prompt-atlas.git
cd prompt-atlas
corepack enable
pnpm install --frozen-lockfile
pnpm run build:standalone
```

静的公開物は `dist/public` に生成されます。GitHub Pages以外の静的ホスティングへ移す場合は、このフォルダをそのままアップロードしてください。独自ドメインのルートへ公開する場合は、`VITE_PUBLIC_BASE=/ pnpm run build:standalone` を使います。

## 公開と復旧

通常は `main` ブランチへ反映するとGitHub ActionsがGitHub Pagesを更新します。GitHubが使えない場合も、上記の `dist/public` をCloudflare Pages、Netlify、任意のWebサーバーへ配置すれば画面は公開できます。問い合わせ機能を継続するには、Cloudflare WorkerのURLを維持してください。

> **互換性の対象範囲:** 公開中の画面と静的機能は `build:standalone` で再生成できます。`server/` 配下に残る旧来の補助コードには、Manus向けのAI・ストレージ・地図プロキシ連携が含まれる場合がありますが、GitHub Pages上の公開画面は使用していません。これらの任意機能を将来外部サーバーで再開する場合は、Cloudflare、Firebase、OpenAI等の一般的な外部サービスへ置き換えてください。

## 保全チェックリスト

1. GitHubリポジトリを定期的にミラークローンまたはZIPで保管します。
2. Cloudflare、Firebase等の外部サービスの管理権限と秘密情報を、ソースコードとは別の安全なパスワード管理庫に保管します。
3. 利用者データを持つ機能は、各アプリの書き出し機能と外部サービス側のバックアップを定期実行します。
4. Manusから届く公式の影響通知がある場合は、GitHubのコード保全とは別に、対象タスクの最新バックアップを取得します。タスクバックアップは時点スナップショットです。

## 確認コマンド

```bash
pnpm run build:standalone
```

このコマンドが成功すれば、Manus専用の開発環境なしに静的公開物を生成できます。
