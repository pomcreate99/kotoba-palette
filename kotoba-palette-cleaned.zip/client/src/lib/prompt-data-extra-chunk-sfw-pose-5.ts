/**
 * Batch chunk: extraChunkSfwPose5Category (27 tags)
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraChunkSfwPose5Category: PromptCategory = {
  id: "pose",
  label: "ポーズ",
  labelEn: "Pose",
  hint: "SFWポーズ追加",
  options: words("pose", [
    ["wake up stretch", "起き抜け伸び"],
    ["toast hold", "トーストを持つ"],
    ["ice cream lick", "アイスを舐める"],
    ["balloon hold", "風船を持つ"],
    ["luggage pull", "スーツケースを引く"],
    ["selfie stick", "自撮り棒"],
    ["group photo pose", "集合写真ポーズ"],
    ["prayer pose kneeling", "跪いて祈る"],
    ["clap once", "一拍手"],
    ["listen pose", "聞くポーズ"],
    ["note taking", "メモを取る"],
    ["tablet hold", "タブレット持ち"],
    ["camera viewfinder", "ファインダーを覗く"],
    ["hip hop pose", "ヒップホップポーズ"],
    ["ballet first position", "バレエ1番"],
    ["kendo ready", "剣道の構え"],
    ["fishing pose", "釣りポーズ"],
    ["watering can", "ジョウロ持ち"],
    ["scooter pose", "キックボード"],
    ["roller skate", "ローラースケート"],
    ["float on back", "仰向け浮き"],
    ["beach ball", "ビーチボール"],
    ["marshmallow roast", "マシュマロ炙り"],
    ["moon gaze", "月を見る"],
    ["sunset silhouette pose", "夕日シルエット"],
    ["build snowman", "雪だるま作り"],
    ["spring stretch", "春の伸び"]
  ]),
};
