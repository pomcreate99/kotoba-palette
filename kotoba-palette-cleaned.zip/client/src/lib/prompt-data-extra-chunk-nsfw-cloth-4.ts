/**
 * Batch chunk: extraChunkNsfwCloth4Category (41 tags)
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraChunkNsfwCloth4Category: PromptCategory = {
  id: "adult-wardrobe",
  label: "成人向け衣類",
  labelEn: "Adult wardrobe",
  hint: "NSFW衣装追加",
  mode: "nsfw",
  options: words("adult-wardrobe", [
    ["rear zip open", "後ろジップ開き"],
    ["tazuki backpack tie", "田畑縄"],
    ["toe tie", "つま先縛り"],
    ["crotch rope harness", "股縄ハーネス"],
    ["nipple clamps visible", "ニップルクリップ見え"],
    ["pelvic curtain only", "前垂れのみ"],
    ["stockings seam back", "バックシームストッキング"],
    ["morning wood clothing", "朝の服越し"],
    ["latex vacuum", "ラテックス真空"],
    ["body tape", "ボディテープ"],
    ["henna body", "ヘナボディ"],
    ["glow in the dark pasties", "蓄光ニップレス"],
    ["chain harness body", "チェーンハーネス"],
    ["metal collar lock", "金属首輪"],
    ["silicone gag worn", "シリコンギャグ"],
    ["ring gag worn", "リングギャグ"],
    ["spider gag worn", "スパイダーギャグ"],
    ["nose hook worn", "鼻フック"],
    ["tongue clamp", "舌クランプ"],
    ["breast binder open", "胸バインダー開き"],
    ["crotchless catsuit", "股開きキャットスーツ"],
    ["open rear leotard", "後ろ開きレオタード"],
    ["cutout at crotch swimsuit", "股カット水着"],
    ["wet micro bikini", "濡れた極小ビキニ"],
    ["see-through micro skirt", "透け極小スカート"],
    ["latex micro skirt", "ラテックス極小スカート"],
    ["PVC micro dress", "PVC極小ドレス"],
    ["bondage harness full", "フルボンデージハーネス"],
    ["discipline skirt short", "ディシプリンミニスカート"],
    ["nurse micro dress", "ナース極小ドレス"],
    ["secretary blouse open", "秘書ブラウスはだけ"],
    ["office skirt hiked", "オフィススカートたくし上げ"],
    ["gym shorts pulled aside", "ジムショーツずらし"],
    ["sports bra pulled up", "スポーツブラ上げ"],
    ["compression shirt wet", "濡れコンプレッション"],
    ["dance leotard high cut", "ハイカットダンスレオタード"],
    ["stage lingerie set", "ステージ用ランジェリー"],
    ["burlesque corset", "バーレスクコルセット"],
    ["showgirl pasties", "ショーガールニップレス"],
    ["go-go boots thigh", "サイハイゴーゴーブーツ"],
    ["platform boots extreme", "極端厚底ブーツ"]
  ]),
};
