/**
 * Prompt Atlas Danbooru/X keyword ingest (2026-08-25), part A.
 * Additive only. Do not edit prompt-data.ts.
 *
 * Skips: existing runtime tags, same-meaning aliases (smile→smiling,
 * spread legs→legs spread), rating tokens nsfw/explicit, loli/shota/
 * toddler/kid/teen/trap/shemale, and already-covered quality/style hits.
 * Hawaiian shirt kept from X research. Classic lolita is fashion, not CSAM.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

const negativeWords = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
    negative: true,
  }));

export const extraGrok20260825QualityCategory: PromptCategory = {
  id: "quality",
  label: "品質",
  labelEn: "Quality",
  hint: "仕上がりの密度を選ぶ",
  options: words("quality", [
    ["great quality", "とても高い品質"],
    ["incredibly absurdres", "非常に高い解像度"],
    ["aesthetic", "美しい仕上がり"],
    ["recent", "近年の作風"],
    ["score_9", "スコア9"],
    ["score_8_up", "スコア8以上"],
    ["score_7_up", "スコア7以上"],
    ["score_7", "スコア7"],
    ["safe", "セーフ"],
    ["sensitive", "センシティブ"],
    ["ultra HD", "ウルトラHD"],
    ["anime screenshot", "アニメのスクリーンショット"],
    ["year 2024", "2024年"],
    ["year 2025", "2025年"],
    ["year 2026", "2026年"],
    ["1980s (style)", "1980年代スタイル"],
    ["1990s (style)", "1990年代スタイル"],
    ["2000s (style)", "2000年代スタイル"],
    ["retro artstyle", "レトロな画風"],
    ["perfect quality", "完璧な品質"],
  ]),
};

export const extraGrok20260825CountCategory: PromptCategory = {
  id: "count",
  label: "人数",
  labelEn: "Count",
  hint: "人物構成を指定する",
  options: words("count", [
    ["3girls", "女性3人"],
    ["multiple girls", "複数の女性"],
    ["3boys", "男性3人"],
    ["multiple boys", "複数の男性"],
    ["1other", "その他1人"],
    ["2others", "その他2人"],
    ["3others", "その他3人"],
    ["male focus", "男性フォーカス"],
    ["female focus", "女性フォーカス"],
    ["solo focus", "一人フォーカス"],
  ]),
};

export const extraGrok20260825PlacementCategory: PromptCategory = {
  id: "placement",
  label: "位置・範囲",
  labelEn: "Placement",
  hint: "被写体の場所と見え方を選ぶ",
  options: words("placement", [
    ["partially underwater", "一部が水中"],
    ["out of frame", "フレーム外"],
    ["feet out of frame", "足がフレーム外"],
    ["hands out of frame", "手がフレーム外"],
  ]),
};

export const extraGrok20260825DemographicsCategory: PromptCategory = {
  id: "demographics",
  label: "性別・年齢",
  labelEn: "Gender & age",
  hint: "性別表記と年齢層をまとめて選ぶ",
  options: words("demographics", [
    ["young adult", "若い成人"],
    ["mature female", "成熟した女性"],
    ["mature male", "成熟した男性"],
    ["elderly", "高齢"],
  ]),
};

export const extraGrok20260825PhysiqueCategory: PromptCategory = {
  id: "physique",
  label: "体格",
  labelEn: "Physique",
  hint: "シルエットの印象を整える",
  options: words("physique", [
    ["giantess", "巨大な女性"],
    ["biceps", "上腕二頭筋"],
  ]),
};

export const extraGrok20260825SkinCategory: PromptCategory = {
  id: "skin",
  label: "肌",
  labelEn: "Skin",
  hint: "肌の仕上げ",
  options: words("skin", [
    ["tan", "日焼け肌"],
    ["glowing skin", "発光する肌"],
  ]),
};

export const extraGrok20260825HairStyleCategory: PromptCategory = {
  id: "hair-style",
  label: "髪型",
  labelEn: "Hair style",
  hint: "長さ・形・アレンジを選ぶ",
  options: words("hair-style", [
    ["absurdly long hair", "途方もなく長い髪"],
    ["very short hair", "ごく短い髪"],
    ["inverted bob", "インバーテッドボブ"],
    ["low twintails", "低いツインテール"],
    ["triple bun", "三つのお団子"],
    ["double bun", "二つのお団子"],
    ["single hair bun", "一つのお団子"],
    ["hair bun", "お団子頭"],
    ["single braid", "一本の三つ編み"],
    ["crown braid", "クラウンブレイド"],
    ["hair over one eye", "片目にかかる髪"],
    ["hair between eyes", "目の間にかかる髪"],
    ["antenna hair", "アンテナヘア"],
    ["drill hair", "ドリルヘア"],
    ["twisted hair", "ねじった髪"],
    ["flipped hair", "跳ねた髪"],
    ["parted bangs", "分けた前髪"],
    ["swept bangs", "流した前髪"],
    ["crossed bangs", "クロスした前髪"],
    ["hair intakes", "インテーク髪"],
    ["hair flaps", "フラップ状の髪"],
    ["shaggy hair", "シャギーヘア"],
    ["side braid", "サイドブレイド"],
    ["man bun", "マンバン"],
    ["hair over shoulder", "肩にかけた髪"],
    ["hair behind ear", "耳にかけた髪"],
    ["floating hair", "浮遊する髪"],
    ["hair flowing over", "流れ落ちる髪"],
    ["hair spread out", "広がった髪"],
    ["glowing hair", "発光する髪"],
    ["translucent hair", "半透明の髪"],
  ]),
};

export const extraGrok20260825HairColorCategory: PromptCategory = {
  id: "hair-color",
  label: "髪色",
  labelEn: "Hair color",
  hint: "髪の色だけを選ぶ",
  options: words("hair-color", [
    ["streaked hair", "ハイライトの入った髪"],
    ["colored inner hair", "インナーカラー"],
    ["aqua hair", "アクア髪"],
  ]),
};

export const extraGrok20260825EyeColorCategory: PromptCategory = {
  id: "eye-color",
  label: "目の色",
  labelEn: "Eye color",
  hint: "虹彩の色を選ぶ",
  options: words("eye-color", [
    ["orange eyes", "オレンジの目"],
    ["aqua eyes", "アクアの目"],
  ]),
};

export const extraGrok20260825EyeShapeCategory: PromptCategory = {
  id: "eye-shape",
  label: "目の形",
  labelEn: "Eye shape",
  hint: "目の形・状態を選ぶ",
  options: words("eye-shape", [
    ["one eye closed", "片目を閉じる"],
    ["wink", "ウインク"],
    ["tsurime", "つり目"],
    ["tareme", "たれ目"],
    ["dilated pupils", "開いた瞳孔"],
    ["symbol-shaped pupils", "記号型の瞳孔"],
    ["colored sclera", "色のついた白目"],
    ["black sclera", "黒い白目"],
    ["no sclera", "白目なし"],
    ["crazy eyes", "狂気の目"],
    ["sanpaku eyes", "三白眼"],
    ["beautiful eyes", "美しい目"],
  ]),
};

export const extraGrok20260825FaceDetailCategory: PromptCategory = {
  id: "face-detail",
  label: "顔の細部",
  labelEn: "Face details",
  hint: "顔のアクセントを加える",
  options: words("face-detail", [
    ["nose blush", "鼻の赤み"],
    ["facial mark", "顔の模様"],
    ["scar on face", "顔の傷跡"],
    ["small face", "小さな顔"],
    ["big face", "大きな顔"],
    ["round face", "丸顔"],
    ["sharp face", "シャープな顔"],
    ["beautiful face", "美しい顔"],
    ["heavy eyeliner", "濃いアイライナー"],
    ["smoky eyes", "スモーキーアイ"],
    ["contact lenses", "コンタクトレンズ"],
  ]),
};

export const extraGrok20260825ExpressionCategory: PromptCategory = {
  id: "expression",
  label: "表情",
  labelEn: "Expression",
  hint: "顔に感情を与える",
  options: words("expression", [
    ["heavy blush", "強い赤面"],
    ["annoyed", "いらだち"],
    ["furious", "激怒"],
    ["shocked", "衝撃"],
    ["scared", "恐れ"],
    ["fear", "恐怖"],
    ["expressionless", "無表情"],
    ["doyagao", "ドヤ顔"],
    ["smug", "得意げ"],
    ["worried", "心配"],
    ["tired", "疲労"],
    ["ecstatic", "有頂天"],
    ["forced smile", "作り笑い"],
    ["evil smile", "悪意のある微笑み"],
    ["crazy smile", "狂気の微笑み"],
    ["tears of joy", "喜びの涙"],
    ["nosebleed", "鼻血"],
    ["steam from nose", "鼻から湯気"],
    ["rolling eyes", "目を回す"],
    ["sweatdrop", "汗のしずく"],
  ]),
};

export const extraGrok20260825KeywordCategories: PromptCategory[] = [
  extraGrok20260825QualityCategory,
  extraGrok20260825CountCategory,
  extraGrok20260825PlacementCategory,
  extraGrok20260825DemographicsCategory,
  extraGrok20260825PhysiqueCategory,
  extraGrok20260825SkinCategory,
  extraGrok20260825HairStyleCategory,
  extraGrok20260825HairColorCategory,
  extraGrok20260825EyeColorCategory,
  extraGrok20260825EyeShapeCategory,
  extraGrok20260825FaceDetailCategory,
  extraGrok20260825ExpressionCategory,
];
