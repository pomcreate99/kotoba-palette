/**
 * Prompt Atlas Danbooru/X keyword ingest (2026-08-25), part B.
 * Additive only. Do not edit prompt-data.ts.
 *
 * Skips: existing runtime tags, same-meaning aliases (smile→smiling,
 * spread legs→legs spread), rating tokens nsfw/explicit, loli/shota/
 * toddler/kid/teen/trap/shemale, and already-covered quality/style hits.
 * Hawaiian shirt kept from X research. Classic lolita is fashion, not CSAM.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

const negativeWords = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
    negative: true,
  }));

export const extraGrok20260825PoseCategory: PromptCategory = {
  id: "pose",
  label: "ポーズ",
  labelEn: "Pose",
  hint: "身体の向きを決める",
  options: words("pose", [
    ["supine", "仰向け"],
    ["hands on own cheeks", "自分の頬に両手"],
    ["hand on own chest", "自分の胸に手"],
    ["hand on own stomach", "自分の腹に手"],
    ["outstretched arm", "伸ばした腕"],
    ["outstretched hand", "伸ばした手"],
    ["interlocked fingers", "組んだ指"],
    ["own hands together", "自分の両手を合わせる"],
    ["adjusting hair", "髪を整える"],
    ["looking to the side", "横を見る"],
    ["waking up", "目覚め"],
    ["holding object", "物を持つ"],
    ["holding cup", "カップを持つ"],
    ["face in hands", "顔を両手で覆う"],
    ["covering face", "顔を隠す"],
  ]),
};

export const extraGrok20260825GestureCategory: PromptCategory = {
  id: "gesture",
  label: "手のジェスチャー",
  labelEn: "Gestures",
  hint: "手元の動きを選ぶ",
  options: words("gesture", [
    ["peace sign over eye", "目の前でピース"],
    ["finger to mouth", "口に指"],
  ]),
};

export const extraGrok20260825InteractionCategory: PromptCategory = {
  id: "interaction",
  label: "交流・関係",
  labelEn: "Interaction",
  hint: "非性的な人との関わり",
  options: words("interaction", [
    ["bridal carry", "お姫様抱っこ"],
    ["headpat", "頭をなでる"],
    ["patting", "軽くたたく"],
  ]),
};

export const extraGrok20260825ClothingCategory: PromptCategory = {
  id: "clothing",
  label: "服装",
  labelEn: "Clothing",
  hint: "衣装の名詞を選ぶ",
  options: words("clothing", [
    ["business suit", "ビジネススーツ"],
    ["one-piece dress", "ワンピース"],
    ["furisode", "振袖"],
    ["plate armor", "プレートアーマー"],
    ["leather armor", "レザーアーマー"],
    ["fantasy armor", "ファンタジーアーマー"],
    ["idol clothes", "アイドル衣装"],
    ["jeans", "ジーンズ"],
    ["victorian dress", "ヴィクトリアンドレス"],
    ["ball gown", "ボールガウン"],
    ["unitard", "ユニタード"],
    ["classic lolita", "クラシックロリータ"],
    ["hawaiian shirt", "アロハシャツ"],
    ["crossdressing", "異性装"],
  ]),
};

export const extraGrok20260825ClothingDetailCategory: PromptCategory = {
  id: "clothing-detail",
  label: "衣服の細部",
  labelEn: "Clothing details",
  hint: "衣類の種類と部位を選ぶ",
  options: words("clothing-detail", [
    ["necktie", "ネクタイ"],
    ["open clothes", "はだけた服"],
    ["unbuttoned", "ボタンを外した"],
    ["torn clothes", "破れた服"],
    ["wet clothes", "濡れた服"],
    ["bare shoulders", "露出した肩"],
    ["midriff", "腹部の露出"],
    ["backless", "背中開き"],
    ["spaghetti strap", "スパゲティストラップ"],
    ["lace-up", "レースアップ"],
    ["zipper", "ファスナー"],
    ["buttons", "ボタン"],
    ["pockets", "ポケット"],
  ]),
};

export const extraGrok20260825AccessoryCategory: PromptCategory = {
  id: "accessory",
  label: "装飾品",
  labelEn: "Accessories",
  hint: "小さな特徴を足す",
  options: words("accessory", [
    ["round eyewear", "丸眼鏡"],
    ["earpiece", "イヤピース"],
    ["face mask", "フェイスマスク"],
    ["surgical mask", "サージカルマスク"],
    ["school bag", "通学かばん"],
    ["ribbon choker", "リボンチョーカー"],
    ["cross necklace", "十字架のネックレス"],
    ["corsage", "コサージュ"],
    ["fingerless gloves", "指なし手袋"],
    ["elbow gloves", "肘までの手袋"],
  ]),
};

export const extraGrok20260825HeadwearCategory: PromptCategory = {
  id: "headwear",
  label: "帽子・髪飾り",
  labelEn: "Headwear",
  hint: "頭部のアクセントを選ぶ",
  options: words("headwear", [
    ["hair bow", "ヘアボウ"],
    ["hair ornament", "髪飾り"],
    ["witch hat", "魔女帽"],
    ["halo", "光輪"],
  ]),
};

export const extraGrok20260825CreatureFeaturesCategory: PromptCategory = {
  id: "creature-features",
  label: "人外の身体特徴",
  labelEn: "Creature features",
  hint: "触手・鱗・ヒレなど人外の身体パーツ",
  options: words("creature-features", [
    ["demon horns", "悪魔の角"],
    ["angel wings", "天使の翼"],
    ["demon wings", "悪魔の翼"],
    ["demon tail", "悪魔の尾"],
  ]),
};

export const extraGrok20260825RoleCategory: PromptCategory = {
  id: "role",
  label: "職業・キャラクター役割",
  labelEn: "Roles",
  hint: "職業・役割・キャラクター類型を選ぶ",
  options: words("role", [
    ["maid", "メイド"],
    ["firefighter", "消防士"],
  ]),
};

export const extraGrok20260825SettingCategory: PromptCategory = {
  id: "setting",
  label: "背景",
  labelEn: "Setting",
  hint: "場所の名詞を選ぶ",
  options: words("setting", [
    ["grey background", "灰色の背景"],
    ["blurry background", "ぼかした背景"],
    ["cityscape", "街並み"],
    ["bar", "バー"],
    ["palace", "宮殿"],
    ["futon", "布団"],
    ["cyberspace", "サイバー空間"],
    ["outer space", "宇宙空間"],
    ["fantasy world", "ファンタジー世界"],
    ["dungeon", "ダンジョン"],
    ["indoor", "屋内"],
    ["outdoor", "屋外"],
    ["photostudio", "フォトスタジオ"],
    ["stage", "ステージ"],
    ["concert", "コンサート"],
    ["festival", "祭り"],
    ["car interior", "車内"],
    ["zoo", "動物園"],
    ["bathhouse", "浴場"],
  ]),
};

export const extraGrok20260825SkyCategory: PromptCategory = {
  id: "sky",
  label: "空・天体",
  labelEn: "Sky & celestial",
  hint: "空と宇宙の要素を選ぶ",
  options: words("sky", [
    ["cloudy sky", "曇り空"],
  ]),
};

export const extraGrok20260825NatureCategory: PromptCategory = {
  id: "nature",
  label: "自然・天候",
  labelEn: "Nature",
  hint: "空気をつくる自然語",
  options: words("nature", [
    ["rainy", "雨の"],
  ]),
};

export const extraGrok20260825LightingDetailCategory: PromptCategory = {
  id: "lighting-detail",
  label: "照明の細部",
  labelEn: "Lighting details",
  hint: "時間と光源を選ぶ",
  options: words("lighting-detail", [
    ["hard lighting", "硬い照明"],
    ["starlight", "星明かり"],
    ["neon lights", "ネオンライト"],
    ["tyndall effect", "チンダル現象"],
    ["colored lighting", "色つき照明"],
    ["red lighting", "赤い照明"],
    ["blue lighting", "青い照明"],
    ["purple lighting", "紫の照明"],
    ["neon glow", "ネオンの輝き"],
  ]),
};

export const extraGrok20260825OpticsCategory: PromptCategory = {
  id: "optics",
  label: "光学エフェクト",
  labelEn: "Optical effects",
  hint: "カメラ的な仕上げを選ぶ",
  options: words("optics", [
    ["sparkle", "きらめき"],
    ["glitter", "グリッター"],
    ["breeze", "そよ風"],
    ["snowing", "雪が降る"],
    ["cherry blossom petals", "桜の花びら"],
    ["embers floating", "漂う残り火"],
    ["dust particles", "塵の粒子"],
    ["pollen", "花粉"],
    ["rain streaks", "雨筋"],
    ["snow particles", "雪の粒子"],
  ]),
};

export const extraGrok20260825StyleCategory: PromptCategory = {
  id: "style",
  label: "画風",
  labelEn: "Style",
  hint: "美術的な方向を選ぶ",
  options: words("style", [
    ["no lineart", "線画なし"],
    ["thick outline", "太い輪郭"],
    ["impasto", "インパスト"],
    ["manhua", "漫画（中国）"],
  ]),
};

export const extraGrok20260825SpeciesCategory: PromptCategory = {
  id: "species",
  label: "幻獣・ファンタジー種族",
  labelEn: "Fantasy species",
  hint: "人外のファンタジー主題を選ぶ",
  options: words("species", [
    ["monster girl", "モンスター娘"],
    ["animal girl", "獣人の少女"],
  ]),
};

export const extraGrok20260825AngleCategory: PromptCategory = {
  id: "angle",
  label: "画角",
  labelEn: "Angle",
  hint: "見る位置を選ぶ",
  options: words("angle", [
    ["front view", "正面ビュー"],
    ["side view", "側面ビュー"],
    ["overhead view", "真上ビュー"],
  ]),
};

export const extraGrok20260825CompositionCategory: PromptCategory = {
  id: "composition",
  label: "構図",
  labelEn: "Composition",
  hint: "画面の配置を選ぶ",
  options: words("composition", [
    ["multiple views", "複数視点"],
    ["split screen", "画面分割"],
  ]),
};

export const extraGrok20260825WorldCategory: PromptCategory = {
  id: "world",
  label: "世界観",
  labelEn: "Worldbuilding",
  hint: "物語の時代や世界を選ぶ",
  options: words("world", [
    ["gothic fantasy", "ゴシックファンタジー"],
    ["magical girl", "魔法少女"],
    ["school life", "学園生活"],
    ["slice of life", "日常もの"],
    ["romance", "恋愛"],
    ["adventure", "冒険"],
    ["thriller", "スリラー"],
    ["mystery", "ミステリー"],
    ["comedy", "コメディ"],
    ["drama", "ドラマ"],
    ["post-apocalyptic", "ポストアポカリプス"],
    ["dystopia", "ディストピア"],
    ["utopia", "ユートピア"],
    ["yuri", "百合"],
    ["yaoi", "耽美"],
  ]),
};

export const extraGrok20260825KeywordCategoriesB: PromptCategory[] = [
  extraGrok20260825PoseCategory,
  extraGrok20260825GestureCategory,
  extraGrok20260825InteractionCategory,
  extraGrok20260825ClothingCategory,
  extraGrok20260825ClothingDetailCategory,
  extraGrok20260825AccessoryCategory,
  extraGrok20260825HeadwearCategory,
  extraGrok20260825CreatureFeaturesCategory,
  extraGrok20260825RoleCategory,
  extraGrok20260825SettingCategory,
  extraGrok20260825SkyCategory,
  extraGrok20260825NatureCategory,
  extraGrok20260825LightingDetailCategory,
  extraGrok20260825OpticsCategory,
  extraGrok20260825StyleCategory,
  extraGrok20260825SpeciesCategory,
  extraGrok20260825AngleCategory,
  extraGrok20260825CompositionCategory,
  extraGrok20260825WorldCategory,
];
