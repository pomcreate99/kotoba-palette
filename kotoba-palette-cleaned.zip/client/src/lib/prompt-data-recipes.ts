/** Complete style recipes. Character attributes are intentionally left open for refinement. */
import type { PromptCategory, PromptOption } from "./prompt-data";

const recipe = (id: string, en: string, ja: string): PromptOption => ({
  id: `recipe-style-${id}`,
  en,
  ja,
});

export const styleRecipeCategory: PromptCategory = {
  id: "recipe-style",
  label: "画風レシピ",
  labelEn: "Style recipes",
  hint: "ひとつ選ぶだけで画風・塗り・光・品質をまとめて追加。人物の髪や目はあとから選べます",
  options: [
    recipe("soft-pastel-anime", "masterpiece, best quality, anime illustration, clean lineart, soft shading, pastel colors, diffused light, gentle atmosphere", "やわらかパステルアニメ"),
    recipe("polished-anime", "masterpiece, best quality, highly detailed anime illustration, sharp clean lineart, clean cel shading, vivid colors, polished finish, perfect lighting", "高品質アニメキービジュアル"),
    recipe("modern-anime", "best quality, trendy modern illustration, precise linework, detailed shading, balanced colors, controlled lighting, clean rendering", "現代的なアニメイラスト"),
    recipe("cinematic-semi-real", "masterpiece, semi-realistic anime, painterly rendering, soft realistic shading, cinematic lighting, rim light, tonal contrast, cinematic finish", "シネマティック・セミリアル"),
    recipe("dreamy-watercolor", "best quality, watercolor illustration, delicate lineart, watercolor wash, luminous finish, soft pastel palette, dappled light, dreamy atmosphere", "夢のような水彩画"),
    recipe("gouache-storybook", "high quality, children's book illustration, gouache painting, textured brushwork, warm muted colors, soft natural light, cozy atmosphere", "あたたかな絵本・ガッシュ"),
    recipe("colored-pencil", "high quality, colored pencil illustration, pencil drawing style, delicate lines, textured paper, subtle shading, soft colors, gentle lighting", "繊細な色鉛筆画"),
    recipe("painterly-fantasy", "masterpiece, fantasy illustration, digital painting, painterly rendering, rich details, dramatic lighting, atmospheric depth, epic mood", "重厚なファンタジー絵画"),
    recipe("gothic-romance", "masterpiece, gothic illustration, ornate details, deep shadows, muted colors, dramatic rendering, candlelight, melancholic atmosphere", "ゴシック・ロマン"),
    recipe("gothic-lolita", "best quality, gothic lolita illustration style, ornate linework, lace-like details, refined coloring, soft dramatic lighting, elegant atmosphere", "ゴシックロリータ画風"),
    recipe("retro-shoujo", "best quality, retro shoujo manga style, elegant lineart, screentone shading, sparkling highlights, limited pastel palette, nostalgic atmosphere", "レトロ少女漫画"),
    recipe("retro-anime", "best quality, 90s anime style, hand-drawn cel animation, bold lineart, cel shading, film grain, warm colors, nostalgic mood", "90年代セルアニメ"),
    recipe("webtoon", "best quality, modern webtoon style, clean lineart, smooth shading, polished rendering, bright balanced colors, soft cinematic lighting", "クリーンなウェブトゥーン"),
    recipe("noir-comic", "high quality, graphic novel illustration, inked lines, high-contrast shading, monochrome palette, hard lighting, film noir atmosphere", "モノクロ・ノワールコミック"),
    recipe("luminous-scifi", "masterpiece, science fiction concept art, sleek design, highly detailed rendering, neon accents, volumetric light, cinematic composition, luminous atmosphere", "発光するSFコンセプトアート"),
    recipe("editorial-minimal", "high quality, editorial illustration, clean design, simplified rendering, limited color palette, negative space, crisp composition, modern aesthetic", "ミニマル・エディトリアル"),
    recipe("action-cel-anime", "masterpiece, dynamic anime keyframe, energetic linework, bold cel shading, vivid accent colors, speed line effects, dramatic perspective, punchy lighting", "躍動感のあるアクションアニメ"),
    recipe("ethereal-fantasy-anime", "masterpiece, ethereal fantasy anime illustration, delicate flowing lineart, translucent colors, iridescent highlights, soft bloom, celestial light, mystical atmosphere", "透明感のある幻想アニメ"),
    recipe("dark-fantasy-engraving", "high quality, dark fantasy engraving, intricate crosshatching, antique etched linework, monochrome ink, weathered paper texture, ominous shadows, arcane atmosphere", "暗黒幻想の銅版画"),
    recipe("ukiyo-e-woodblock", "high quality, ukiyo-e woodblock print, expressive contour lines, flat color blocks, traditional Japanese pigments, washi paper texture, decorative composition, Edo period aesthetic", "浮世絵・木版画"),
    recipe("sumi-e-ink-wash", "high quality, sumi-e ink wash painting, expressive brush strokes, flowing black ink, restrained grayscale, rice paper texture, generous negative space, meditative atmosphere", "静かな水墨画"),
    recipe("art-nouveau-poster", "high quality, art nouveau poster illustration, elegant organic linework, flowing botanical ornaments, decorative frame, muted jewel tones, flat shading, vintage print finish", "アール・ヌーヴォーのポスター"),
    recipe("impressionist-oil", "high quality, impressionist oil painting, visible broken brushstrokes, luminous color mixing, soft edges, natural outdoor light, atmospheric color, painterly canvas texture", "光を描く印象派油彩"),
    recipe("baroque-chiaroscuro", "masterpiece, baroque painting, classical oil rendering, rich fabric detail, deep chiaroscuro, warm golden highlights, dramatic composition, museum-quality finish", "バロック調の明暗絵画"),
    recipe("paper-cut-collage", "high quality, layered paper cut illustration, handcrafted collage, clean cut edges, tactile paper fibers, stacked silhouettes, soft cast shadows, playful color harmony", "立体的な切り絵コラージュ"),
    recipe("risograph-print", "high quality, risograph print illustration, limited spot colors, bold graphic shapes, halftone grain, imperfect ink registration, recycled paper texture, indie zine aesthetic", "リソグラフ・ZINE風"),
    recipe("pixel-art", "high quality, detailed pixel art, crisp pixel clusters, limited color palette, deliberate dithering, sprite-like rendering, retro game lighting, nostalgic digital atmosphere", "精密なピクセルアート"),
    recipe("low-poly-3d", "high quality, low-poly 3D illustration, faceted geometric forms, clean polygonal modeling, stylized materials, ambient occlusion, soft studio lighting, modern game art aesthetic", "ローポリゴン3D"),
    recipe("clay-stop-motion", "high quality, clay stop-motion style, handcrafted clay character, visible sculpted texture, miniature set, soft depth of field, warm practical lighting, charming tactile finish", "クレイ・ストップモーション"),
    recipe("stained-glass", "high quality, stained glass illustration, bold lead outlines, jewel-toned glass panels, translucent color, luminous backlighting, ornamental symmetry, cathedral window aesthetic", "光るステンドグラス"),
    recipe("vintage-travel-poster", "high quality, vintage travel poster, simplified scenic shapes, bold geometric composition, screen-printed texture, sun-faded palette, crisp typography-free layout, mid-century graphic style", "ヴィンテージ旅行ポスター"),
  ],
};
