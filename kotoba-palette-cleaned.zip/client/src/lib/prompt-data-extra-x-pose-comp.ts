/**
 * X research SFW tags (2026-08). Additive only.
 * Do not edit prompt-data.ts.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraXPoseCategory: PromptCategory = {
  id: "pose",
  label: "ポーズ",
  labelEn: "Pose",
  hint: "X調査追加",
  options: words("pose", [
    ["princess carry", "お姫様抱っこ"],
    ["putting on gloves", "手袋をはめる"],
    ["adjusting glove", "手袋を直す"],
    ["hiding mouth", "口元を隠す"],
    ["holding rose", "バラを持つ"],
    ["holding folding fan", "扇を持つ"],
    ["curtsey", "カーテシー"],
    ["skirt hold", "スカートを摘む"],
    ["skirt lift", "スカートを持ち上げる"],
    ["clothes lift", "服を持ち上げる"],
    ["looking back over shoulder", "肩越しに振り返る"],
    ["over shoulder look", "肩越しの視線"],
    ["head turned back", "頭を後ろに向ける"],
    ["hugging own leg", "自分の脚を抱える"],
    ["head on knee", "膝に頭"],
    ["finger to lips", "指を唇に"],
    ["hand covering mouth", "手で口を覆う"],
    ["writing notes", "メモを取る"],
    ["holding binder", "バインダーを持つ"],
    ["holding pen", "ペンを持つ"],
    ["side sitting", "横向き座り"],
    ["sitting on bench", "ベンチに座る"],
    ["playing piano", "ピアノを弾く"],
    ["sitting at piano", "ピアノの前に座る"],
    ["crossed ankle", "足首をクロス"],
    ["polite gesture", "礼儀正しい仕草"],
    ["elegant posture", "優雅な姿勢"],
    ["confident pose", "自信のあるポーズ"],
    ["arms behind back", "後ろで手を組む"],
    ["cross ankles", "足首を交差"],
    ["legs extended", "脚を伸ばす"],
    ["stretched legs", "伸ばした脚"],
    ["resting head on arms", "腕に頭を乗せる"],
    ["both arms down", "両腕を下ろす"],
    ["looking down at viewer", "見下ろす視点"],
    ["elegant sitting pose", "優雅な座り"],
    ["empty hands", "手ぶら"],
    ["delicate pose", "繊細なポーズ"],
  ]),
};

export const extraXCompositionCategory: PromptCategory = {
  id: "composition",
  label: "構図",
  labelEn: "Composition",
  hint: "X調査追加",
  options: words("composition", [
    ["head out of frame", "頭がフレーム外"],
    ["extreme low angle", "極端なローアングル"],
    ["dramatic foreshortening", "劇的な短縮遠近"],
    ["fisheye distortion", "魚眼歪み"],
    ["barrel distortion", "バレル歪み"],
    ["extreme dutch angle", "極端なダッチアングル"],
    ["dynamic diagonal", "ダイナミックな斜め構図"],
    ["asymmetric composition", "非対称構図"],
    ["extreme bokeh", "極端なボケ"],
    ["starry sky", "星空"],
    ["shooting star", "流れ星"],
    ["light particles", "光の粒子"],
    ["rose petals", "バラの花びら"],
    ["constellation", "星座"],
    ["aurora", "オーロラ"],
    ["grand staircase", "大階段"],
    ["mansion interior", "邸宅の内装"],
    ["dim cafe interior", "薄暗いカフェ内"],
    ["reaction panel", "リアクションパネル"]
  ]),
};

export const extraXShotDistanceCategory: PromptCategory = {
  id: "shot-distance",
  label: "距離",
  labelEn: "Shot distance",
  hint: "X調査追加",
  options: words("shot-distance", [
    ["upper thighs body", "太もも上までの構図"]
  ]),
};

export const extraXPoseCompCategories: PromptCategory[] = [
  extraXPoseCategory,
  extraXCompositionCategory,
  extraXShotDistanceCategory,
];
