/**
 * Prompt Atlas SFW style / coloring / medium tags (2026-08-25).
 * Additive only. Do not edit prompt-data.ts.
 *
 * Same-meaning / same-dedupe skips: watercolor, oilpainting, gouache, pastel,
 * cel shading, anime-style, 80s/90s anime, ukiyo-e, lineless art, cross-hatching,
 * flatcolor, popart, muted/dull colors, limited palette, digital illustration, etc.
 * soft color / pastel color / flat colors collapse to the plural or existing form.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraGrok20260825ColoringCategory: PromptCategory = {
  id: "coloring",
  label: "塗り・表現",
  labelEn: "Coloring & rendering",
  hint: "色味・塗り・線画・仕上げ",
  options: words("coloring", [
    ["soft colors", "ソフトカラー"],
    ["pastel colors", "パステルカラー"],
    ["washed out colors", "洗い流したような色"],
    ["greyscale", "グレースケール"],
    ["warm colors", "暖色寄り"],
    ["cool colors", "寒色寄り"],
    ["vibrant colors", "鮮やかな色"],
    ["bold colors", "大胆な色"],
    ["rich color separation", "リッチな色の分離"],
    ["pastel pink", "パステルピンク"],
    ["pastel blue", "パステルブルー"],
    ["pastel purple", "パステルパープル"],
    ["pastel yellow", "パステルイエロー"],
    ["ink-wash blues", "墨流しブルー"],
    ["matte colors", "マットな色"],
    ["glossy colors", "光沢のある色"],
    ["flat shading", "フラット陰影"],
    ["no shading", "陰影なし"],
    ["soft cel shading", "ソフトセルシェーディング"],
    ["hard cel shading", "ハードセルシェーディング"],
    ["manga coloring", "漫画塗り"],
    ["cel coloring", "セル塗り"],
    ["semi-painterly", "セミペインタリー"],
    ["soft painting", "柔らかい塗り"],
    ["blended painting", "ブレンド塗り"],
    ["spot color", "スポットカラー"],
    ["selective coloring", "選択的着色"],
    ["partially colored", "部分着色"],
    ["anime render", "アニメレンダー"],
    ["realistic coloring", "リアル塗り"],
    ["semi-realistic coloring", "セミリアル塗り"],
    ["delicate pencil-like contour lines", "繊細な鉛筆風輪郭線"],
    ["sketchy lineart", "スケッチ風線画"],
    ["black lineart", "黒い線画"],
    ["white lineart", "白い線画"],
    ["monochrome lineart", "モノクロ線画"],
    ["ink outlines", "インク輪郭"],
    ["thick black ink outlines", "太い黒インク輪郭"],
    ["dense crosshatching", "密なクロスハッチング"],
    ["construction lines", "構築線"],
    ["loose sketch", "ルーズスケッチ"],
    ["visible brushstrokes", "筆致が見える"],
    ["brush strokes", "ブラシストローク"],
    ["clean minimal portrait", "クリーンなミニマル肖像"],
    ["airy rendering", "軽やかなレンダリング"],
    ["low-contrast soft portrait", "低コントラストの柔らかい肖像"],
    ["semi-realistic anime illustration", "セミリアルアニメイラスト"],
    ["softly painted textures", "柔らかく塗られたテクスチャ"],
    ["painted cel shading", "描き込みセルシェーディング"],
    ["metallic highlights", "メタルハイライト"],
    ["flat layered collage", "フラットなレイヤーコラージュ"],
    ["analog screen-print imperfections", "アナログスクリーンプリントのムラ"],
  ]),
};

export const extraGrok20260825MediumCategory: PromptCategory = {
  id: "medium",
  label: "媒体",
  labelEn: "Medium",
  hint: "画材・技法",
  options: words("medium", [
    ["soft watercolor", "ソフト水彩"],
    ["loose watercolor", "ルーズ水彩"],
    ["watercolor bleed", "水彩のにじみ"],
    ["ink and watercolor", "インク＋水彩"],
    ["line and wash", "線とウォッシュ"],
    ["palette knife", "パレットナイフ"],
    ["soft pastel", "ソフトパステル"],
    ["oil pastel", "オイルパステル"],
    ["chalk drawing", "チョーク画"],
    ["poster paint", "ポスターカラー"],
    ["poster-color illustration", "ポスターカラーイラスト"],
  ]),
};

export const extraGrok20260825StyleCategory: PromptCategory = {
  id: "style",
  label: "画風",
  labelEn: "Style",
  hint: "画風・美学",
  options: words("style", [
    ["ligne claire", "リーニュクレール"],
    ["ukiyo-e woodblock print", "浮世絵木版"],
    ["yume kawaii", "ゆめかわいい"],
    ["fairy kei", "フェアリーケイ"],
    ["modern anime style", "現代アニメスタイル"],
    ["sketch style", "スケッチスタイル"],
    ["cel anime style", "セルアニメスタイル"],
    ["ben-day dots", "ベンデイドット"],
    ["graphic novel style", "グラフィックノベル風"],
  ]),
};

export const extraGrok20260825SurfaceCategory: PromptCategory = {
  id: "surface",
  label: "質感",
  labelEn: "Surface",
  hint: "紙の質感",
  options: words("surface", [
    ["paper texture", "紙の質感"],
    ["soft paper texture", "柔らかい紙質感"],
  ]),
};

export const extraGrok20260825OpticsCategory: PromptCategory = {
  id: "optics",
  label: "光学効果",
  labelEn: "Optics",
  hint: "大気の霞",
  options: words("optics", [
    ["soft atmospheric haze", "柔らかい大気の霞"],
  ]),
};

export const extraGrok20260825SkinCategory: PromptCategory = {
  id: "skin",
  label: "肌",
  labelEn: "Skin",
  hint: "肌の仕上げ",
  options: words("skin", [
    ["subsurface skin warmth", "肌のサブサーフェス温み"],
  ]),
};

export const extraGrok20260825SettingCategory: PromptCategory = {
  id: "setting",
  label: "背景",
  labelEn: "Setting",
  hint: "紙背景",
  options: words("setting", [
    ["warm beige paper background", "温かいベージ紙背景"],
  ]),
};

export const extraGrok20260825StyleCategories: PromptCategory[] = [
  extraGrok20260825ColoringCategory,
  extraGrok20260825MediumCategory,
  extraGrok20260825StyleCategory,
  extraGrok20260825SurfaceCategory,
  extraGrok20260825OpticsCategory,
  extraGrok20260825SkinCategory,
  extraGrok20260825SettingCategory,
];
