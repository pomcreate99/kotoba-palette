import type { ContentMode, PromptCategory, PromptOption } from "./prompt-data";

type RecipeSlot = {
  categoryIds: string[];
  allowed: string[];
  count?: number;
};

type RandomRecipe = {
  id: string;
  label: string;
  slots: RecipeSlot[];
};

const commonQuality: RecipeSlot = {
  categoryIds: ["quality"],
  allowed: ["detailed", "intricate", "polished", "highres", "ultradetailed", "finelydetailed", "sharp", "crisp"],
  count: 3,
};

const commonNegative: RecipeSlot = {
  categoryIds: ["avoid"],
  allowed: ["lowres", "deformed", "artifact", "blur", "watermark", "text"],
  count: 4,
};

const nsfwEnhancementSlots: RecipeSlot[] = [
  {
    categoryIds: ["adult-body"],
    allowed: [
      "petite body", "slender frame", "lithe body", "slim", "athletic",
      "muscular", "toned", "soft body", "plump", "voluptuous", "curvy",
      "broad shoulders", "narrow waist", "wide hips", "thick thighs", "long legs",
    ],
  },
  {
    categoryIds: ["adult-wardrobe"],
    allowed: [
      "lingerie", "bodysuit", "stockings", "garter", "corset", "nightgown",
      "latex", "leather", "lace", "satin", "sheer", "mesh", "bustier",
      "fishnets", "bikini", "bunny lingerie", "reverse bunnysuit",
    ],
  },
  {
    categoryIds: ["adult-mood"],
    allowed: [
      "sensual", "seductive", "intimate", "sultry", "alluring", "romantic",
      "passionate", "confident", "relaxed", "glamorous", "shy", "bold",
    ],
  },
  {
    categoryIds: ["adult-pose"],
    allowed: [
      "reclining", "arching", "kneeling", "lounging", "lying", "sitting",
      "leaning", "stretching", "onback", "sidepose", "looking away",
      "looking at viewer", "eyes closed",
    ],
  },
  {
    categoryIds: ["adult-scene"],
    allowed: [
      "boudoir", "bedroom", "closeup", "rearview", "silhouette", "mirror",
      "curtains", "candlelight", "sheets", "bathtub", "private", "night",
      "softlight", "moonlight", "windowlight",
    ],
  },
];

const recipes: RandomRecipe[] = [
  {
    id: "anime-character",
    label: "アニメ人物",
    slots: [
      { categoryIds: ["subject"], allowed: ["person", "portrait", "figure"] },
      { categoryIds: ["count"], allowed: ["solo"] },
      { categoryIds: ["pose", "action"], allowed: ["elegantpose", "casualpose", "lookingback", "standing", "sitting", "walking"] },
      { categoryIds: ["camera"], allowed: ["portrait", "mediumshot", "fullbody"] },
      { categoryIds: ["angle"], allowed: ["eyelevel", "frontal", "lowangle"] },
      { categoryIds: ["composition"], allowed: ["ruleofthirds", "centered", "dynamic", "negativespace"] },
      { categoryIds: ["setting"], allowed: ["city", "street", "garden", "cafe", "library", "rooftop", "shrine"] },
      { categoryIds: ["light"], allowed: ["softlighting", "rimlight", "backlight", "cinematiclighting", "naturallight"] },
      { categoryIds: ["lighting-detail"], allowed: ["goldenhour", "bluehour", "windowlight", "sidelighting"] },
      { categoryIds: ["tone"], allowed: ["vibrant", "pastel", "bright", "softtones"] },
      { categoryIds: ["medium"], allowed: ["illustration", "digitalart"] },
      { categoryIds: ["style"], allowed: ["anime", "manga", "celshaded", "softshading"] },
      { categoryIds: ["mood"], allowed: ["beautiful", "dreamy", "serene", "lively", "soft"] },
      commonQuality,
      commonNegative,
    ],
  },
  {
    id: "soft-illustration",
    label: "やわらかいイラスト",
    slots: [
      { categoryIds: ["subject"], allowed: ["person", "portrait", "figure"] },
      { categoryIds: ["count"], allowed: ["solo", "duo"] },
      { categoryIds: ["pose", "action"], allowed: ["casualpose", "elegantpose", "sitting", "reading", "walking", "leaning"] },
      { categoryIds: ["camera"], allowed: ["portrait", "mediumshot", "fullbody"] },
      { categoryIds: ["angle"], allowed: ["eyelevel", "frontal"] },
      { categoryIds: ["composition"], allowed: ["ruleofthirds", "centered", "negativespace", "minimal"] },
      { categoryIds: ["setting"], allowed: ["garden", "cafe", "library", "bedroom", "park", "cottage"] },
      { categoryIds: ["light"], allowed: ["softlight", "diffusedlight", "softlighting", "naturallight"] },
      { categoryIds: ["lighting-detail"], allowed: ["goldenhour", "windowlight", "highkey"] },
      { categoryIds: ["tone"], allowed: ["pastel", "warm", "bright", "softtones", "muted"] },
      { categoryIds: ["medium"], allowed: ["illustration", "watercolor", "gouache", "digitalart"] },
      { categoryIds: ["style"], allowed: ["illustration", "softshading", "semi realistic", "cozy", "watercolor"] },
      { categoryIds: ["mood"], allowed: ["beautiful", "dreamy", "serene", "peaceful", "cozy", "warm"] },
      commonQuality,
      commonNegative,
    ],
  },
  {
    id: "cinematic-concept",
    label: "シネマティック",
    slots: [
      { categoryIds: ["subject"], allowed: ["person", "figure", "portrait"] },
      { categoryIds: ["count"], allowed: ["solo"] },
      { categoryIds: ["pose", "action"], allowed: ["dynamicpose", "actionpose", "lookingback", "standing", "walking"] },
      { categoryIds: ["camera"], allowed: ["mediumshot", "fullbody", "wideangle", "portrait"] },
      { categoryIds: ["angle"], allowed: ["lowangle", "eyelevel", "highangle", "dutchangle"] },
      { categoryIds: ["composition"], allowed: ["ruleofthirds", "diagonal", "dynamic", "layered"] },
      { categoryIds: ["setting"], allowed: ["city", "alley", "forest", "ruins", "castle", "rooftop", "space"] },
      { categoryIds: ["light"], allowed: ["cinematiclighting", "volumetriclight", "rimlight", "backlight", "dramaticlighting"] },
      { categoryIds: ["lighting-detail"], allowed: ["bluehour", "moonlight", "sidelighting", "lowkey", "streetlight"] },
      { categoryIds: ["tone"], allowed: ["contrast", "cool", "dark", "desaturated", "vibrant"] },
      { categoryIds: ["medium"], allowed: ["digitalart", "illustration", "photography"] },
      { categoryIds: ["style"], allowed: ["conceptart", "fantasy", "cyberpunk", "darkfantasy", "highfantasy", "photorealistic"] },
      { categoryIds: ["mood"], allowed: ["dramatic", "mysterious", "epic", "powerful", "mystical"] },
      commonQuality,
      commonNegative,
    ],
  },
];

const pickRandom = <T,>(items: T[]): T | undefined => items[Math.floor(Math.random() * items.length)];

function pickSlot(slot: RecipeSlot, categories: PromptCategory[]): PromptOption[] {
  const allowed = new Set(slot.allowed.map((word) => word.toLowerCase().replace(/\s+/g, "")));
  const candidates = categories
    .filter((category) => slot.categoryIds.includes(category.id))
    .flatMap((category) => category.options)
    .filter((option) => allowed.has(option.en.toLowerCase().replace(/\s+/g, "")));

  const pool = [...candidates];
  const result: PromptOption[] = [];
  const count = Math.min(slot.count ?? 1, pool.length);
  while (result.length < count) {
    const index = Math.floor(Math.random() * pool.length);
    result.push(pool.splice(index, 1)[0]);
  }
  return result;
}

export function generateCuratedRandom(categories: PromptCategory[], contentMode: ContentMode) {
  const available = categories.filter((category) => category.mode !== "nsfw" || contentMode === "nsfw");
  const recipe = pickRandom(recipes) ?? recipes[0];
  const baseOptions = recipe.slots.flatMap((slot) => pickSlot(slot, available));
  const adultOptions = contentMode === "nsfw"
    ? nsfwEnhancementSlots.flatMap((slot) => pickSlot(slot, available))
    : [];
  const unique = [...new Map([...baseOptions, ...adultOptions].map((option) => [option.id, option])).values()];
  return {
    label: contentMode === "nsfw" ? `${recipe.label} + NSFW` : recipe.label,
    options: unique,
  };
}
