/**
 * Batch chunk: extraChunkSfwCloth4Category (32 tags)
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraChunkSfwCloth4Category: PromptCategory = {
  id: "clothing",
  label: "服装",
  labelEn: "Clothing",
  hint: "SFW衣装追加",
  options: words("clothing", [
    ["bike shorts under skirt", "スカート下のバイクパンツ"],
    ["compression tights", "コンプレッションタイツ"],
    ["hakama-style pants", "袴風パンツ"],
    ["hakama skirt", "袴スカート"],
    ["yukata with obi", "帯付き浴衣"],
    ["coverall stained", "汚れのつなぎ"],
    ["pottery apron", "陶芸エプロン"],
    ["gardening gloves", "園芸手袋"],
    ["helmet bike", "自転車ヘルメット"],
    ["chef toque", "コック帽"],
    ["lab goggles on head", "頭にゴーグル"],
    ["name tag pin", "名札ピン"],
    ["wristlet", "リストレット"],
    ["key pouch", "キーポーチ"],
    ["instrument case", "楽器ケース"],
    ["sketchbook under arm", "スケッチブック"],
    ["shopping tote full", "いっぱいのトート"],
    ["foldable bag", "折りたたみバッグ"],
    ["weekender bag", "ウィークエンダー"],
    ["carry-on luggage", "機内持ち込み荷物"],
    ["travel pouch", "旅行用ポーチ"],
    ["toiletry bag", "洗面用具バッグ"],
    ["tech pouch", "ガジェットポーチ"],
    ["thermos hold", "水筒"],
    ["lunch bag", "ランチバッグ"],
    ["shrine maiden ribbons", "巫女リボン"],
    ["firefighter jacket", "消防ジャケット"],
    ["pilot epaulettes", "パイロット肩章"],
    ["police badge", "警官バッジ"],
    ["hard hat", "安全ヘルメット"],
    ["cycling cap", "サイクルキャップ"],
    ["cowboy hat modern", "モダンカウボーイハット"]
  ]),
};
