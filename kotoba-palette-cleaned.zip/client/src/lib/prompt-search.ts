import type { PromptOption } from "@/lib/prompt-data";

export type PromptSearchResult = {
  matches: PromptOption[];
  isSentence: boolean;
};

const SAFE_SINGLE_JAPANESE_TERMS = new Set([
  "雨", "夜", "傘", "森", "海", "空", "猫", "犬", "花", "雪",
  "月", "星", "火", "水", "本", "車", "駅", "城", "街",
]);

type SemanticAliasRule = {
  pattern: RegExp;
  targets: string[];
};

/**
 * Japanese natural-language input often uses concepts that do not literally
 * appear in the tag labels (for example 少女 -> girl or 魔法 -> fantasy).
 * Keep this expansion conservative: aliases point only to existing prompt tags
 * and never rewrite the user's text or invent a new prompt token.
 */
const JAPANESE_SEMANTIC_ALIASES: SemanticAliasRule[] = [
  { pattern: /魔法少女/u, targets: ["magical girl costume", "girl", "fantasy", "mystical"] },
  { pattern: /少女|女の子|女子/u, targets: ["girl"] },
  { pattern: /少年|男の子|男子/u, targets: ["boy"] },
  { pattern: /女性|女の人/u, targets: ["woman", "female"] },
  { pattern: /男性|男の人/u, targets: ["man", "male"] },
  { pattern: /魔法|魔術|魔力/u, targets: ["fantasy", "mystical"] },
  { pattern: /幻想的|幻想/u, targets: ["fantasy", "mystical", "dreamy"] },
  { pattern: /森林|森の中/u, targets: ["forest"] },
  { pattern: /海辺|浜辺/u, targets: ["beach", "shore", "coast"] },
  { pattern: /都会|都市/u, targets: ["city"] },
  { pattern: /夕暮れ|夕方|黄昏/u, targets: ["dusk", "sunset"] },
  { pattern: /朝焼け|夜明け|明け方/u, targets: ["dawn", "sunrise"] },
  { pattern: /星空/u, targets: ["starry sky", "stars"] },
  { pattern: /月夜/u, targets: ["night", "moon", "moonlight"] },
  { pattern: /雨天|雨の中/u, targets: ["rain"] },
  { pattern: /雪景色|雪の中/u, targets: ["snow"] },
  { pattern: /アニメ風|アニメ調/u, targets: ["anime"] },
];

/**
 * Audited alternate Japanese labels for canonical prompt tokens.
 * These aliases improve search without creating new runtime tags.
 */
const JAPANESE_OPTION_ALIASES: Record<string, readonly string[]> = {
  "nipple clamps": ["乳首クリップ"],
  "mandarin collar": ["マンダリンカラー", "マンダリンカラー/スタンドカラー"],
  "lamp": ["スタンドライト"],
};

const normalize = (value: string) =>
  value.normalize("NFKC").toLocaleLowerCase().trim();

const compact = (value: string) =>
  normalize(value).replace(/[\s\p{P}\p{S}]+/gu, "");

const escapeRegExp = (value: string) =>
  value.replace(/[|\\{}()[\]^$+*?.-]/g, "\\$&");

const japaneseOptionAliases = (option: PromptOption) =>
  JAPANESE_OPTION_ALIASES[normalize(option.en)] ?? [];

const looksLikeSentence = (query: string) => {
  const normalized = normalize(query);
  if (normalized.length >= 12) return true;
  if (/[、。！？,.!?\n]/u.test(normalized)) return true;
  if (/\s/u.test(normalized) && normalized.split(/\s+/u).length >= 3) return true;
  return normalized.length >= 6 && /[はがをにでとのへもや]/u.test(normalized);
};

const containsEnglishTerm = (query: string, term: string) => {
  const normalizedQuery = normalize(query);
  const normalizedTerm = normalize(term);
  if (!normalizedTerm) return false;

  if (/^[a-z0-9 ]+$/u.test(normalizedTerm)) {
    const spacedTerm = normalizedTerm.replace(/\s+/gu, " ");
    const boundaryPattern = new RegExp(
      `(^|[^a-z0-9])${escapeRegExp(spacedTerm)}(?=$|[^a-z0-9])`,
      "u",
    );
    if (boundaryPattern.test(normalizedQuery.replace(/\s+/gu, " "))) return true;

    const compactTerm = compact(normalizedTerm);
    return compactTerm.length >= 6 && compact(normalizedQuery).includes(compactTerm);
  }

  return normalizedQuery.includes(normalizedTerm);
};

const semanticAliasScore = (query: string, option: PromptOption) => {
  const normalizedQuery = normalize(query);
  const normalizedEn = normalize(option.en);
  const compactEn = compact(option.en);
  let best = 0;

  for (const rule of JAPANESE_SEMANTIC_ALIASES) {
    if (!rule.pattern.test(normalizedQuery)) continue;
    const targetIndex = rule.targets.findIndex((target) => {
      const normalizedTarget = normalize(target);
      return normalizedEn === normalizedTarget || compactEn === compact(normalizedTarget);
    });
    if (targetIndex < 0) continue;
    best = Math.max(best, 4_000 + (rule.targets.length - targetIndex) * 10 + compactEn.length);
  }

  return best;
};

const optionMatchScore = (query: string, option: PromptOption) => {
  const normalizedQuery = normalize(query);
  const compactQuery = compact(query);
  const normalizedEn = normalize(option.en);
  const normalizedJa = normalize(option.ja);
  const normalizedJaAliases = japaneseOptionAliases(option).map(normalize);
  const compactEn = compact(option.en);

  if (
    normalizedQuery === normalizedEn ||
    normalizedQuery === normalizedJa ||
    normalizedJaAliases.includes(normalizedQuery) ||
    compactQuery === compactEn
  ) {
    return 10_000 + Math.max(
      normalizedEn.length,
      normalizedJa.length,
      ...normalizedJaAliases.map((alias) => alias.length),
    );
  }

  const japaneseMatch =
    (normalizedJa.length > 1
      ? normalizedQuery.includes(normalizedJa)
      : SAFE_SINGLE_JAPANESE_TERMS.has(normalizedJa) && normalizedQuery.includes(normalizedJa)) ||
    normalizedJaAliases.some((alias) => alias.length > 1 && normalizedQuery.includes(alias));
  const englishMatch = containsEnglishTerm(query, option.en);
  const lexicalScore = Math.max(
    japaneseMatch ? 5_000 + Math.max(normalizedJa.length, ...normalizedJaAliases.map((alias) => alias.length)) : 0,
    englishMatch ? 5_000 + compactEn.length : 0,
  );

  return Math.max(lexicalScore, semanticAliasScore(query, option));
};

export function findPromptMatches(
  query: string,
  options: PromptOption[],
): PromptSearchResult {
  const normalizedQuery = normalize(query);
  if (!normalizedQuery) return { matches: [], isSentence: false };

  const isSentence = looksLikeSentence(query);

  if (!isSentence) {
    const compactQuery = compact(query);
    const matches = options.filter((option) => {
      const normalizedEn = normalize(option.en);
      const normalizedJa = normalize(option.ja);
      const normalizedJaAliases = japaneseOptionAliases(option).map(normalize);
      return (
        normalizedEn.includes(normalizedQuery) ||
        normalizedJa.includes(normalizedQuery) ||
        normalizedJaAliases.some((alias) => alias.includes(normalizedQuery)) ||
        compact(option.en).includes(compactQuery)
      );
    });
    return { matches, isSentence };
  }

  const seen = new Set<string>();
  const ranked = options
    .map((option, index) => ({
      option,
      index,
      score: optionMatchScore(query, option),
    }))
    .filter(({ option, score }) => {
      if (!score || seen.has(option.id)) return false;
      seen.add(option.id);
      return true;
    })
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .map(({ option }) => option);

  return { matches: ranked, isSentence };
}
