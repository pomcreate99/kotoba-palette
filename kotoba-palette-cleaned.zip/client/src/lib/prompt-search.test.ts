import "./prompt-dictionary-ownership.test";
import { describe, expect, it } from "vitest";
import { categories, type PromptOption } from "./prompt-data";
import { applyPromptCategoryAliases, auditedTranslationVariantEnglish } from "./prompt-category-aliases";
import { mergeExtraCategoriesWithAliases } from "./prompt-data-merge";
import { findPromptMatches } from "./prompt-search";

const options: PromptOption[] = [
  { id: "setting-forest", en: "forest", ja: "森" },
  { id: "demographics-girl", en: "girl", ja: "女の子" },
  { id: "style-fantasy", en: "fantasy", ja: "ファンタジー" },
  { id: "mood-mystical", en: "mystical", ja: "幻想的" },
  { id: "adult-goods-magicwand", en: "magic wand", ja: "電マ" },
  { id: "demographics-boy", en: "boy", ja: "男の子" },
  { id: "setting-beach", en: "beach", ja: "海岸" },
  { id: "setting-shore", en: "shore", ja: "岸辺" },
  { id: "time-night", en: "night", ja: "夜" },
  { id: "object-lamp", en: "lamp", ja: "ランプ" },
  { id: "adult-wardrobe-nipple clamps", en: "nipple clamps", ja: "ニップルクランプ" },
  { id: "clothing-detail-mandarincollar", en: "mandarin collar", ja: "スタンドカラー" },
];

describe("prompt sentence search", () => {
  it("expands a Japanese sentence into multiple useful visual concepts", () => {
    const result = findPromptMatches("魔法の森の中にいる少女", options);
    const ids = result.matches.map((option) => option.id);

    expect(result.isSentence).toBe(true);
    expect(ids).toContain("setting-forest");
    expect(ids).toContain("demographics-girl");
    expect(ids).toContain("style-fantasy");
    expect(ids).toContain("mood-mystical");
    expect(ids).not.toContain("adult-goods-magicwand");
  });

  it("supports common Japanese paraphrases instead of literal-label matching only", () => {
    const result = findPromptMatches("夜の海辺にいる少年", options);
    const ids = result.matches.map((option) => option.id);

    expect(ids).toContain("time-night");
    expect(ids).toContain("demographics-boy");
    expect(ids).toContain("setting-beach");
    expect(ids).toContain("setting-shore");
  });

  it("keeps ordinary short tag search behavior", () => {
    const result = findPromptMatches("ファンタジー", options);
    expect(result.isSentence).toBe(false);
    expect(result.matches.map((option) => option.id)).toEqual(["style-fantasy"]);
  });

  it("keeps audited alternate Japanese translations searchable without duplicate tags", () => {
    expect(findPromptMatches("乳首クリップ", options).matches.map((option) => option.id))
      .toEqual(["adult-wardrobe-nipple clamps"]);
    expect(findPromptMatches("マンダリンカラー", options).matches.map((option) => option.id))
      .toEqual(["clothing-detail-mandarincollar"]);
    expect(findPromptMatches("スタンドライト", options).matches.map((option) => option.id))
      .toEqual(["object-lamp"]);
  });

  it("keeps translation variants searchable without restoring obsolete source categories", () => {
    expect(auditedTranslationVariantEnglish).toHaveLength(2);

    const merged = mergeExtraCategoriesWithAliases(categories);
    const runtime = merged.categories;
    const aliasedView = applyPromptCategoryAliases(runtime, runtime, merged.categoryAliasOptionIds);

    const find = (categoryId: string, en: string) => aliasedView
      .find((category) => category.id === categoryId)?.options.find((option) => option.en === en);

    const nippleClampsWardrobe = find("adult-wardrobe", "nipple clamps");
    expect(nippleClampsWardrobe).toBeDefined();
    expect(runtime.some((category) => category.id === "adult-goods")).toBe(false);

    const mandarinCollarDetail = find("clothing-detail", "mandarin collar");
    const mandarinCollarClothing = find("clothing", "mandarin collar");
    expect(mandarinCollarDetail).toBeDefined();
    expect(mandarinCollarClothing).toBeUndefined();

    expect(runtime.flatMap((category) => category.options)).toHaveLength(5368);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "nipple clamps")).toHaveLength(1);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "mandarin collar")).toHaveLength(1);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "lamp")).toHaveLength(1);
  });
});
