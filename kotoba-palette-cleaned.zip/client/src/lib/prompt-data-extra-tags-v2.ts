/** Additional SFW tags supplied for Prompt Atlas v2. */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({ id: `${category}-${en.replace(/\s+/g, "")}`, en, ja }));

export const extraV2Categories: PromptCategory[] = [
  {
    id: "quality",
    label: "品質",
    labelEn: "Quality",
    hint: "仕上がりの密度を選ぶ",
    options: words("quality", [
      ["highest quality", "最上級品質"],
      ["tonal contrast", "トーンコントラスト"],
    ]),
  },
  {
    id: "expression",
    label: "表情",
    labelEn: "Expression",
    hint: "顔に感情を与える",
    options: words("expression", [
      ["gentle smile", "優しい微笑み"],
      ["serene expression", "穏やかな表情"],
      ["melancholic expression", "物憂げな表情"],
    ]),
  },
  {
    id: "setting",
    label: "背景",
    labelEn: "Setting",
    hint: "場所の名詞を選ぶ",
    options: words("setting", [
      ["japanese garden", "日本庭園"],
      ["church", "教会"],
      ["city street", "街路"],
    ]),
  },
  {
    id: "light",
    label: "光",
    labelEn: "Light",
    hint: "ライティングを選ぶ",
    options: words("light", [
      ["gentle lighting", "穏やかな照明"],
      ["controlled lighting", "制御された照明"],
      ["top light", "トップライト"],
    ]),
  },
  {
    id: "mood",
    label: "雰囲気",
    labelEn: "Mood",
    hint: "感情の方向を選ぶ",
    options: words("mood", [
      ["fragile", "儚い"],
      ["unstable", "不安定"],
      ["relaxed", "くつろいだ"],
      ["melancholic atmosphere", "憂鬱な雰囲気"],
      ["lonely atmosphere", "孤独な雰囲気"],
      ["quiet atmosphere", "静かな雰囲気"],
      ["fragile atmosphere", "儚い雰囲気"],
    ]),
  },
  {
    id: "face-detail",
    label: "顔の細部",
    labelEn: "Face details",
    hint: "顔のアクセントを加える",
    options: words("face-detail", [
      ["refined facial features", "端整な顔立ち"],
      ["delicate features", "繊細な顔立ち"],
      ["slender face", "細面"],
      ["small nose", "小さな鼻"],
      ["narrow jaw", "細い顎"],
      ["small chin", "小さな顎"],
      ["slightly parted lips", "少し開いた唇"],
      ["soft lips", "柔らかい唇"],
      ["glossy lips", "艶のある唇"],
      ["full lips", "ふっくらした唇"],
      ["bloodless skin", "血の気のない肌"],
    ]),
  },
  {
    id: "lighting-detail",
    label: "照明の細部",
    labelEn: "Lighting details",
    hint: "時間と光源を選ぶ",
    options: words("lighting-detail", [
      ["side backlight", "サイド逆光"],
      ["dappled light", "木漏れ日のような光"],
    ]),
  },
];
