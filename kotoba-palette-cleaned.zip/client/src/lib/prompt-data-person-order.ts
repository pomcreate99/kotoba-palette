import type { PromptCategory, PromptOption } from "./prompt-data";

const normalize = (value: string) => value.toLowerCase().replace(/\s+/g, " ").trim();

const exactOrders: Record<string, string[]> = {
  subject: [
    "person", "human", "individual", "figure", "portrait",
    "1person", "2people", "multiple people",
    "half body",
    "facing viewer", "three quarter view", "profile view", "from behind",
    "silhouette", "anonymous",
  ],
  demographics: [
    "adult",
    "man", "male", "gentleman", "youngman", "oldman", "elderlyman",
    "woman", "female", "lady", "youngwoman", "oldwoman", "elderlywoman",
    "androgynous", "nonbinary", "masculine", "feminine",
    "child", "boy", "girl", "malechild", "femalechild", "teenager",
    "schoolchild", "schoolboy", "schoolgirl",
  ],
  count: ["1girl", "1boy", "2girls", "2boys", "solo", "pair", "duo", "couple", "twins", "trio", "group", "ensemble", "lineup", "crowd"],
  relationships: [
    "family", "parents", "sibling", "guardian",
    "companion", "friends", "classmate", "teammate", "neighbor", "community",
    "mentor",
  ],
};

// Each row is one semantic group. Options are alphabetical inside that group.
const semanticGroups: Record<string, string[][]> = {
  physique: [
    ["tall", "petite"],
    ["slender", "slim", "skinny", "lean", "thin frame", "slender build", "lean physique", "delicate"],
    ["athletic", "athletic build", "muscular", "muscular arms", "toned", "ripped", "strong", "broad", "stocky"],
    ["soft body", "chubby", "plump", "curvy", "graceful"],
    ["hourglass figure", "pear shaped"],
    ["broad shoulders", "narrow waist", "wide hips", "thick thighs", "thin arms"],
    ["long legs", "short legs", "long torso", "short torso"],
    ["large breasts", "small breasts", "flat chest"],
  ],
  skin: [
    ["pale skin", "fair skin", "porcelain skin", "light skin", "medium skin", "olive skin", "sun-kissed skin", "tan skin", "tanned skin", "brown skin", "dark skin", "deep skin", "ebony skin"],
    ["warm undertone", "neutral undertone", "cool undertone"],
    ["smooth skin", "soft skin", "silky skin", "dewy skin", "matte skin", "glossy skin", "textured skin", "rough skin", "dry skin", "oily skin", "translucent skin", "veiny skin"],
    ["freckles", "light freckles", "heavy freckles", "face freckles", "shoulder freckles", "moles", "beauty mark", "birthmark", "tan lines"],
    ["healthy glow", "radiant skin", "flawless skin", "rosy cheeks", "flushed skin", "sunburn", "pallid complexion"],
  ],
  "face-detail": [
    ["refined facial features", "delicate features", "slender face", "small nose", "narrow jaw", "small chin", "dimples", "wrinkles"],
    ["soft lips", "glossy lips", "full lips", "slightly parted lips"],
    ["makeup", "foundation", "highlighter", "blush", "lipstick", "eyeliner", "mascara", "eyeshadow", "facepaint"],
    ["mole", "scar", "bandage", "eyepatch", "sunglasses", "tears"],
    ["pale", "tanned", "bloodless skin"],
  ],
  brows: [
    ["thickbrows", "thinbrows", "softbrows"],
    ["straightbrows", "archedbrows", "vshapedbrows"],
    ["darkbrows", "lightbrows"],
    ["raisedbrows", "furrowedbrows"],
  ],
  "eye-color": [
    ["black eyes", "dark brown eyes", "brown eyes", "light brown eyes", "hazel eyes"],
    ["amber eyes", "gold eyes", "yellow eyes"],
    ["green eyes", "emerald eyes"],
    ["dark blue eyes", "blue eyes", "light blue eyes", "pale blue eyes"],
    ["gray eyes", "silver eyes"],
    ["red eyes", "pink eyes", "purple eyes", "violet eyes"],
    ["heterochromia", "glowing eyes", "dull eyes"],
  ],
  "eye-shape": [
    ["round eyes", "almond eyes", "upturned eyes", "downturned eyes", "fox eyes", "doe eyes", "cat eyes", "sharp eyes", "soft eyes", "gentle eyes"],
    ["large eyes", "small eyes", "wide eyes", "narrow eyes", "large expressive eyes"],
    ["monolid", "double eyelid", "hooded eyes", "droopy eyes", "half-closed eyes", "half-lidded eyes", "closed eyes", "sleepy eyes", "heavy lower eyelids", "heavy upper eyelids", "aegyo sal", "under-eye shadows"],
    ["thick eyelashes", "long eyelashes", "sparse eyelashes", "defined lower eyelashes", "soft eyelashes"],
    ["looking at viewer", "looking away", "looking up", "looking down", "side glance", "emotional gaze", "distant gaze", "gentle gaze"],
    ["sparkling eyes", "teary eyes", "empty eyes", "glass-like eyes", "detailed eyes"],
  ],
  "hair-color": [
    ["black hair", "dark brown hair", "brown hair", "light brown hair", "ash brown hair"],
    ["blonde hair", "platinum blonde", "golden blonde", "strawberry blonde", "ash blonde"],
    ["auburn hair", "red hair", "ginger hair", "orange hair", "copper hair", "burgundy hair"],
    ["white hair", "silver hair", "gray hair"],
    ["pink hair", "hot pink hair"],
    ["blue hair", "light blue hair", "navy hair"],
    ["purple hair", "lavender hair"],
    ["green hair", "mint hair", "teal hair"],
    ["rainbow hair", "multicolored hair", "ombre hair", "gradient hair", "two-tone hair", "dyed hair", "natural hair color"],
  ],
  "hair-style": [
    ["very long hair", "long hair", "medium hair", "short hair"],
    ["bob cut", "pixie cut", "wolf cut", "hime cut", "layered hair", "undercut", "mullet", "buzz cut", "mohawk"],
    ["straight hair", "wavy hair", "curly hair", "coily hair", "afro", "dreadlocks", "spiky hair", "fluffy hair", "messy hair", "silky hair", "shiny hair", "wet hair"],
    ["loose hair", "tied hair", "ponytail", "high ponytail", "low ponytail", "side ponytail", "twintails", "bun", "messy bun", "top knot", "half up"],
    ["braid", "twin braids", "french braid", "fishtail braid"],
    ["blunt bangs", "side bangs", "curtain bangs", "see-through bangs", "no bangs", "center part", "side part"],
    ["ahoge", "sidelocks", "uneven strands", "face-framing strands"],
  ],
  expression: [
    ["calm", "serious", "thoughtful", "serene expression"],
    ["smiling", "softsmile", "gentle smile", "joyful", "laughing", "grinning", "excited"],
    ["sad", "crying", "melancholic expression", "nervous", "shy", "embarrassed", "bored", "sleepy"],
    ["angry", "frowning", "fierce", "determined", "confident", "surprised", "pouting", "smirk", "gentle"],
    ["closedmouth", "openmouth", "tonguesout"],
  ],
  role: [
    ["artist", "musician", "dancer", "idol", "model", "actor", "writer", "poet"],
    ["chef", "barista", "gardener", "librarian", "mechanic", "teacher", "doctor", "nurse", "officeworker", "student"],
    ["scientist", "inventor", "philosopher", "detective", "pilot", "astronaut", "athlete", "traveler", "explorer"],
    ["magician", "witch", "alchemist", "witchdoctor", "shaman", "oracle", "prophet", "priest", "nun", "apprentice"],
    ["hero", "antihero", "villain", "knight", "samurai", "ninja", "mercenary", "assassin", "thief", "pirate", "soldier"],
    ["captain", "general", "king", "queen", "prince", "princess", "emperor", "empress"],
  ],
};

function exactRank(categoryId: string, option: PromptOption): number | undefined {
  const order = exactOrders[categoryId];
  if (!order) return undefined;
  const index = order.indexOf(normalize(option.en));
  return index < 0 ? order.length : index;
}

function semanticRank(categoryId: string, option: PromptOption): number | undefined {
  const groups = semanticGroups[categoryId];
  if (!groups) return undefined;
  const value = normalize(option.en);
  const groupIndex = groups.findIndex((group) => group.includes(value));
  if (groupIndex < 0) return groups.length * 1_000;
  return groupIndex * 1_000 + groups[groupIndex].indexOf(value);
}

export function organizePersonOptions(categories: PromptCategory[]): PromptCategory[] {
  return categories.map((category) => {
    const hasRule = category.id in exactOrders || category.id in semanticGroups;
    if (!hasRule) return category;

    return {
      ...category,
      options: [...category.options].sort((a, b) => {
        const aRank = exactRank(category.id, a) ?? semanticRank(category.id, a) ?? 0;
        const bRank = exactRank(category.id, b) ?? semanticRank(category.id, b) ?? 0;
        return aRank - bRank || a.en.localeCompare(b.en);
      }),
    };
  });
}
