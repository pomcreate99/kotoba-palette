import type { PromptCategory, PromptOption } from "./prompt-data";

type OwnershipRule = {
  source: string;
  target: string;
  terms?: string[];
  allRemaining?: boolean;
};

/**
 * Dictionary-only ownership corrections.
 * Runtime category ids and option ids are deliberately left untouched.
 */
const ownershipRules: OwnershipRule[] = [
  { source: "subject", target: "count", terms: ["solo", "couple", "group", "crowd", "1person", "2people", "multiple people"] },
  { source: "subject", target: "shot-distance", terms: ["headshot", "bust shot", "half body", "full body"] },
  { source: "subject", target: "angle", terms: ["profile view", "three quarter view", "facing viewer", "from behind"] },
  { source: "subject", target: "composition", terms: ["silhouette"] },
  { source: "physique", target: "skin", terms: ["pale skin", "fair skin", "light skin", "medium skin", "olive skin", "tan skin", "tanned skin", "dark skin", "deep skin", "brown skin", "porcelain skin", "smooth skin", "glossy skin", "matte skin", "freckles", "moles", "beauty mark"] },
  { source: "hair", target: "hair-color", terms: ["blonde", "brunette", "silverhair", "redhair", "blackhair", "whitehair", "pinkhair", "bluehair", "purplehair", "greenhair", "orangehair", "ashbrown", "platinum", "two-tone", "gradienthair"] },
  { source: "hair", target: "hair-style", allRemaining: true },
  { source: "hair-detail", target: "hair-style", allRemaining: true },
  { source: "eyes", target: "eye-color", terms: ["amber", "emerald", "violet", "blueeyes", "browneyes", "grey eyes", "redeyes", "heterochromia"] },
  { source: "eyes", target: "eye-shape", allRemaining: true },
  { source: "face-detail", target: "expression", terms: ["smile", "reaction", "exaggerated"] },

  { source: "machines", target: "transport", terms: ["helicopter", "jet"] },
  { source: "machines", target: "object", terms: ["camera", "lens", "tripod", "microphone", "headphones"] },

  { source: "clothing", target: "headwear", terms: ["hat", "hats", "cap", "caps", "beanie", "beret", "fedora", "bonnet", "headdress", "headband", "helmet", "toque", "earmuffs", "goggles on head", "visor"] },
  { source: "clothing", target: "footwear", terms: ["sneaker", "sneakers", "shoe", "shoes", "boot", "boots", "loafer", "loafers", "geta", "zori", "socks", "tights", "leg warmers", "arm warmers", "mary jane"] },
  { source: "clothing", target: "accessory", terms: ["bag", "bags", "backpack", "pouch", "purse", "tote", "suitcase", "luggage", "basket", "case", "belt", "scarf", "gloves", "mittens", "bracelet", "choker", "tie", "badge", "lanyard", "ribbon", "ribbons", "epaulettes", "name tag", "wristlet", "stethoscope", "neck gaiter", "cravat"] },
  { source: "clothing", target: "school-hobby-props", terms: ["bento box", "sketchbook"] },
  { source: "clothing", target: "object", terms: ["thermos", "water bottle"] },
  { source: "clothing", target: "clothing-detail", terms: ["sleeve", "sleeves", "neckline", "collar", "lace", "petticoat", "frill", "frills", "ruffle", "ruffles", "tulle", "organza", "underskirt", "scalloped"] },
  { source: "clothing-detail", target: "clothing", terms: ["tshirt", "blouse", "cardigan", "turtleneck", "vest", "denim", "overalls", "shorts", "trousers", "pleatedskirt", "blazer", "coat", "collaredshirt", "buttonup", "polo", "tanktop", "camisole", "crop top"] },
  { source: "accessory", target: "headwear", terms: ["hat", "crown", "veil"] },
  { source: "accessory-detail", target: "headwear", terms: ["hairpin"] },
  { source: "accessory-detail", target: "accessory", terms: ["bracelet", "brooch", "watch", "ring", "belt", "handbag", "tote", "satchel", "pocketwatch", "badge", "lanyard"] },

  { source: "action", target: "pose", terms: ["sitting", "standing", "kneeling", "crouching", "leaning", "stretching", "sleeping"] },
  { source: "action", target: "gesture", terms: ["waving", "pointing"] },
  { source: "action", target: "interaction", terms: ["kissing", "hugging"] },
  { source: "pose", target: "gesture", terms: ["peace", "shaka", "wave", "pointing", "stop gesture", "come here", "counting on fingers", "crossed fingers", "praying hands", "raised fist", "clenched fist"] },
  { source: "pose", target: "interaction", terms: ["fist bump", "incoming hug"] },
  { source: "pose", target: "hobby-sport", terms: ["kick", "skipping", "dashing", "handstand", "landing", "yoga", "meditation", "bicycle", "puddle jump", "arabesque", "skateboard", "dive pose", "acrobatic", "lunge", "spinning", "twirl", "toe touch", "hip hop", "ballet", "scooter", "roller skate", "float on back", "beach ball"] },

  { source: "camera", target: "shot-distance", terms: ["closeup", "mediumshot", "fullbody", "portrait"] },
  { source: "camera", target: "camera-tech", terms: ["macro", "wideangle", "telephoto", "fisheye", "bokeh", "shallowfocus", "depthoffield"] },
  { source: "camera", target: "composition", terms: ["panorama"] },
  { source: "composition", target: "sky", terms: ["starry sky", "shooting star", "constellation", "aurora"] },
  { source: "composition", target: "optics", terms: ["light particles"] },
  { source: "composition", target: "nature", terms: ["rose petals"] },
  { source: "composition", target: "scenery", terms: ["grand staircase"] },
  { source: "composition", target: "interior", terms: ["mansion interior", "dim cafe interior"] },

  { source: "quality", target: "composition", terms: ["beautiful composition"] },
  { source: "quality", target: "lighting-detail", terms: ["perfect lighting"] },
  { source: "quality", target: "surface", terms: ["texture detail"] },
  { source: "quality", target: "camera-tech", terms: ["sharp focus", "soft focus"] },

  { source: "adult-anatomy", target: "adult-chest", terms: ["topless", "breasts", "cleavage", "nipples", "areolae"] },
  { source: "adult-anatomy", target: "adult-skin", terms: ["skin", "tanlines", "shiny", "glistening", "sweaty", "wetskin", "oiled", "soft", "firm"] },
  { source: "adult-anatomy", target: "adult-body", allRemaining: true },
  { source: "adult-skin", target: "adult-body", terms: ["navel", "torso", "back", "shoulder", "hip", "thigh"] },
  { source: "adult-body", target: "adult-pose", terms: ["arched back"] },
  { source: "adult-pose", target: "adult-scene", terms: ["mirror sex", "bathtub", "shower", "office", "hotel", "hot spring", "changing room", "rooftop", "car backseat", "kitchen", "locker", "fitting room", "elevator", "balcony", "sauna", "medical exam", "under desk", "capsule", "massage table"] },
];

function normalize(value: string): string {
  return value.toLowerCase().replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim();
}

function matchesTerm(option: PromptOption, term: string): boolean {
  const valueTokens = normalize(option.en).split(" ");
  const targetTokens = normalize(term).split(" ");
  if (targetTokens.length === 1) return valueTokens.includes(targetTokens[0]);
  for (let index = 0; index <= valueTokens.length - targetTokens.length; index += 1) {
    if (targetTokens.every((token, offset) => valueTokens[index + offset] === token)) return true;
  }
  return false;
}

function appendUnique(target: PromptCategory, additions: PromptOption[]): PromptCategory {
  if (!additions.length) return target;
  const ids = new Set(target.options.map((option) => option.id));
  const unique = additions.filter((option) => !ids.has(option.id));
  return unique.length ? { ...target, options: [...target.options, ...unique] } : target;
}

export function applyDictionaryCategoryOwnership(categories: PromptCategory[]): PromptCategory[] {
  const order = categories.map((category) => category.id);
  const byId = new Map<string, PromptCategory>(
    categories.map((category): [string, PromptCategory] => [category.id, { ...category, options: [...category.options] }]),
  );

  for (const rule of ownershipRules) {
    const source = byId.get(rule.source);
    const target = byId.get(rule.target);
    if (!source || !target || source.id === target.id) continue;

    const moved = rule.allRemaining
      ? [...source.options]
      : source.options.filter((option) => rule.terms?.some((term) => matchesTerm(option, term)));
    if (!moved.length) continue;

    const movedIds = new Set(moved.map((option) => option.id));
    byId.set(source.id, { ...source, options: source.options.filter((option) => !movedIds.has(option.id)) });
    byId.set(target.id, appendUnique(target, moved));
  }

  return order
    .map((id) => byId.get(id))
    .filter((category): category is PromptCategory => Boolean(category?.options.length));
}
