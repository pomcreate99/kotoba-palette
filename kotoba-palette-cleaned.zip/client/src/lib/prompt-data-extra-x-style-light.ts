/**
 * X research SFW tags (2026-08). Additive only.
 * Do not edit prompt-data.ts.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraXStyleCategory: PromptCategory = {
  id: "style",
  label: "スタイル",
  labelEn: "Style",
  hint: "X調査追加",
  options: words("style", [
    ["clean lineart", "クリーンな線画"],
    ["bold outlines", "太いアウトライン"],
    ["minimal shading", "最小限の陰影"],
    ["simple hatching", "シンプルハッチング"],
    ["gag manga", "ギャグ漫画風"],
    ["cinematic noir", "シネマティックノワール"],
    ["dark romanticism", "ダークロマンティシズム"],
    ["gothic atmosphere", "ゴシックな雰囲気"],
    ["cheerful summer atmosphere", "明るい夏の雰囲気"]
  ]),
};

export const extraXColoringCategory: PromptCategory = {
  id: "coloring",
  label: "塗り",
  labelEn: "Coloring",
  hint: "X調査追加",
  options: words("coloring", [
    ["Dull colors", "くすんだ色調"]
  ]),
};

export const extraXLightingDetailCategory: PromptCategory = {
  id: "lighting-detail",
  label: "照明の細部",
  labelEn: "Lighting detail",
  hint: "X調査追加",
  options: words("lighting-detail", [
    ["noir lighting", "ノワール照明"],
    ["chiaroscuro", "キアロスクーロ"],
    ["tropical daylight", "トロピカルな日光"]
  ]),
};

export const extraXStyleLightCategories: PromptCategory[] = [
  extraXStyleCategory,
  extraXColoringCategory,
  extraXLightingDetailCategory,
];
