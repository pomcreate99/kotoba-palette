/**
 * Prompt Atlas Danbooru/X keyword ingest (2026-08-25), part C (NSFW + avoid).
 * Additive only. Do not edit prompt-data.ts.
 *
 * Skips: existing runtime tags, same-meaning aliases (smile→smiling,
 * spread legs→legs spread), rating tokens nsfw/explicit, loli/shota/
 * toddler/kid/teen/trap/shemale, and already-covered quality/style hits.
 * Hawaiian shirt kept from X research. Classic lolita is fashion, not CSAM.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

const negativeWords = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
    negative: true,
  }));

export const extraGrok20260825AdultGenitalsCategory: PromptCategory = {
  id: "adult-genitals",
  label: "性器・尻",
  labelEn: "Genitals & rear",
  hint: "性器・陰毛・尻の描写",
  mode: "nsfw",
  options: words("adult-genitals", [
    ["pussy", "性器"],
    ["vagina", "膿"],
    ["penis", "ペニス"],
    ["erection", "勃起"],
    ["detailed pussy", "詳細な性器"],
    ["detailed anus", "詳細な肛門"],
    ["no pubic hair", "陰毛なし"],
  ]),
};

export const extraGrok20260825AdultPoseCategory: PromptCategory = {
  id: "adult-pose",
  label: "成人向けポーズ",
  labelEn: "Adult pose",
  hint: "成人の架空人物に限る",
  mode: "nsfw",
  options: words("adult-pose", [
    ["covering breasts", "胸を隠す"],
    ["sex", "性交"],
    ["vaginal", "膿性交"],
    ["anal", "肛門性交"],
    ["oral", "オーラル"],
    ["fellatio", "フェラチオ"],
    ["paizuri", "パイズリ"],
    ["penetration", "挿入"],
    ["deep penetration", "深い挿入"],
    ["pantyshot", "パンチラ"],
    ["upskirt", "スカートの中"],
    ["bondage", "ボンデージ"],
    ["restrained", "拘束された"],
    ["gagged", "口を塞がれた"],
  ]),
};

export const extraGrok20260825AdultReactionCategory: PromptCategory = {
  id: "adult-reaction",
  label: "表情・体液",
  labelEn: "Reaction & fluids",
  hint: "表情・反応・体液の描写",
  mode: "nsfw",
  options: words("adult-reaction", [
    ["pussy juice", "愛液"],
    ["cum", "精液"],
    ["semen", "精液"],
    ["orgasm", "絶頂"],
    ["ecstasy", "恍惚"],
    ["cum in pussy", "膿内射精"],
    ["bukkake", "ぶっかけ"],
    ["cumdrip", "精液が垂れる"],
    ["spit", "唾"],
  ]),
};

export const extraGrok20260825AdultSkinCategory: PromptCategory = {
  id: "adult-skin",
  label: "肌・質感",
  labelEn: "Skin & texture",
  hint: "肌の状態・質感・痕跡",
  mode: "nsfw",
  options: words("adult-skin", [
    ["partially nude", "部分的な裸体"],
    ["sweat", "汗"],
    ["lotion", "ローション"],
  ]),
};

export const extraGrok20260825AdultSceneCategory: PromptCategory = {
  id: "adult-scene",
  label: "成人向け構図",
  labelEn: "Adult framing",
  hint: "成人向けの画面設計",
  mode: "nsfw",
  options: words("adult-scene", [
    ["hip focus", "腰フォーカス"],
    ["ass focus", "尻フォーカス"],
    ["breast focus", "胸フォーカス"],
  ]),
};

export const extraGrok20260825AdultBodyCategory: PromptCategory = {
  id: "adult-body",
  label: "体型・体格",
  labelEn: "Body type",
  hint: "成人の体型・体格・シルエット",
  mode: "nsfw",
  options: words("adult-body", [
    ["futanari", "ふたなり"],
  ]),
};

export const extraGrok20260825AdultWardrobeCategory: PromptCategory = {
  id: "adult-wardrobe",
  label: "成人向け衣類",
  labelEn: "Adult wardrobe",
  hint: "成人向けの衣類・素材",
  mode: "nsfw",
  options: words("adult-wardrobe", [
    ["bdsm", "BDSM"],
  ]),
};

export const extraGrok20260825AvoidCategory: PromptCategory = {
  id: "avoid",
  label: "除外候補",
  labelEn: "Avoid",
  hint: "不要な単語を除外指定にする",
  options: negativeWords("avoid", [
    ["worst quality", "最低品質"],
    ["low quality", "低品質"],
    ["normal quality", "普通の品質"],
    ["bad quality", "悪い品質"],
    ["very displeasing", "非常に不快"],
    ["displeasing", "不快"],
    ["bad anatomy", "悪い人体構造"],
    ["bad hands", "悪い手"],
    ["bad proportions", "悪いプロポーション"],
    ["disfigured", "形の崩れた"],
    ["mutated", "変異した"],
    ["extra limbs", "余分な四肢"],
    ["extra legs", "余分な脚"],
    ["extra fingers", "余分な指"],
    ["missing fingers", "欠けた指"],
    ["fewer digits", "少ない指"],
    ["fused fingers", "癒合した指"],
    ["too many fingers", "多すぎる指"],
    ["long neck", "長い首"],
    ["mutated hands", "変異した手"],
    ["poorly drawn hands", "拙い手"],
    ["poorly drawn face", "拙い顔"],
    ["mutation", "突然変異"],
    ["ugly", "醜い"],
    ["blurry", "ぼやけ"],
    ["jpeg artifacts", "JPEGノイズ"],
    ["signature", "署名"],
    ["username", "ユーザー名"],
    ["artist name", "作家名"],
    ["cut off", "切れている"],
    ["error", "エラー"],
    ["morbid", "病的"],
    ["mutilated", "損傷した"],
    ["gross proportions", "極端なプロポーション"],
    ["bad feet", "悪い足"],
    ["bad legs", "悪い脚"],
    ["fused limbs", "癒合した四肢"],
    ["missing arms", "欠けた腕"],
    ["missing legs", "欠けた脚"],
    ["extra digit", "余分な指の関節"],
    ["mutated hands and fingers", "変異した手と指"],
    ["malformed hands", "奇形の手"],
    ["poorly drawn", "拙い描画"],
    ["amateur", "素人"],
    ["beginner", "初心者"],
    ["unfinished", "未完成"],
    ["incomplete", "不完全"],
  ]),
};

export const extraGrok20260825KeywordCategoriesC: PromptCategory[] = [
  extraGrok20260825AdultGenitalsCategory,
  extraGrok20260825AdultPoseCategory,
  extraGrok20260825AdultReactionCategory,
  extraGrok20260825AdultSkinCategory,
  extraGrok20260825AdultSceneCategory,
  extraGrok20260825AdultBodyCategory,
  extraGrok20260825AdultWardrobeCategory,
  extraGrok20260825AvoidCategory,
];
