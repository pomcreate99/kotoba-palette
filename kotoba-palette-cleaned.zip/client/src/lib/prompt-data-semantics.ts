import type { PromptCategory, PromptOption } from "./prompt-data";
import { promptDedupeKey } from "./prompt-data-integrity";

/**
 * Audited cases where the same English prompt token represents genuinely
 * different concepts depending on category. Categories in the same named
 * group remain globally deduped; different groups are allowed to coexist.
 *
 * Keep this list intentionally explicit. New entries require semantic audit.
 */
const semanticGroups = new Map<string, Readonly<Record<string, string>>>([
  [promptDedupeKey("oiled"), { "adult-skin": "body", "adult-anatomy": "body", surface: "surface" }],
  [promptDedupeKey("back"), { "adult-skin": "body", "adult-anatomy": "body", pose: "pose" }],
  [promptDedupeKey("ripped"), { physique: "body", surface: "surface" }],
  [promptDedupeKey("fragile"), { mood: "mood", surface: "surface" }],
  [promptDedupeKey("polished"), { quality: "quality", surface: "surface" }],
  [promptDedupeKey("pencil"), { "school-hobby-props": "object", object: "object", medium: "medium" }],
  [promptDedupeKey("tall"), { physique: "body", "adult-anatomy": "body", "adult-scene": "scale" }],
  [promptDedupeKey("delicate"), { physique: "body", surface: "surface" }],
  [promptDedupeKey("amber"), { eyes: "eyes", material: "material" }],
  [promptDedupeKey("wide"), { eyes: "eyes", "adult-scene": "scale" }],
  [promptDedupeKey("painting"), { action: "action", scenery: "object" }],
  [promptDedupeKey("hiding"), { action: "action", "adult-pose": "pose" }],
  [promptDedupeKey("bridge"), { setting: "structure", architecture: "structure", scenery: "structure", "adult-pose": "pose" }],
  [promptDedupeKey("lotus"), { nature: "plant", "adult-pose": "pose" }],
  [promptDedupeKey("glass"), { object: "object", material: "material" }],
  [promptDedupeKey("pastel"), { tone: "tone", medium: "medium", style: "style", "art-materials": "medium" }],
  [promptDedupeKey("warm"), { tone: "tone", mood: "mood", "adult-mood": "mood" }],
  [promptDedupeKey("layered"), { composition: "composition", "hair-detail": "hair" }],
  [promptDedupeKey("marble"), { material: "material", patterns: "pattern" }],
  [promptDedupeKey("stone"), { material: "material", patterns: "pattern" }],
  [promptDedupeKey("diamond"), { material: "material", patterns: "pattern" }],
  [promptDedupeKey("intimate"), { mood: "mood", "adult-mood": "mood", placement: "proximity", "adult-scene": "proximity" }],
  [promptDedupeKey("wave"), { water: "water", patterns: "pattern" }],
  [promptDedupeKey("sun"), { sky: "celestial", patterns: "pattern" }],
  [promptDedupeKey("moon"), { sky: "celestial", patterns: "pattern" }],
  [promptDedupeKey("tiger"), { animals: "animal", patterns: "pattern" }],
  [promptDedupeKey("snake"), { animals: "animal", patterns: "pattern" }],
  [promptDedupeKey("mouse"), { animals: "animal", machines: "device" }],
  [promptDedupeKey("giraffe"), { animals: "animal", patterns: "pattern" }],
  [promptDedupeKey("zebra"), { animals: "animal", patterns: "pattern" }],
  [promptDedupeKey("leopard"), { animals: "animal", patterns: "pattern" }],
  [promptDedupeKey("wool"), { material: "material", "creature-features": "fur" }],
  [promptDedupeKey("mosaic"), { patterns: "pattern", "art-materials": "art" }],
  [promptDedupeKey("rough"), { surface: "surface", "adult-mood": "mood" }],
  [promptDedupeKey("short"), { "adult-anatomy": "body", "adult-scene": "scale" }],
]);

/** Identity used by copied/generated prompt output. */
export function promptOutputIdentity(option: PromptOption): string {
  return `${promptDedupeKey(option.en)}:${option.negative ? "negative" : "positive"}`;
}

/**
 * Identity used only by cross-category runtime dedupe. Audited distinct meanings
 * get a semantic suffix while same-meaning category aliases keep sharing one key.
 */
export function promptGlobalDedupeIdentity(category: PromptCategory, option: PromptOption): string {
  const outputIdentity = promptOutputIdentity(option);
  const semanticGroup = semanticGroups.get(promptDedupeKey(option.en))?.[category.id];
  return semanticGroup ? `${outputIdentity}:${semanticGroup}` : outputIdentity;
}
