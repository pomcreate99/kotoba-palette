import { describe, expect, it } from "vitest";
import { categories, type PromptOption } from "./prompt-data";
import { applyPromptOptionIntegrity } from "./prompt-data-integrity";
import { mergeExtraCategories, mergeExtraCategoriesWithAliases } from "./prompt-data-merge";
import { applyPromptCategoryAliases, auditedCategoryAliasEnglish } from "./prompt-category-aliases";
import {
  migrateLegacyFavoriteIds,
  migrateLegacyHistoryItems,
  migrateLegacyOptionContainers,
  migrateLegacyPromptOption,
} from "./prompt-storage-migrations";

function mergedCategories() {
  return mergeExtraCategories(categories);
}

function allOptions() {
  return mergedCategories().flatMap((category) => category.options);
}

function hasOption(categoryId: string, en: string, ja?: string) {
  return mergedCategories().some(
    (category) => category.id === categoryId && category.options.some(
      (option) => option.en === en && (ja === undefined || option.ja === ja),
    ),
  );
}

describe("prompt tag integrity", () => {
  it("keeps the two audited whitespace-sensitive concepts distinct", () => {
    const options = allOptions();
    expect(options.some((option) => option.en === "cow girl" && option.ja === "牛娘")).toBe(true);
    expect(options.some((option) => option.en === "cowgirl")).toBe(true);
    expect(options.some((option) => option.en === "fish tail" && option.ja === "魚の尾")).toBe(true);
    expect(options.some((option) => option.en === "fishtail" && option.ja === "フィッシュテール")).toBe(true);
  });

  it("preserves negative variants even when the same English tag exists positively", () => {
    const merged = mergedCategories();
    const negative = merged.flatMap((category) => category.options).filter((option) => option.negative);
    expect(negative).toHaveLength(59);

    for (const en of ["blur", "cropped", "noise", "frame"]) {
      expect(negative.some((option) => option.en === en)).toBe(true);
      expect(merged.some((category) => category.id !== "avoid" && category.options.some((option) => option.en === en && !option.negative))).toBe(true);
    }
  });

  it("preserves audited same-English concepts without expanding same-meaning aliases", () => {
    expect(hasOption("object", "glass", "グラス")).toBe(true);
    expect(hasOption("material", "glass", "ガラス")).toBe(true);

    expect(hasOption("physique", "ripped", "筋肉が浮き出た")).toBe(true);
    expect(hasOption("surface", "ripped", "裂け")).toBe(true);

    expect(hasOption("school-hobby-props", "pencil", "鉛筆")).toBe(true);
    expect(hasOption("medium", "pencil", "鉛筆画")).toBe(true);
    expect(hasOption("object", "pencil", "鉛筆")).toBe(false);

    expect(hasOption("setting", "bridge", "橋")).toBe(true);
    expect(hasOption("adult-pose", "bridge", "ブリッジ")).toBe(true);
    expect(hasOption("architecture", "bridge", "橋梁")).toBe(false);
    expect(hasOption("scenery", "bridge", "橋")).toBe(false);

    expect(hasOption("art-materials", "pastel", "パステル画材")).toBe(true);
    expect(hasOption("tone", "pastel", "パステル")).toBe(true);
    expect(hasOption("style", "pastel", "パステル風")).toBe(true);
    expect(hasOption("medium", "pastel", "パステル")).toBe(false);

    expect(hasOption("tone", "warm", "暖色")).toBe(true);
    expect(hasOption("mood", "warm", "温かい")).toBe(true);
    expect(hasOption("adult-mood", "warm", "温かい")).toBe(false);

    expect(hasOption("animals", "mouse", "鼠")).toBe(true);
    expect(hasOption("machines", "mouse", "マウス")).toBe(true);
  });

  it("restores all audited semantic groups while keeping existing winner ids stable", () => {
    const expectedGroups: Array<[string, string[]]> = [
      ["oiled", ["adult-skin", "surface"]],
      ["back", ["adult-skin", "pose"]],
      ["ripped", ["physique", "surface"]],
      ["fragile", ["mood", "surface"]],
      ["polished", ["quality", "surface"]],
      ["pencil", ["school-hobby-props", "medium"]],
      ["tall", ["physique", "adult-scene"]],
      ["delicate", ["physique", "surface"]],
      ["amber", ["material", "eyes"]],
      ["wide", ["eyes", "adult-scene"]],
      ["painting", ["action", "scenery"]],
      ["hiding", ["action", "adult-pose"]],
      ["bridge", ["setting", "adult-pose"]],
      ["lotus", ["nature", "adult-pose"]],
      ["glass", ["object", "material"]],
      ["pastel", ["art-materials", "tone", "style"]],
      ["warm", ["tone", "mood"]],
      ["layered", ["composition", "hair-detail"]],
      ["marble", ["material", "patterns"]],
      ["stone", ["material", "patterns"]],
      ["diamond", ["material", "patterns"]],
      ["intimate", ["mood", "placement"]],
      ["wave", ["water", "patterns"]],
      ["sun", ["sky", "patterns"]],
      ["moon", ["sky", "patterns"]],
      ["tiger", ["animals", "patterns"]],
      ["snake", ["animals", "patterns"]],
      ["mouse", ["animals", "machines"]],
      ["giraffe", ["animals", "patterns"]],
      ["zebra", ["animals", "patterns"]],
      ["leopard", ["animals", "patterns"]],
      ["wool", ["material", "creature-features"]],
      ["mosaic", ["art-materials", "patterns"]],
      ["rough", ["surface", "adult-mood"]],
      ["short", ["adult-scene", "adult-anatomy"]],
    ];

    const merged = mergedCategories();
    for (const [en, categoryIds] of expectedGroups) {
      const present = merged
        .filter((category) => category.options.some((option) => option.en === en && !option.negative))
        .map((category) => category.id);
      expect(new Set(present), en).toEqual(new Set(categoryIds));
    }

    expect(hasOption("object", "glass")).toBe(true);
    expect(hasOption("tone", "warm")).toBe(true);
    expect(hasOption("setting", "bridge")).toBe(true);
    expect(hasOption("art-materials", "pastel")).toBe(true);
  });

  it("keeps all 74 audited category aliases as references instead of runtime duplicates", () => {
    expect(auditedCategoryAliasEnglish).toHaveLength(74);
    expect(new Set(auditedCategoryAliasEnglish).size).toBe(74);

    const merged = mergeExtraCategoriesWithAliases(categories);
    const runtime = merged.categories;
    const aliasedView = applyPromptCategoryAliases(runtime, runtime, merged.categoryAliasOptionIds);

    const find = (source: typeof runtime, categoryId: string, en: string) => source
      .find((category) => category.id === categoryId)?.options.find((option) => option.en === en);

    const templeSetting = find(aliasedView, "setting", "temple");
    const templeArchitecture = find(aliasedView, "architecture", "temple");
    expect(templeSetting).toBeDefined();
    expect(templeArchitecture?.id).toBe(templeSetting?.id);

    const watercolorMedium = find(aliasedView, "medium", "watercolor");
    const watercolorStyle = find(aliasedView, "style", "watercolor");
    expect(watercolorMedium).toBeDefined();
    expect(watercolorStyle?.id).toBe(watercolorMedium?.id);

    const socksFootwear = find(aliasedView, "footwear", "socks");
    const socksAdultWardrobe = find(aliasedView, "adult-wardrobe", "socks");
    expect(socksFootwear).toBeDefined();
    expect(socksAdultWardrobe?.id).toBe(socksFootwear?.id);

    const phoenixAnimals = find(aliasedView, "animals", "phoenix");
    const phoenixSpecies = find(aliasedView, "species", "phoenix");
    expect(phoenixAnimals).toBeDefined();
    expect(phoenixSpecies?.id).toBe(phoenixAnimals?.id);

    const leatherMaterial = find(aliasedView, "material", "leather");
    const leatherWardrobe = find(aliasedView, "adult-wardrobe", "leather");
    expect(leatherMaterial).toBeDefined();
    expect(leatherWardrobe?.id).toBe(leatherMaterial?.id);

    const lampObject = find(aliasedView, "object", "lamp");
    const lampScenery = find(aliasedView, "scenery", "lamp");
    expect(lampObject?.id).toBe("object-lamp");
    expect(lampScenery?.id).toBe(lampObject?.id);

    const balconySetting = find(aliasedView, "setting", "balcony");
    const balconyArchitecture = find(aliasedView, "architecture", "balcony");
    const balconyInterior = find(aliasedView, "interior", "balcony");
    expect(balconyInterior?.id).toBe("interior-balcony");
    expect(balconySetting?.id).toBe(balconyInterior?.id);
    expect(balconyArchitecture?.id).toBe(balconyInterior?.id);

    expect(runtime.flatMap((category) => category.options)).toHaveLength(5368);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "balony")).toHaveLength(0);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "balcony")).toHaveLength(1);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "lamp")).toHaveLength(1);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "leather")).toHaveLength(1);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "leather texture")).toHaveLength(1);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "socks")).toHaveLength(1);
    expect(runtime.flatMap((category) => category.options).filter((option) => option.en === "temple")).toHaveLength(1);
  });

  it("applies only high-confidence runtime label corrections while preserving ids", () => {
    const options = allOptions();

    const greyEyes = options.find((option) => option.id === "eyes-greyeneyes");
    expect(greyEyes?.en).toBe("grey eyes");
    expect(greyEyes?.ja).toBe("灰色の目");

    const dragonSpirit = options.find((option) => option.en === "dragon spirit");
    expect(dragonSpirit?.id).toContain("dragonsprit");
    expect(dragonSpirit?.ja).toBe("龍の精霊");

    const practicalLighting = options.find((option) => option.id === "lighting-detail-practicalight");
    expect(practicalLighting?.en).toBe("practical lighting");
    expect(practicalLighting?.ja).toBe("実用照明");

    const balconette = options.find((option) => option.en === "balconette");
    expect(balconette?.ja).toBe("バルコネットブラ");

    const correctedBalony = applyPromptOptionIntegrity({ id: "setting-balony", en: "balony", ja: "バルコニー" });
    expect(correctedBalony.en).toBe("balcony");
    expect(correctedBalony.ja).toBe("バルコニー");
    expect(correctedBalony.id).toBe("setting-balony");

    const fallingLeaves = options.find((option) => option.id === "optics-leaves");
    expect(fallingLeaves?.en).toBe("falling leaves");
    expect(fallingLeaves?.ja).toBe("葉舞い");
    expect(fallingLeaves?.id).toBe("optics-leaves");

    const fallingPetals = options.find((option) => option.id === "optics-petals");
    expect(fallingPetals?.en).toBe("falling petals");
    expect(fallingPetals?.ja).toBe("花びら舞い");
    expect(fallingPetals?.id).toBe("optics-petals");

    const westernPainting = options.find((option) => option.id === "style-yoga");
    expect(westernPainting?.en).toBe("western-style painting");
    expect(westernPainting?.ja).toBe("洋画風");
    expect(westernPainting?.id).toBe("style-yoga");

    const privateRoom = options.find((option) => option.id === "adult-scene-private");
    expect(privateRoom?.en).toBe("private room");
    expect(privateRoom?.ja).toBe("私室");
    expect(privateRoom?.id).toBe("adult-scene-private");

    const westernHouse = options.find((option) => option.id === "architecture-mansion");
    expect(westernHouse?.en).toBe("western-style house");
    expect(westernHouse?.ja).toBe("洋館");
    expect(westernHouse?.id).toBe("architecture-mansion");

    const leatherTexture = options.find((option) => option.id === "patterns-leather");
    expect(leatherTexture?.en).toBe("leather texture");
    expect(leatherTexture?.ja).toBe("レザー柄");
    expect(leatherTexture?.id).toBe("patterns-leather");

    expect(hasOption("nature", "leaves", "葉")).toBe(true);
    expect(hasOption("nature", "petals", "花びら")).toBe(true);
    expect(hasOption("optics", "falling leaves", "葉舞い")).toBe(true);
    expect(hasOption("optics", "falling petals", "花びら舞い")).toBe(true);
    expect(hasOption("pose", "yoga", "ヨガポーズ")).toBe(true);
    expect(hasOption("adult-mood", "private", "私的")).toBe(true);
    expect(hasOption("setting", "mansion", "豪邸")).toBe(true);
    expect(hasOption("material", "leather", "革")).toBe(true);
    expect(hasOption("patterns", "leather texture", "レザー柄")).toBe(true);
  });

  it("migrates legacy balony favorites, history and presets to the canonical balcony id", () => {
    expect(migrateLegacyFavoriteIds(["setting-balony", "interior-balcony", "object-lamp"]))
      .toEqual(["interior-balcony", "object-lamp"]);

    const migratedOption = migrateLegacyPromptOption({ id: "setting-balony", en: "balony", ja: "バルコニー" });
    expect(migratedOption).toEqual({ id: "interior-balcony", en: "balcony", ja: "バルコニー" });

    const history = migrateLegacyHistoryItems([{
      id: "history-1",
      prompt: "balony, night",
      negativePrompt: "",
      options: [
        { id: "setting-balony", en: "balony", ja: "バルコニー" },
        { id: "time-night", en: "night", ja: "夜" },
      ],
      createdAt: "legacy",
    }]);
    expect(history[0]?.options[0]?.id).toBe("interior-balcony");
    expect(history[0]?.prompt).toBe("balcony, night");

    const presets = migrateLegacyOptionContainers([{
      id: "preset-1",
      name: "legacy",
      options: [{ id: "setting-balony", en: "balony", ja: "バルコニー", negative: true }],
    }]);
    expect(presets[0]?.options[0]).toMatchObject({
      id: "interior-balcony",
      en: "balcony",
      ja: "バルコニー",
      negative: true,
    });
  });

  it("repairs category-specific corrupted labels without changing unrelated meanings", () => {
    const adultPose: PromptOption = { id: "adult-pose-onkneesoral", en: "on knees oral", ja: "膝立ちで口 technic" };
    expect(applyPromptOptionIntegrity(adultPose).ja).toBe("膝立ちでオーラル");

    const adultMoodSticky: PromptOption = { id: "adult-mood-sticky", en: "sticky", ja: " sticky" };
    expect(applyPromptOptionIntegrity(adultMoodSticky).ja).toBe("べたつく");

    const surfaceSticky: PromptOption = { id: "surface-sticky", en: "sticky", ja: "粘着" };
    expect(applyPromptOptionIntegrity(surfaceSticky).ja).toBe("粘着");

    const adultMoodTender: PromptOption = { id: "adult-mood-tender", en: "tender", ja: " tender" };
    expect(applyPromptOptionIntegrity(adultMoodTender).ja).toBe("優しい");
  });

  it("clarifies audited category-specific Japanese labels without changing English tags", () => {
    const spooning: PromptOption = { id: "adult-pose-spooning", en: "spooning", ja: "スプーン" };
    const correctedSpooning = applyPromptOptionIntegrity(spooning);
    expect(correctedSpooning.en).toBe("spooning");
    expect(correctedSpooning.ja).toBe("側位（スプーニング）");
    expect(correctedSpooning.id).toBe(spooning.id);

    const profile: PromptOption = { id: "pose-profile", en: "profile", ja: "横向き" };
    const correctedProfile = applyPromptOptionIntegrity(profile);
    expect(correctedProfile.en).toBe("profile");
    expect(correctedProfile.ja).toBe("横顔");

    const effectGrain: PromptOption = { id: "effect-grain", en: "grain", ja: "粒子" };
    expect(applyPromptOptionIntegrity(effectGrain).ja).toBe("粒状感");

    const adultSceneGrain: PromptOption = { id: "adult-scene-grain", en: "grain", ja: "粒子" };
    expect(applyPromptOptionIntegrity(adultSceneGrain).ja).toBe("粒状感");

    const particles: PromptOption = { id: "effect-particles", en: "particles", ja: "粒子" };
    expect(applyPromptOptionIntegrity(particles).ja).toBe("粒子");
  });

  it("disambiguates Japanese labels that previously hid distinct concepts", () => {
    const parents: PromptOption = { id: "relationships-parents", en: "parents", ja: "保護者" };
    expect(applyPromptOptionIntegrity(parents).ja).toBe("両親");

    const guardian: PromptOption = { id: "relationships-guardian", en: "guardian", ja: "保護者" };
    expect(applyPromptOptionIntegrity(guardian).ja).toBe("保護者");

    const natureMist: PromptOption = { id: "nature-mist", en: "mist", ja: "霞" };
    expect(applyPromptOptionIntegrity(natureMist).ja).toBe("薄霧");

    const opticsMist: PromptOption = { id: "optics-mist", en: "mist", ja: "霞効果" };
    expect(applyPromptOptionIntegrity(opticsMist).ja).toBe("薄霧効果");

    const haze: PromptOption = { id: "optics-haze", en: "haze", ja: "霞" };
    expect(applyPromptOptionIntegrity(haze).ja).toBe("霞");

    const frosted: PromptOption = { id: "surface-frosted", en: "frosted", ja: "曇り" };
    expect(applyPromptOptionIntegrity(frosted).ja).toBe("フロスト加工");

    const cloudy: PromptOption = { id: "sky-cloudy", en: "cloudy", ja: "曇り" };
    expect(applyPromptOptionIntegrity(cloudy).ja).toBe("曇り");

    const engraved: PromptOption = { id: "surface-engraved", en: "engraved", ja: "彫刻" };
    expect(applyPromptOptionIntegrity(engraved).ja).toBe("彫り込み");

    const sculpture: PromptOption = { id: "medium-sculpture", en: "sculpture", ja: "彫刻" };
    expect(applyPromptOptionIntegrity(sculpture).ja).toBe("彫刻");
  });

  it("normalizes verified generic display labels without changing prompt tags", () => {
    const handFan: PromptOption = { id: "accessory-handfan", en: "hand fan", ja: "扇子" };
    const correctedHandFan = applyPromptOptionIntegrity(handFan);
    expect(correctedHandFan.en).toBe("hand fan");
    expect(correctedHandFan.ja).toBe("手持ち扇");
    expect(correctedHandFan.id).toBe(handFan.id);

    const cleavage: PromptOption = { id: "adult-anatomy-cleavage", en: "cleavage", ja: "胸元" };
    const correctedCleavage = applyPromptOptionIntegrity(cleavage);
    expect(correctedCleavage.en).toBe("cleavage");
    expect(correctedCleavage.ja).toBe("胸の谷間");
    expect(correctedCleavage.id).toBe(cleavage.id);
  });

  it("adds adult-usable 1girl/1boy and furry tags without reclassifying youth boy/girl", () => {
    expect(hasOption("count", "1girl", "女性1人")).toBe(true);
    expect(hasOption("count", "1boy", "男性1人")).toBe(true);
    expect(hasOption("count", "2girls", "女性2人")).toBe(true);
    expect(hasOption("count", "2boys", "男性2人")).toBe(true);
    expect(hasOption("species", "fox girl", "狐娘")).toBe(true);
    expect(hasOption("species", "wolf girl", "狼娘")).toBe(true);
    expect(hasOption("species", "cat boy", "猫男子")).toBe(true);
    expect(hasOption("species", "anthro", "アントロ")).toBe(true);
    expect(hasOption("creature-features", "white fur", "白い体毛")).toBe(true);
    expect(hasOption("hair-style", "full bangs", "フルバング")).toBe(true);
    expect(hasOption("pose", "empty hands", "手ぶら")).toBe(true);
    expect(hasOption("accessory", "white gloves", "白手袋")).toBe(true);
    const options = allOptions();
    expect(options.some((option) => option.en === "cat boy" && option.ja === "猫少年")).toBe(false);
    expect(hasOption("demographics", "boy", "男の子")).toBe(true);
    expect(hasOption("demographics", "girl", "女の子")).toBe(true);
    const boy = options.find((option) => option.en === "boy" && option.ja === "男の子");
    const girl = options.find((option) => option.en === "girl" && option.ja === "女の子");
    expect(boy?.audience).toBe("youth");
    expect(girl?.audience).toBe("youth");
  });

  it("adds Prompt Atlas style/coloring/medium tags without stealing pastel or existing aliases", () => {
    expect(hasOption("coloring", "soft colors", "ソフトカラー")).toBe(true);
    expect(hasOption("coloring", "pastel pink", "パステルピンク")).toBe(true);
    expect(hasOption("coloring", "manga coloring", "漫画塗り")).toBe(true);
    expect(hasOption("coloring", "flat shading", "フラット陰影")).toBe(true);
    expect(hasOption("medium", "palette knife", "パレットナイフ")).toBe(true);
    expect(hasOption("medium", "oil pastel", "オイルパステル")).toBe(true);
    expect(hasOption("medium", "poster paint", "ポスターカラー")).toBe(true);
    expect(hasOption("style", "ligne claire", "リーニュクレール")).toBe(true);
    expect(hasOption("style", "yume kawaii", "ゆめかわいい")).toBe(true);
    expect(hasOption("style", "graphic novel style", "グラフィックノベル風")).toBe(true);
    expect(hasOption("surface", "paper texture", "紙の質感")).toBe(true);
    expect(hasOption("optics", "soft atmospheric haze", "柔らかい大気の霞")).toBe(true);
    expect(hasOption("skin", "subsurface skin warmth", "肌のサブサーフェス温み")).toBe(true);
    expect(hasOption("setting", "warm beige paper background", "温かいベージ紙背景")).toBe(true);
    expect(hasOption("medium", "pastel", "パステル")).toBe(false);
    expect(hasOption("art-materials", "pastel", "パステル画材")).toBe(true);
    expect(hasOption("coloring", "flat color")).toBe(false);
    expect(hasOption("style", "pop art")).toBe(false);
    expect(hasOption("style", "popart", "ポップアート")).toBe(true);
  });

  it("adds Danbooru/X keyword ingest tags without restoring skipped rating or alias forms", () => {
    expect(hasOption("quality", "score_9", "スコア9")).toBe(true);
    expect(hasOption("quality", "great quality", "とても高い品質")).toBe(true);
    expect(hasOption("quality", "sensitive", "センシティブ")).toBe(true);
    expect(hasOption("quality", "nsfw")).toBe(false);
    expect(hasOption("quality", "explicit")).toBe(false);
    expect(hasOption("count", "3girls", "女性3人")).toBe(true);
    expect(hasOption("count", "male focus", "男性フォーカス")).toBe(true);
    expect(hasOption("eye-shape", "tsurime", "つり目")).toBe(true);
    expect(hasOption("expression", "doyagao", "ドヤ顔")).toBe(true);
    expect(hasOption("expression", "smile")).toBe(false);
    expect(hasOption("expression", "smiling", "微笑み")).toBe(true);
    expect(hasOption("clothing", "hawaiian shirt", "アロハシャツ")).toBe(true);
    expect(hasOption("clothing", "classic lolita", "クラシックロリータ")).toBe(true);
    expect(hasOption("headwear", "witch hat", "魔女帽")).toBe(true);
    expect(hasOption("world", "yuri", "百合")).toBe(true);
    expect(hasOption("adult-body", "futanari", "ふたなり")).toBe(true);
    expect(hasOption("adult-genitals", "penis", "ペニス")).toBe(true);
    expect(hasOption("adult-pose", "sex", "性交")).toBe(true);
    expect(hasOption("adult-pose", "spread legs")).toBe(false);
    expect(hasOption("adult-pose", "legs spread", "脚を開く")).toBe(true);
    expect(hasOption("avoid", "worst quality", "最低品質")).toBe(true);
    expect(hasOption("avoid", "bad anatomy", "悪い人体構造")).toBe(true);
  });

  it("updates the runtime inventory only by the audited semantic restorations and typo dedupe", () => {
    const merged = mergedCategories();
    const all = merged.flatMap((category) => category.options);
    const sfw = merged.filter((category) => category.mode !== "nsfw").flatMap((category) => category.options);
    const nsfw = merged.filter((category) => category.mode === "nsfw").flatMap((category) => category.options);

    expect(all).toHaveLength(5368);
    expect(sfw).toHaveLength(4070);
    expect(nsfw).toHaveLength(1298);
    expect(all.filter((option) => option.negative)).toHaveLength(59);
  });
});
