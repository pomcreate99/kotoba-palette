/**
 * X research SFW tags (2026-08). Additive only.
 * Do not edit prompt-data.ts.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraXHairStyleCategory: PromptCategory = {
  id: "hair-style",
  label: "髪型",
  labelEn: "Hair style",
  hint: "X調査追加",
  options: words("hair-style", [
    ["inner white", "インナーホワイト"],
    ["center-parted curtain bangs", "センター分けカーテンバング"],
    ["soft feathered layers", "ソフトフェザーレイヤー"],
    ["airy fluffy volume", "エアリーふわボリューム"],
    ["korean idol hairstyle", "韓国アイドルヘア"],
    ["black and white gradient hair", "白黒グラデーション髪"],
    ["icy silver hair", "アイシーシルバー髪"],
    ["medium-length layered black hair", "ミディアムレイヤー黒髪"],
    ["center-parted layered hairstyle", "センター分けレイヤー"],
    ["soft curtain bangs", "ソフトカーテンバング"],
    ["hair touching the nape", "うなじにかかる髪"],
    ["neck-length back hair", "うなじ丈の後ろ髪"],
    ["stylish wavy black long hair", "スタイリッシュウェーブ黒髪ロング"],
    ["stylish bangs", "スタイリッシュ前髪"],
    ["center-parted bangs", "センター分け前髪"],
    ["messy side bangs", "乱れたサイドバング"],
    ["fluffy bangs", "ふわふわ前髪"],
    ["full bangs", "フルバング"],
  ]),
};

export const extraXHairColorCategory: PromptCategory = {
  id: "hair-color",
  label: "髪色",
  labelEn: "Hair color",
  hint: "X調査追加",
  options: words("hair-color", [
    ["silver hair with subtle blue tint", "青みのある銀髪"]
  ]),
};

export const extraXEyeShapeCategory: PromptCategory = {
  id: "eye-shape",
  label: "目の形",
  labelEn: "Eye shape",
  hint: "X調査追加",
  options: words("eye-shape", [
    ["vertically slit pupils", "縦長スリット瞳"],
    ["almond-shaped eyes", "アーモンド型の目"],
    ["heart shaped pupils", "ハート型の瞳孔"]
  ]),
};

export const extraXEyeColorCategory: PromptCategory = {
  id: "eye-color",
  label: "瞳色",
  labelEn: "Eye color",
  hint: "X調査追加",
  options: words("eye-color", [
    ["charcoal gray eyes", "チャコールグレーの目"],
    ["deep sea-blue eyes", "ディープシーブルーの目"]
  ]),
};

export const extraXFaceDetailCategory: PromptCategory = {
  id: "face-detail",
  label: "顔の細部",
  labelEn: "Face detail",
  hint: "X調査追加",
  options: words("face-detail", [
    ["double eyelids", "二重まぶた"],
    ["mole under the right eye", "右目の下のほくろ"],
    ["refined sharp facial features", "シャープな整った顔立ち"],
    ["defined jawline", "はっきりした顎のライン"],
    ["full lips", "ふっくらした唇"],
    ["straight nose", "ストレート鼻"],
    ["reaction face", "リアクション顔"],
    ["exaggerated face", "誇張した顔"],
    ["enigmatic smile", "謎めいた笑み"],
    ["soft smiling", "柔らかい笑顔"],
    ["parted lips", "少し開いた唇"],
    ["cheerful smile", "明るい笑顔"],
    ["seductive smile", "色っぽい笑顔"],
    ["light smile", "薄い微笑み"]
  ]),
};

export const extraXSkinCategory: PromptCategory = {
  id: "skin",
  label: "肌",
  labelEn: "Skin",
  hint: "X調査追加",
  options: words("skin", [
    ["pale flawless skin", "青白く無瑕の肌"]
  ]),
};

export const extraXPhysiqueCategory: PromptCategory = {
  id: "physique",
  label: "体型",
  labelEn: "Physique",
  hint: "X調査追加",
  options: words("physique", [
    ["lean toned physique", "引き締まった細マッチョ体型"],
    ["lean athletic physique", "しなやかなアスリート体型"],
    ["defined collarbones", "くっきりした鎖骨"]
  ]),
};

export const extraXHairFaceCategories: PromptCategory[] = [
  extraXHairStyleCategory,
  extraXHairColorCategory,
  extraXEyeShapeCategory,
  extraXEyeColorCategory,
  extraXFaceDetailCategory,
  extraXSkinCategory,
  extraXPhysiqueCategory,
];
