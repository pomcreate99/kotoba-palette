import { describe, expect, it } from "vitest";
import { categories } from "./prompt-data";
import { applyPromptCategoryAliases } from "./prompt-category-aliases";
import { mergeExtraCategoriesWithAliases } from "./prompt-data-merge";

function buildDictionaryView() {
  const merged = mergeExtraCategoriesWithAliases(categories);
  return {
    runtime: merged.categories,
    view: applyPromptCategoryAliases(merged.categories, merged.categories, merged.categoryAliasOptionIds),
  };
}

function has(view: ReturnType<typeof buildDictionaryView>["view"], categoryId: string, en: string) {
  return Boolean(view.find((category) => category.id === categoryId)?.options.some((option) => option.en === en));
}

function idsIn(view: ReturnType<typeof buildDictionaryView>["view"], categoryIds: string[]) {
  const allowed = new Set(categoryIds);
  return new Set(view.filter((category) => allowed.has(category.id)).flatMap((category) => category.options.map((option) => option.id)));
}

describe("dictionary category ownership", () => {
  it("changes only dictionary ownership, never the runtime inventory", () => {
    const { runtime } = buildDictionaryView();
    expect(runtime.flatMap((category) => category.options)).toHaveLength(5368);
  });

  it("keeps Wardrobe sibling categories responsible for their own item types", () => {
    const { view } = buildDictionaryView();

    expect(has(view, "clothing", "chinstrap hat")).toBe(false);
    expect(has(view, "headwear", "chinstrap hat")).toBe(true);
    expect(has(view, "clothing", "hiking sneakers")).toBe(false);
    expect(has(view, "footwear", "hiking sneakers")).toBe(true);
    expect(has(view, "clothing", "crossbody bag")).toBe(false);
    expect(has(view, "accessory", "crossbody bag")).toBe(true);
    expect(has(view, "clothing", "square neckline")).toBe(false);
    expect(has(view, "clothing-detail", "square neckline")).toBe(true);

    expect(has(view, "clothing-detail", "tshirt")).toBe(false);
    expect(has(view, "clothing", "tshirt")).toBe(true);
    expect(has(view, "accessory-detail", "handbag")).toBe(false);
    expect(has(view, "accessory", "handbag")).toBe(true);

    // Exact-token ownership: `cap` must never steal `capelet`.
    expect(has(view, "clothing", "capelet")).toBe(true);
    expect(has(view, "headwear", "capelet")).toBe(false);
  });

  it("removes legacy People buckets once dedicated categories own the concepts", () => {
    const { runtime, view } = buildDictionaryView();

    expect(has(view, "subject", "solo")).toBe(false);
    expect(has(view, "count", "solo")).toBe(true);
    expect(has(view, "subject", "headshot")).toBe(false);
    expect(has(view, "shot-distance", "headshot")).toBe(true);
    expect(has(view, "physique", "pale skin")).toBe(false);
    expect(has(view, "skin", "pale skin")).toBe(true);

    const legacyHairIds = runtime
      .filter((category) => category.id === "hair" || category.id === "hair-detail")
      .flatMap((category) => category.options.map((option) => option.id));
    const hairOwners = idsIn(view, ["hair-color", "hair-style"]);
    expect(view.some((category) => category.id === "hair")).toBe(false);
    expect(view.some((category) => category.id === "hair-detail")).toBe(false);
    expect(legacyHairIds.every((id) => hairOwners.has(id))).toBe(true);

    const legacyEyeIds = runtime.find((category) => category.id === "eyes")?.options.map((option) => option.id) ?? [];
    const eyeOwners = idsIn(view, ["eye-color", "eye-shape"]);
    expect(view.some((category) => category.id === "eyes")).toBe(false);
    expect(legacyEyeIds.every((id) => eyeOwners.has(id))).toBe(true);
  });

  it("keeps Action and Pose from swallowing sibling Motion concepts", () => {
    const { view } = buildDictionaryView();

    expect(has(view, "action", "standing")).toBe(false);
    expect(has(view, "pose", "standing")).toBe(true);
    expect(has(view, "action", "waving")).toBe(false);
    expect(has(view, "gesture", "waving")).toBe(true);
    expect(has(view, "action", "kissing")).toBe(false);
    expect(has(view, "interaction", "kissing")).toBe(true);

    expect(has(view, "pose", "peace")).toBe(false);
    expect(has(view, "gesture", "peace")).toBe(true);
    expect(has(view, "pose", "acrobatic pose")).toBe(false);
    expect(has(view, "hobby-sport", "acrobatic pose")).toBe(true);
  });

  it("retires the legacy Camera bucket into dedicated framing categories", () => {
    const { runtime, view } = buildDictionaryView();
    const legacyCameraIds = runtime.find((category) => category.id === "camera")?.options.map((option) => option.id) ?? [];
    const cameraOwners = idsIn(view, ["shot-distance", "camera-tech", "composition"]);

    expect(view.some((category) => category.id === "camera")).toBe(false);
    expect(legacyCameraIds.every((id) => cameraOwners.has(id))).toBe(true);
    expect(has(view, "composition", "mansion interior")).toBe(false);
    expect(has(view, "interior", "mansion interior")).toBe(true);
  });

  it("keeps Quality limited to quality rather than dedicated controls", () => {
    const { view } = buildDictionaryView();

    expect(has(view, "quality", "beautiful composition")).toBe(false);
    expect(has(view, "composition", "beautiful composition")).toBe(true);
    expect(has(view, "quality", "perfect lighting")).toBe(false);
    expect(has(view, "lighting-detail", "perfect lighting")).toBe(true);
    expect(has(view, "quality", "sharp focus")).toBe(false);
    expect(has(view, "camera-tech", "sharp focus")).toBe(true);
  });

  it("uses split NSFW categories instead of the old adult-anatomy catch-all", () => {
    const { runtime, view } = buildDictionaryView();
    const legacyAnatomyIds = runtime.find((category) => category.id === "adult-anatomy")?.options.map((option) => option.id) ?? [];
    const anatomyOwners = idsIn(view, ["adult-body", "adult-chest", "adult-skin"]);

    expect(view.some((category) => category.id === "adult-anatomy")).toBe(false);
    expect(legacyAnatomyIds.every((id) => anatomyOwners.has(id))).toBe(true);

    expect(has(view, "adult-skin", "navel")).toBe(false);
    expect(has(view, "adult-body", "navel")).toBe(true);
    expect(has(view, "adult-pose", "hotel room sex")).toBe(false);
    expect(has(view, "adult-scene", "hotel room sex")).toBe(true);
  });

  it("places new furry and danbooru count tags in their owner categories", () => {
    const { view } = buildDictionaryView();

    expect(has(view, "count", "1girl")).toBe(true);
    expect(has(view, "count", "1boy")).toBe(true);
    expect(has(view, "species", "fox girl")).toBe(true);
    expect(has(view, "species", "cat boy")).toBe(true);
    expect(has(view, "accessory", "white gloves")).toBe(true);
    expect(has(view, "hair-style", "full bangs")).toBe(true);
    expect(has(view, "creature-features", "white fur")).toBe(true);
    expect(has(view, "demographics", "boy")).toBe(true);
    expect(has(view, "demographics", "girl")).toBe(true);
    expect(has(view, "style", "ligne claire")).toBe(true);
    expect(has(view, "coloring", "soft colors")).toBe(true);
    expect(has(view, "medium", "oil pastel")).toBe(true);
    expect(has(view, "surface", "paper texture")).toBe(true);
    expect(has(view, "count", "3girls")).toBe(true);
    expect(has(view, "clothing", "hawaiian shirt")).toBe(true);
    expect(has(view, "headwear", "witch hat")).toBe(true);
    expect(has(view, "adult-body", "futanari")).toBe(true);
  });
});
