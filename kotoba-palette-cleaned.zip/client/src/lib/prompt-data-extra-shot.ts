/** Shot distance / framing distance tags */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({ id: `${category}-${en.replace(/\s+/g, "")}`, en, ja }));

export const extraShotDistanceCategory: PromptCategory = {
  id: "shot-distance",
  label: "撮影距離",
  labelEn: "Shot distance",
  hint: "被写体までの距離・ショットサイズ",
  options: words("shot-distance", [
    ["extreme wide shot", "超広角ショット"],
    ["wide shot", "ワイドショット"],
    ["long shot", "ロングショット"],
    ["full shot", "フルショット"],
    ["full body", "全身"],
    ["cowboy shot", "カウボーイショット"],
    ["medium full shot", "ニーショット"],
    ["medium shot", "ミディアムショット"],
    ["waist shot", "ウェストショット"],
    ["upper body", "上半身"],
    ["bust shot", "バストショット"],
    ["medium close-up", "ミディアムクローズアップ"],
    ["close-up", "クローズアップ"],
    ["extreme close-up", "エクストリームクローズアップ"],
    ["headshot", "ヘッドショット"],
    ["face focus", "顔フォーカス"],
    ["portrait shot", "ポートレートショット"],
    ["establishing shot", "導入ショット"],
    ["over the shoulder", "肩越し"],
    ["point of view", "主観視点"],
    ["insert shot", "インサート"],
    ["two shot", "ツーショット"],
    ["group shot", "グループショット"],
  ]),
};
