/**
 * X research SFW tags (2026-08). Additive only.
 * Do not edit prompt-data.ts.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraXClothingCategory: PromptCategory = {
  id: "clothing",
  label: "服装",
  labelEn: "Clothing",
  hint: "X調査追加",
  options: words("clothing", [
    ["mandarin collar", "マンダリンカラー／スタンドカラー"],
    ["cropped black military jacket", "クロップド黒軍服ジャケット"],
    ["asymmetrical short-front long-back jacket", "前短後長の非対称ジャケット"],
    ["high-waisted black tailored short pants", "ハイウエスト黒テーラードショート"],
    ["cheerleader outfit", "チアガール衣装"],
    ["strapless pineapple balloon mini dress", "ストラップレスパイナップルバルーンミニ"],
    ["balloon skirt", "バルーンスカート"],
    ["cyber military fashion", "サイバー軍服ファッション"],
    ["elegant tactical fashion", "エレガント戦術ファッション"]
  ]),
};

export const extraXClothingDetailCategory: PromptCategory = {
  id: "clothing-detail",
  label: "衣服の細部",
  labelEn: "Clothing detail",
  hint: "X調査追加",
  options: words("clothing-detail", [
    ["frog buttons", "チャイナボタン"],
    ["double-breasted", "ダブルブレスト"],
    ["shoulder epaulettes", "肩章"],
    ["gunmetal buttons", "ガンメタルボタン"],
    ["high stand collar", "ハイスタンドカラー"],
    ["purple piping", "紫のパイピング"],
    ["structured silhouette", "構築的シルエット"],
    ["fitted waist", "フィットしたウエスト"],
    ["long split coattails", "スリット入り長い裾"]
  ]),
};

export const extraXAccessoryCategory: PromptCategory = {
  id: "accessory",
  label: "装身具",
  labelEn: "Accessory",
  hint: "X調査追加",
  options: words("accessory", [
    ["folding fan", "扇・扇子"],
    ["vintage silver microphone", "ヴィンテージ銀マイク"],
    ["latex gloves", "ラテックス手袋"],
    ["binder", "バインダー"],
    ["ear piercing", "耳ピアス"],
    ["eyebrow piercing", "眉ピアス"],
    ["lip piercing", "リップピアス"],
    ["pineapple choker", "パイナップルチョーカー"],
    ["wrist corsage", "リストコサージュ"],
    ["white gloves", "白手袋"],
    ["silver earrings", "銀のピアス"],
  ]),
};

export const extraXFootwearCategory: PromptCategory = {
  id: "footwear",
  label: "足元",
  labelEn: "Footwear",
  hint: "X調査追加",
  options: words("footwear", [
    ["knee-high leather heeled boots", "ニーハイレザーヒールブーツ"]
  ]),
};

export const extraXHeadwearCategory: PromptCategory = {
  id: "headwear",
  label: "帽子&髪飾り",
  labelEn: "Headwear",
  hint: "X調査追加",
  options: words("headwear", [
    ["pineapple crown headpiece", "パイナップル冠"]
  ]),
};

export const extraXWardrobeCategories: PromptCategory[] = [
  extraXClothingCategory,
  extraXClothingDetailCategory,
  extraXAccessoryCategory,
  extraXFootwearCategory,
  extraXHeadwearCategory,
];
