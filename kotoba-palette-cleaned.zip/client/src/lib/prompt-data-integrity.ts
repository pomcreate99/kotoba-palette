import type { PromptOption } from "./prompt-data";
import { migrateLegacyPromptStorage } from "./prompt-storage-migrations";

if (typeof window !== "undefined") {
  migrateLegacyPromptStorage(window.localStorage);
}

/**
 * Runtime-only corrections for legacy tag data.
 *
 * Keep option ids stable so existing localStorage favorites/history continue to
 * resolve. Ambiguous/model-specific candidates are intentionally not changed
 * here until the audit has stronger evidence.
 */
const safeEnglishCorrections = new Map<string, string>([
  ["greyeneyes", "grey eyes"],
  ["dragonsprit", "dragon spirit"],
  ["practicalight", "practical lighting"],
]);

const safeJapaneseCorrections = new Map<string, string>([
  ["balconette", "バルコネットブラ"],
  ["hand fan", "手持ち扇"],
  ["cleavage", "胸の谷間"],
]);

/**
 * Some English tags are valid in multiple categories with different meanings,
 * so category-specific corrections use the stable option-id prefix rather than
 * changing every occurrence of the English word globally.
 */
const safeCategoryEnglishCorrections = [
  { prefix: "setting-", en: "balony", correctedEn: "balcony" },
  { prefix: "optics-", en: "leaves", correctedEn: "falling leaves" },
  { prefix: "optics-", en: "petals", correctedEn: "falling petals" },
  { prefix: "style-", en: "yoga", correctedEn: "western-style painting" },
  { prefix: "adult-scene-", en: "private", correctedEn: "private room" },
  { prefix: "architecture-", en: "mansion", correctedEn: "western-style house" },
  { prefix: "patterns-", en: "leather", correctedEn: "leather texture" },
] as const;

const safeCategoryJapaneseCorrections = [
  { prefix: "adult-pose-", en: "on knees oral", ja: "膝立ちでオーラル" },
  { prefix: "adult-pose-", en: "spooning", ja: "側位（スプーニング）" },
  { prefix: "adult-mood-", en: "sticky", ja: "べたつく" },
  { prefix: "adult-mood-", en: "tender", ja: "優しい" },
  { prefix: "pose-", en: "profile", ja: "横顔" },
  { prefix: "effect-", en: "grain", ja: "粒状感" },
  { prefix: "adult-scene-", en: "grain", ja: "粒状感" },
  { prefix: "relationships-", en: "parents", ja: "両親" },
  { prefix: "nature-", en: "mist", ja: "薄霧" },
  { prefix: "optics-", en: "mist", ja: "薄霧効果" },
  { prefix: "surface-", en: "frosted", ja: "フロスト加工" },
  { prefix: "surface-", en: "engraved", ja: "彫り込み" },
] as const;

function categoryEnglishCorrection(option: PromptOption): string | undefined {
  return safeCategoryEnglishCorrections.find(
    (correction) => option.id.startsWith(correction.prefix) && option.en === correction.en,
  )?.correctedEn;
}

function categoryJapaneseCorrection(option: PromptOption): string | undefined {
  return safeCategoryJapaneseCorrections.find(
    (correction) => option.id.startsWith(correction.prefix) && option.en === correction.en,
  )?.ja;
}

export function applyPromptOptionIntegrity(option: PromptOption): PromptOption {
  const correctedEn = categoryEnglishCorrection(option)
    ?? safeEnglishCorrections.get(option.en)
    ?? option.en;
  const correctedJa = categoryJapaneseCorrection(option)
    ?? safeJapaneseCorrections.get(option.en)
    ?? option.ja;
  if (correctedEn === option.en && correctedJa === option.ja) return option;
  return { ...option, en: correctedEn, ja: correctedJa };
}

/**
 * Most historical tags intentionally dedupe whitespace variants such as
 * `wideeyes` / `wide eyes`. These two pairs are different concepts, so they
 * must retain distinct identities even though the old normalizer would merge
 * them after removing spaces.
 */
const semanticWhitespaceDistinctTags = new Set([
  "cow girl",
  "fish tail",
]);

export function promptDedupeKey(en: string): string {
  const normalized = en.toLowerCase().trim().replace(/\s+/g, " ");
  if (semanticWhitespaceDistinctTags.has(normalized)) {
    return `literal:${normalized}`;
  }
  return normalized.replace(/\s+/g, "");
}
