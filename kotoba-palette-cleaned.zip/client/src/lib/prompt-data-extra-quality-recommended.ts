/** Quality tags commonly recommended for PixAI, NoobAI, and Illustrious models. */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({ id: `quality-${en.replace(/\s+/g, "")}`, en, ja }));

export const recommendedQualityCategory: PromptCategory = {
  id: "quality",
  label: "品質",
  labelEn: "Quality",
  hint: "仕上がりの密度を選ぶ",
  options: words([
    ["high quality", "高品質"],
    ["good quality", "良品質"],
    ["very aesthetic", "非常に美しい仕上がり"],
    ["newest", "新しい作風・データ傾向"],
    ["high resolution", "高解像度"],
    ["detailed background", "詳細な背景"],
    ["detailed face", "詳細な顔"],
    ["detailed hands", "詳細な手"],
    ["coherent details", "整合性のある細部"],
  ]),
};
