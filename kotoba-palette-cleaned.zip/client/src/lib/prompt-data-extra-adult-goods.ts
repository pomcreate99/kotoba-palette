/**
 * Adult goods (sex toys / BDSM props) and cow-themed costume tags.
 * Adult fictional characters only. Deduped against existing extras.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

/** アダルトグッズ・道具 */
export const extraAdultGoodsCategory: PromptCategory = {
  id: "adult-wardrobe",
  label: "成人向け衣装",
  labelEn: "Adult wardrobe",
  hint: "アダルトグッズ・拘束具・玩具",
  mode: "nsfw",
  options: words("adult-goods", [
    // toys
    ["dildo", "ディルド"],
    ["realistic dildo", "リアルディルド"],
    ["double dildo", "ダブルディルド"],
    ["strap-on", "ストラップオン"],
    ["magic wand", "電マ"],
    ["wand vibrator", "電マバイブ"],
    ["bullet vibrator", "ローター"],
    ["rabbit vibrator", "うさぎ型バイブ"],
    ["anal beads", "アナルビーズ"],
    ["anal plug", "アナルプラグ"],
    ["jeweled butt plug", "宝石付きプラグ"],
    ["tail butt plug", "しっぽ付きプラグ"],
    ["prostate massager", "前立腺マッサージャー"],
    ["sex machine", "セックスマシン"],
    ["fucking machine", "ファッキングマシン"],
    ["sybian", "サイビアン"],
    ["onahole", "オナホール"],
    ["fleshlight", "フレッシュライト"],
    ["masturbator", "オナニー器具"],
    // restraints / BDSM gear
    ["ball gag", "ボールギャグ"],
    ["ring gag", "リングギャグ"],
    ["bit gag", "ビットギャグ"],
    ["gag", "口枷"],
    ["blindfold", "目隠し"],
    ["leather blindfold", "レザー目隠し"],
    ["restraints", "拘束具"],
    ["leather restraints", "レザー拘束具"],
    ["armbinder", "アームバインダー"],
    ["hogtie", "ホグタイ"],
    ["spreader bar", "スプレッダーバー"],
    ["shackles", "足枷"],
    ["ankle cuffs", "アンクルカフ"],
    ["wrist restraints", "手首拘束"],
    ["chastity cage", "貞操帯（ケージ）"],
    ["chastity belt", "貞操帯"],
    ["nipple clamps", "乳首クリップ"],
    ["nipple weights", "乳首ウェイト"],
    ["clothespins on nipples", "乳首に洗濯バサミ"],
    ["riding crop", "乗馬ムチ"],
    ["flogger", "フロッガー"],
    ["paddle", "パドル"],
    ["leather paddle", "レザーパドル"],
    ["whip", "ムチ"],
    ["leather whip", "レザー鞭"],
    ["cane", "杖（スパンキング）"],
    ["spanking bench", "スパンキングベンチ"],
    ["St. Andrew's cross", "聖アンドレの十字架"],
    ["bondage frame", "ボンデージフレーム"],
    ["collar and chain", "首輪とチェーン"],
    ["leash", "リード"],
    ["metal collar", "金属カラー"],
    ["padlock collar", "南京錠付きカラー"],
    ["harness", "ハーネス"],
    ["chest harness", "チェストハーネス"],
    ["body harness", "ボディハーネス"],
    ["leather harness", "レザーハーネス"],
    ["cock ring", "コックリング"],
    ["penis ring", "ペニスリング"],
    ["sounding rod", "サウンディング"],
    ["urethral plug", "尿道プラグ"],
    ["enema", "浣腸"],
    ["speculum", "クスコ"],
    ["medical restraints", "医療拘束具"],
  ]),
};

/** 牛系・ケモ耳衣装（頭） */
export const extraCowHeadwearCategory: PromptCategory = {
  id: "headwear",
  label: "帽子・頭",
  labelEn: "Headwear",
  hint: "牛耳・角など",
  options: words("headwear", [
    ["cow ears", "牛耳"],
    ["cow horns", "牛の角"],
    ["small horns", "小さな角"],
    ["curved horns", "曲がった角"],
    ["bull horns", "雄牛の角"],
    ["cow print hairband", "牛柄ヘアバンド"],
    ["cow ear headband", "牛耳ヘッドバンド"],
  ]),
};

/** 牛系小物 */
export const extraCowAccessoryCategory: PromptCategory = {
  id: "accessory",
  label: "小物",
  labelEn: "Accessories",
  hint: "牛鈴・しっぽなど",
  options: words("accessory", [
    ["cow tail", "牛のしっぽ"],
    ["cowbell", "カウベル"],
    ["cow bell collar", "カウベル付き首輪"],
    ["bell collar", "鈴付き首輪"],
    ["nose ring", "鼻輪"],
    ["cow print collar", "牛柄カラー"],
  ]),
};

/** 牛系衣装 */
export const extraCowClothingCategory: PromptCategory = {
  id: "clothing",
  label: "服装",
  labelEn: "Clothing",
  hint: "牛柄・ホルスタイン衣装",
  options: words("clothing", [
    ["cow print", "牛柄"],
    ["cow print bikini", "牛柄ビキニ"],
    ["cow print lingerie", "牛柄ランジェリー"],
    ["cow print leotard", "牛柄レオタード"],
    ["cow print bodysuit", "牛柄ボディスーツ"],
    ["holstein print", "ホルスタイン柄"],
    ["cow girl outfit", "牛娘衣装"],
    ["cow costume", "牛コスチューム"],
    ["dairy maid outfit", "酪農メイド衣装"],
    ["milk maid dress", "ミルクメイドドレス"],
  ]),
};

/** 牛系・成人向け（露出寄り） */
export const extraCowAdultWardrobeCategory: PromptCategory = {
  id: "adult-wardrobe",
  label: "成人向け衣装",
  labelEn: "Adult wardrobe",
  hint: "牛娘・搾乳系の成人向け衣装",
  mode: "nsfw",
  options: words("adult-wardrobe", [
    ["cow print micro bikini", "牛柄極小ビキニ"],
    ["cow print pasties", "牛柄ニップレス"],
    ["lactation", "授乳・搾乳"],
    ["milking", "搾乳"],
    ["milking machine", "搾乳機"],
    ["breast pump", "搾乳器"],
    ["udder", "乳房（牛）"],
    ["cow girl", "牛娘"],
    ["hucow", "ヒューカウ"],
  ]),
};
