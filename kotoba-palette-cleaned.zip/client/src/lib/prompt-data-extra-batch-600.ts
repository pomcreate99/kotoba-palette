/**
 * Deprecated placeholder path — content lives in prompt-data-extra-chunk-*.ts
 * Kept empty of tags so accidental imports fail loudly if miswired.
 */
export {};
