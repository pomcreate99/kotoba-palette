import { describe, expect, it } from "vitest";
import { categories } from "./prompt-data";
import { mergeExtraCategories } from "./prompt-data-merge";
import { styleRecipeCategory } from "./prompt-data-recipes";

const normalize = (value: string) => value.toLowerCase().replace(/\s+/g, "");

describe("画風レシピ", () => {
  it("IDと英語プロンプトが重複しない", () => {
    const ids = styleRecipeCategory.options.map((option) => option.id);
    const prompts = styleRecipeCategory.options.map((option) => normalize(option.en));
    expect(new Set(ids).size).toBe(ids.length);
    expect(new Set(prompts).size).toBe(prompts.length);
  });

  it("人物の髪・目などを後から追加できる画風プロンプトとして構成される", () => {
    for (const option of styleRecipeCategory.options) {
      expect(option.en.split(",").length).toBeGreaterThanOrEqual(6);
      expect(option.ja.trim()).not.toBe("");
    }
  });

  it("全カテゴリの重複除去後も追加レシピがすべて残る", () => {
    const merged = mergeExtraCategories(categories).find((category) => category.id === "recipe-style");
    expect(merged?.options.map((option) => option.id)).toEqual(styleRecipeCategory.options.map((option) => option.id));
  });
});
