/**
 * Merge helper for modular prompt data expansions.
 * Dedupes by normalized English key, first within each category and then across
 * the complete merged category list. Audited semantic exceptions stay distinct.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";
import { applyPromptOptionIntegrity } from "./prompt-data-integrity";
import { promptGlobalDedupeIdentity, promptOutputIdentity } from "./prompt-data-semantics";
import { isAuditedCategoryAlias, type PromptCategoryAliasOptionIds } from "./prompt-category-aliases";
import { extraPoseCategory } from "./prompt-data-extra-pose";
import {
  extraAdultPoseCategory,
  extraAdultWardrobeCategory,
} from "./prompt-data-extra-nsfw";
import {
  extraAdultAnatomyCategory,
  extraAdultPoseMoreCategory,
} from "./prompt-data-extra-nsfw-body";
import {
  extraAdultBodyCategory,
  extraAdultChestCategory,
  extraAdultGenitalsCategory,
  extraAdultSkinCategory,
  extraAdultReactionCategory,
} from "./prompt-data-extra-nsfw-split";
import {
  extraSubjectCategory,
  extraPhysiqueCategory,
} from "./prompt-data-extra-person";
import { extraHairEyeCategories } from "./prompt-data-extra-hair-eyes";
import { extraShotDistanceCategory } from "./prompt-data-extra-shot";
import {
  extraSpeciesCategory,
  extraCreatureFeaturesCategory,
  extraAnimalsCategory,
} from "./prompt-data-extra-creatures";
import {
  extraQualityCategory,
  extraDesignCategory,
} from "./prompt-data-extra-quality";
import {
  extraColoringCategory,
  extraStyleCategory,
  extraMediumCategory,
} from "./prompt-data-extra-style";
import {
  extraBunnyHeadwearCategory,
  extraBunnyAccessoryCategory,
  extraBunnyClothingCategory,
  extraBunnyAdultWardrobeCategory,
} from "./prompt-data-extra-bunny";
import {
  extraAdultGoodsCategory,
  extraCowHeadwearCategory,
  extraCowAccessoryCategory,
  extraCowClothingCategory,
  extraCowAdultWardrobeCategory,
} from "./prompt-data-extra-adult-goods";
import { extraV2Categories } from "./prompt-data-extra-tags-v2";
import { styleRecipeCategory } from "./prompt-data-recipes";
import {
  spreadsheetSkinCategory,
  spreadsheetClothingCategory,
  spreadsheetAccessoryCategory,
  spreadsheetPoseCategory,
  spreadsheetAdultWardrobeCategory,
  spreadsheetAdultPoseCategory,
} from "./prompt-data-extra-spreadsheet";
import {
  extraSkinCategory,
  extraSfwClothingCategory,
  extraAdultPoseMore2Category,
} from "./prompt-data-extra-skin-clothing-pose";
import {
  extraBatchAdultWardrobeCategory,
  extraBatchAdultPoseCategory,
  extraBatchAdultSceneCategory,
  extraBatchClothingCategory,
  extraBatchAccessoryCategory,
  extraBatchFootwearCategory,
  extraBatchClothingDetailCategory,
  extraBatchHeadwearCategory,
  extraBatchAccessoryDetailCategory,
} from "./prompt-data-extra-batch-wardrobe-pose";
import { extraChunkNsfwCloth1Category } from "./prompt-data-extra-chunk-nsfw-cloth-1";
import { extraChunkNsfwCloth2Category } from "./prompt-data-extra-chunk-nsfw-cloth-2";
import { extraChunkNsfwCloth3Category } from "./prompt-data-extra-chunk-nsfw-cloth-3";
import { extraChunkNsfwCloth4Category } from "./prompt-data-extra-chunk-nsfw-cloth-4";
import { extraChunkNsfwPose1Category } from "./prompt-data-extra-chunk-nsfw-pose-1";
import { extraChunkNsfwPose2Category } from "./prompt-data-extra-chunk-nsfw-pose-2";
import { extraChunkNsfwPose3Category } from "./prompt-data-extra-chunk-nsfw-pose-3";
import { extraChunkNsfwPose4Category } from "./prompt-data-extra-chunk-nsfw-pose-4";
import { extraChunkSfwCloth1Category } from "./prompt-data-extra-chunk-sfw-cloth-1";
import { extraChunkSfwCloth2Category } from "./prompt-data-extra-chunk-sfw-cloth-2";
import { extraChunkSfwCloth3Category } from "./prompt-data-extra-chunk-sfw-cloth-3";
import { extraChunkSfwCloth4Category } from "./prompt-data-extra-chunk-sfw-cloth-4";
import { extraChunkSfwPose1Category } from "./prompt-data-extra-chunk-sfw-pose-1";
import { extraChunkSfwPose2Category } from "./prompt-data-extra-chunk-sfw-pose-2";
import { extraChunkSfwPose3Category } from "./prompt-data-extra-chunk-sfw-pose-3";
import { extraChunkSfwPose4Category } from "./prompt-data-extra-chunk-sfw-pose-4";
import { extraChunkSfwPose5Category } from "./prompt-data-extra-chunk-sfw-pose-5";
import { extraXPoseCompCategories } from "./prompt-data-extra-x-pose-comp";
import { extraXHairFaceCategories } from "./prompt-data-extra-x-hair-face";
import { extraXWardrobeCategories } from "./prompt-data-extra-x-wardrobe";
import { extraXStyleLightCategories } from "./prompt-data-extra-x-style-light";
import { extraGrok20260824FurryCategories } from "./prompt-data-extra-grok-20260824-furry";
import { extraGrok20260825StyleCategories } from "./prompt-data-extra-grok-20260825-style";
import { extraGrok20260825KeywordCategories } from "./prompt-data-extra-grok-20260825-keywords";
import { extraGrok20260825KeywordCategoriesB } from "./prompt-data-extra-grok-20260825-keywords-b";
import { extraGrok20260825KeywordCategoriesC } from "./prompt-data-extra-grok-20260825-keywords-c";

import { organizePersonOptions } from "./prompt-data-person-order";
import { recommendedQualityCategory } from "./prompt-data-extra-quality-recommended";
import { extraBackgroundCategories } from "./prompt-data-extra-background";

function prepareCategory(category: PromptCategory): PromptCategory {
  return {
    ...category,
    options: category.options.map(applyPromptOptionIntegrity),
  };
}

function dedupeOptions(options: PromptOption[]): PromptOption[] {
  const seen = new Set<string>();
  const result: PromptOption[] = [];
  for (const opt of options) {
    const key = promptOutputIdentity(opt);
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(opt);
  }
  return result;
}

const preferredCategoryRank = new Map<string, number>([
  ...[
    "skin", "hair-color", "hair-style", "eye-color", "eye-shape", "shot-distance",
    "count", "creature-features", "adult-body", "adult-chest",
    "adult-genitals", "adult-skin", "adult-reaction",
  ].map((id) => [id, 0] as const),
  ...[
    "lighting-detail", "camera-tech", "clothing-detail", "accessory-detail",
    "face-detail", "footwear", "headwear", "interior", "water", "sky",
    "animals", "machines", "dessert", "drinks", "places", "art-materials",
    "optics", "coloring",
  ].map((id) => [id, 10] as const),
  ["hair-detail", 250],
  ["hair", 300],
  ["eyes", 300],
  ["adult-anatomy", 400],
  ["avoid", 500],
]);

function globalPreferenceScore(category: PromptCategory, option: PromptOption, order: number) {
  return (preferredCategoryRank.get(category.id) ?? 100)
    + (category.mode === "nsfw" ? 1000 : 0)
    + (category.audience === "youth" || option.audience === "youth" ? 500 : 0)
    + (option.negative ? 200 : 0)
    + order / 1_000_000;
}

/**
 * Keep one occurrence of each audited semantic meaning and polarity across all
 * categories. Same-output category aliases still collapse to one occurrence;
 * audited different meanings may coexist without changing their option ids.
 */
function dedupeAcrossCategories(
  categories: PromptCategory[],
  categoryAliasOptionIds?: Map<string, string[]>,
): PromptCategory[] {
  const winners = new Map<string, { categoryId: string; optionId: string; score: number }>();
  let order = 0;

  for (const category of categories) {
    for (const option of category.options) {
      const key = promptGlobalDedupeIdentity(category, option);
      const score = globalPreferenceScore(category, option, order++);
      const current = winners.get(key);
      if (!current || score < current.score) {
        winners.set(key, { categoryId: category.id, optionId: option.id, score });
      }
    }
  }

  if (categoryAliasOptionIds) {
    for (const category of categories) {
      for (const option of category.options) {
        if (!isAuditedCategoryAlias(option)) continue;
        const winner = winners.get(promptGlobalDedupeIdentity(category, option));
        if (!winner) continue;
        const refs = categoryAliasOptionIds.get(category.id) ?? [];
        if (!refs.includes(winner.optionId)) refs.push(winner.optionId);
        categoryAliasOptionIds.set(category.id, refs);
      }
    }
  }

  return categories.map((category) => ({
    ...category,
    options: category.options.filter((option) => {
      const winner = winners.get(promptGlobalDedupeIdentity(category, option));
      return winner?.categoryId === category.id && winner.optionId === option.id;
    }),
  }));
}

function mergeExtraCategoriesInternal(
  base: PromptCategory[],
  categoryAliasOptionIds?: Map<string, string[]>,
): PromptCategory[] {
  const preparedBase = base.map(prepareCategory);
  const extras = [
    extraPoseCategory,
    extraAdultPoseCategory,
    extraAdultPoseMoreCategory,
    extraAdultWardrobeCategory,
    extraAdultAnatomyCategory,
    extraAdultBodyCategory,
    extraAdultChestCategory,
    extraAdultGenitalsCategory,
    extraAdultSkinCategory,
    extraAdultReactionCategory,
    extraSubjectCategory,
    extraPhysiqueCategory,
    ...extraHairEyeCategories,
    extraShotDistanceCategory,
    extraSpeciesCategory,
    extraCreatureFeaturesCategory,
    extraAnimalsCategory,
    extraQualityCategory,
    recommendedQualityCategory,
    ...extraBackgroundCategories,
    extraDesignCategory,
    extraColoringCategory,
    extraStyleCategory,
    extraMediumCategory,
    extraBunnyHeadwearCategory,
    extraBunnyAccessoryCategory,
    extraBunnyClothingCategory,
    extraBunnyAdultWardrobeCategory,
    extraAdultGoodsCategory,
    extraCowHeadwearCategory,
    extraCowAccessoryCategory,
    extraCowClothingCategory,
    extraCowAdultWardrobeCategory,
    ...extraV2Categories,
    styleRecipeCategory,
    spreadsheetSkinCategory,
    spreadsheetClothingCategory,
    spreadsheetAccessoryCategory,
    spreadsheetPoseCategory,
    spreadsheetAdultWardrobeCategory,
    spreadsheetAdultPoseCategory,
    extraSkinCategory,
    extraSfwClothingCategory,
    extraAdultPoseMore2Category,
    extraBatchAdultWardrobeCategory,
    extraBatchAdultPoseCategory,
    extraBatchAdultSceneCategory,
    extraBatchClothingCategory,
    extraBatchAccessoryCategory,
    extraBatchFootwearCategory,
    extraBatchClothingDetailCategory,
    extraBatchHeadwearCategory,
    extraBatchAccessoryDetailCategory,
    extraChunkNsfwCloth1Category,
    extraChunkNsfwCloth2Category,
    extraChunkNsfwCloth3Category,
    extraChunkNsfwCloth4Category,
    extraChunkNsfwPose1Category,
    extraChunkNsfwPose2Category,
    extraChunkNsfwPose3Category,
    extraChunkNsfwPose4Category,
    extraChunkSfwCloth1Category,
    extraChunkSfwCloth2Category,
    extraChunkSfwCloth3Category,
    extraChunkSfwCloth4Category,
    extraChunkSfwPose1Category,
    extraChunkSfwPose2Category,
    extraChunkSfwPose3Category,
    extraChunkSfwPose4Category,
    extraChunkSfwPose5Category,
    ...extraXPoseCompCategories,
    ...extraXHairFaceCategories,
    ...extraXWardrobeCategories,
    ...extraXStyleLightCategories,
    ...extraGrok20260824FurryCategories,
    ...extraGrok20260825StyleCategories,
    ...extraGrok20260825KeywordCategories,
    ...extraGrok20260825KeywordCategoriesB,
    ...extraGrok20260825KeywordCategoriesC,

  ].map(prepareCategory);

  const baseIds = new Set(preparedBase.map((c) => c.id));

  const merged = preparedBase.map((cat) => {
    const matching = extras.filter((e) => e.id === cat.id);
    let options = cat.options;

    for (const extra of matching) {
      const existing = new Set(options.map((o) => promptOutputIdentity(o)));
      const newOptions = extra.options.filter(
        (o) => !existing.has(promptOutputIdentity(o)),
      );
      if (newOptions.length > 0) {
        options = [...options, ...newOptions];
      }
    }

    const deduped = dedupeOptions(options);
    return {
      ...cat,
      options: deduped,
    };
  });

  const appendedIds = new Set<string>();
  for (const extra of extras) {
    if (baseIds.has(extra.id) || appendedIds.has(extra.id)) continue;

    const matching = extras.filter((candidate) => candidate.id === extra.id);
    const options = dedupeOptions(matching.flatMap((candidate) => candidate.options));
    merged.push({
      ...extra,
      options,
    });
    appendedIds.add(extra.id);
  }

  return organizePersonOptions(dedupeAcrossCategories(merged, categoryAliasOptionIds));
}

/** Merge extras into matching ids, append brand-new categories, dedupe. */
export function mergeExtraCategories(base: PromptCategory[]): PromptCategory[] {
  return mergeExtraCategoriesInternal(base);
}

/**
 * Merge runtime categories and separately return dictionary-only category alias
 * references. Alias references reuse canonical option ids and do not increase
 * the runtime tag inventory.
 */
export function mergeExtraCategoriesWithAliases(base: PromptCategory[]): {
  categories: PromptCategory[];
  categoryAliasOptionIds: PromptCategoryAliasOptionIds;
} {
  const categoryAliasOptionIds = new Map<string, string[]>();
  const categories = mergeExtraCategoriesInternal(base, categoryAliasOptionIds);
  return { categories, categoryAliasOptionIds };
}
