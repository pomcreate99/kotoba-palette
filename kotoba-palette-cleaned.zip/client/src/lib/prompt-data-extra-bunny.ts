/**
 * Bunny / animal-ear costume tags (Playboy bunny, reverse bunnysuit, kemonomimi).
 * Deduped against base clothing / headwear / accessory / adult-wardrobe.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

/** うさ耳・ケモ耳（頭） */
export const extraBunnyHeadwearCategory: PromptCategory = {
  id: "headwear",
  label: "帽子・頭",
  labelEn: "Headwear",
  hint: "頭・耳・ヘッドアクセ",
  options: words("headwear", [
    ["rabbit ears", "うさ耳"],
    ["bunny ears", "バニー耳"],
    ["fake animal ears", "付け耳"],
    ["animal ears", "動物の耳"],
    ["rabbit ear hairband", "うさ耳ヘアバンド"],
    ["bunny ear headband", "バニー耳ヘッドバンド"],
    ["lop rabbit ears", "垂れうさ耳"],
    ["floppy bunny ears", "くたびれたうさ耳"],
    ["cat ears", "猫耳"],
    ["fox ears", "狐耳"],
    ["dog ears", "犬耳"],
    ["wolf ears", "狼耳"],
    ["kitsune ears", "キツネ耳"],
    ["bear ears", "熊耳"],
    ["mouse ears", "ネズミ耳"],
    ["kemonomimi", "ケモ耳"],
  ]),
};

/** しっぽ・小物 */
export const extraBunnyAccessoryCategory: PromptCategory = {
  id: "accessory",
  label: "小物",
  labelEn: "Accessories",
  hint: "しっぽ・カフス・付け襟など",
  options: words("accessory", [
    ["rabbit tail", "うさぎのしっぽ"],
    ["bunny tail", "バニーテール"],
    ["fluffy tail", "ふわふわのしっぽ"],
    ["fake tail", "付けしっぽ"],
    ["pom pom tail", "ポンポンしっぽ"],
    ["cat tail", "猫のしっぽ"],
    ["fox tail", "狐のしっぽ"],
    ["dog tail", "犬のしっぽ"],
    ["wolf tail", "狼のしっぽ"],
    ["detached collar", "付け襟"],
    ["detachable collar", "取り外し可能な襟"],
    ["bow tie", "蝶ネクタイ"],
    ["black bow tie", "黒の蝶ネクタイ"],
    ["bunny wrist cuffs", "バニーのリストカフ"],
    ["white wrist cuffs", "白いリストカフ"],
    ["playboy cuffs", "プレイボーイカフス"],
  ]),
};

/** バニー衣装本体（SFW寄り・一般衣装） */
export const extraBunnyClothingCategory: PromptCategory = {
  id: "clothing",
  label: "服装",
  labelEn: "Clothing",
  hint: "バニースーツ・レオタード系",
  options: words("clothing", [
    ["bunny suit", "バニースーツ"],
    ["bunnysuit", "バニースーツ"],
    ["bunny costume", "バニーコスチューム"],
    ["playboy bunny", "プレイボーイバニー"],
    ["bunny girl", "バニーガール"],
    ["strapless leotard", "ストラップレスレオタード"],
    ["highleg leotard", "ハイレグレオタード"],
    ["highleg", "ハイレグ"],
    ["black leotard", "黒いレオタード"],
    ["white leotard", "白いレオタード"],
    ["satin leotard", "サテンのレオタード"],
    ["shiny leotard", "光沢のあるレオタード"],
    ["bunny leotard", "バニーレオタード"],
    ["corset leotard", "コルセットレオタード"],
    ["fishnet pantyhose", "網タイツ（パンスト）"],
    ["fishnet thighhighs", "網のニーハイ"],
    ["black pantyhose", "黒パンスト"],
    ["sheer pantyhose", "薄手パンスト"],
    ["latex legwear", "ラテックスのレッグウェア"],
  ]),
};

/** 逆バニーなど成人向け衣装 */
export const extraBunnyAdultWardrobeCategory: PromptCategory = {
  id: "adult-wardrobe",
  label: "成人向け衣装",
  labelEn: "Adult wardrobe",
  hint: "逆バニー・露出の強いバニー衣装",
  mode: "nsfw",
  options: words("adult-wardrobe", [
    ["reverse bunnysuit", "逆バニースーツ"],
    ["reverse bunny suit", "逆バニー"],
    ["reverse outfit", "逆衣装"],
    ["heart pasties", "ハート型ニップレス"],
    ["star pasties", "星型ニップレス"],
    ["maebari", "前貼り"],
    ["heart maebari", "ハート前貼り"],
    ["crotchless pantyhose", "クロッチレスパンスト"],
    ["open crotch leotard", "股開きレオタード"],
    ["micro bikini bunny", "極小ビキニバニー"],
    ["bunny lingerie", "バニーランジェリー"],
    ["revealing bunny suit", "露出多めのバニースーツ"],
    ["bare midriff bunny", "お腹見せバニー"],
    ["underboob leotard", "アンダーブーブレオタード"],
    ["sideboob leotard", "サイドブーブレオタード"],
  ]),
};
