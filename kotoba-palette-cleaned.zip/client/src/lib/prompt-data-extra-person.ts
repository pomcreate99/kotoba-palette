/**
 * Extra person tags: subject / physique (incl. skin tone & body type)
 * SFW only. No minor-related terms.
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({ id: `${category}-${en}`, en, ja }));

export const extraSubjectCategory: PromptCategory = {
  id: "subject",
  label: "人物（一般）",
  labelEn: "Human subject",
  hint: "人物を主題にするときに選ぶ",
  options: words("subject", [
    ["solo", "一人"],
    ["couple", "二人・カップル"],
    ["group", "グループ"],
    ["crowd", "群衆"],
    ["1person", "人物1人"],
    ["2people", "人物2人"],
    ["multiple people", "複数人"],
    ["headshot", "顔アップ"],
    ["bust shot", "バストショット"],
    ["half body", "半身"],
    ["full body", "全身"],
    ["profile view", "横顔"],
    ["three quarter view", "斜め前"],
    ["facing viewer", "正面"],
    ["from behind", "後ろ姿"],
    ["silhouette", "シルエット"],
    ["anonymous", "顔なし・匿名"],
  ]),
};

export const extraPhysiqueCategory: PromptCategory = {
  id: "physique",
  label: "体格",
  labelEn: "Physique",
  hint: "体型・肌の色の印象を整える",
  options: words("physique", [
    // body type
    ["slim", "スリム"],
    ["skinny", "やせ型"],
    ["lean", "引き締まった"],
    ["toned", "引き締まった筋肉"],
    ["ripped", "筋肉が浮き出た"],
    ["soft body", "やわらかい体型"],
    ["chubby", "ぽっちゃり"],
    ["plump", "ふくよか"],
    ["stocky", "ずんぐり"],
    ["hourglass figure", "砂時計体型"],
    ["pear shaped", "洋ナシ体型"],
    ["broad shoulders", "広い肩"],
    ["narrow waist", "細い腰"],
    ["long legs", "長い脚"],
    ["short legs", "短い脚"],
    ["long torso", "長い胴"],
    ["short torso", "短い胴"],
    ["large breasts", "大きな胸"],
    ["small breasts", "小さな胸"],
    ["flat chest", "平坦な胸"],
    ["wide hips", "広い腰"],
    ["thick thighs", "太い太もも"],
    ["thin arms", "細い腕"],
    ["muscular arms", "筋肉質の腕"],
    // skin tone / surface (SFW)
    ["pale skin", "色白"],
    ["fair skin", "明るい肌"],
    ["light skin", "薄い肌色"],
    ["medium skin", "中間の肌色"],
    ["olive skin", "オリーブ肌"],
    ["tan skin", "日焼け肌"],
    ["tanned skin", "小麦色の肌"],
    ["dark skin", "暗い肌色"],
    ["deep skin", "深い肌色"],
    ["brown skin", "茶色の肌"],
    ["porcelain skin", "陶器のような肌"],
    ["smooth skin", "なめらかな肌"],
    ["glossy skin", "つやのある肌"],
    ["matte skin", "マットな肌"],
    ["freckles", "そばかす"],
    ["moles", "ほくろ"],
    ["beauty mark", "ほくろ（美人点）"],
    ["thin frame", "華奢な体格"],
    ["slender build", "すらりとした体つき"],
    ["lean physique", "引き締まった体躯"],
    ["athletic build", "アスリート体型"],
  ]),
};
