import type { PromptOption } from "./prompt-data";

const LEGACY_BALONY_ID = "setting-balony";
const CANONICAL_BALCONY_ID = "interior-balcony";

export function migrateLegacyPromptOption(option: PromptOption): PromptOption {
  if (option.id !== LEGACY_BALONY_ID) return option;
  return {
    ...option,
    id: CANONICAL_BALCONY_ID,
    en: "balcony",
    ja: "バルコニー",
  };
}

export function migrateLegacyFavoriteIds(ids: string[]): string[] {
  return [...new Set(ids.map((id) => id === LEGACY_BALONY_ID ? CANONICAL_BALCONY_ID : id))];
}

export function migrateLegacyPromptOptions(options: PromptOption[]): PromptOption[] {
  const migrated = options.map(migrateLegacyPromptOption);
  const seen = new Set<string>();
  return migrated.filter((option) => {
    const key = `${option.id}:${Boolean(option.negative)}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export function migrateLegacyOptionContainers<T extends { options: PromptOption[] }>(items: T[]): T[] {
  return items.map((item) => ({
    ...item,
    options: migrateLegacyPromptOptions(item.options),
  }));
}

export function migrateLegacyHistoryItems<T extends {
  options: PromptOption[];
  prompt: string;
  negativePrompt?: string;
}>(items: T[]): T[] {
  return items.map((item) => {
    const options = migrateLegacyPromptOptions(item.options);
    const prompt = options.filter((option) => !option.negative).map((option) => option.en).join(", ");
    const negativePrompt = options.filter((option) => option.negative).map((option) => option.en).join(", ");
    return {
      ...item,
      options,
      prompt,
      negativePrompt: negativePrompt || undefined,
    };
  });
}

type StorageLike = Pick<Storage, "getItem" | "setItem">;

function migrateJsonKey<T>(storage: StorageLike, key: string, migrate: (value: T) => T): void {
  const raw = storage.getItem(key);
  if (!raw) return;
  try {
    const parsed = JSON.parse(raw) as T;
    const migrated = migrate(parsed);
    const next = JSON.stringify(migrated);
    if (next !== raw) storage.setItem(key, next);
  } catch {
    // Preserve unreadable legacy storage rather than deleting user data.
  }
}

/**
 * One-time, idempotent migration for the legacy `balony` typo.
 * It runs before UI state reads the shared prompt-atlas localStorage keys.
 */
export function migrateLegacyPromptStorage(storage: StorageLike): void {
  migrateJsonKey<string[]>(storage, "prompt-atlas:favorites", (value) =>
    Array.isArray(value) ? migrateLegacyFavoriteIds(value) : value,
  );

  migrateJsonKey<Array<{ options: PromptOption[]; prompt: string; negativePrompt?: string }>>(
    storage,
    "prompt-atlas:history",
    (value) => Array.isArray(value) ? migrateLegacyHistoryItems(value) : value,
  );

  migrateJsonKey<Array<{ options: PromptOption[] }>>(
    storage,
    "prompt-atlas:custom-presets",
    (value) => Array.isArray(value) ? migrateLegacyOptionContainers(value) : value,
  );
}
