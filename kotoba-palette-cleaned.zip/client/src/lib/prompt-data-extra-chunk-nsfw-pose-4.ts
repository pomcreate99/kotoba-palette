/**
 * Batch chunk: extraChunkNsfwPose4Category (36 tags)
 */
import type { PromptCategory, PromptOption } from "./prompt-data";

const words = (category: string, pairs: [string, string][]): PromptOption[] =>
  pairs.map(([en, ja]) => ({
    id: `${category}-${en.replace(/\s+/g, "")}`,
    en,
    ja,
  }));

export const extraChunkNsfwPose4Category: PromptCategory = {
  id: "adult-pose",
  label: "成人向けポーズ",
  labelEn: "Adult poses",
  hint: "NSFWポーズ追加",
  mode: "nsfw",
  options: words("adult-pose", [
    ["ankle cuffs spread", "足首カフで開脚"],
    ["ball gag pose", "ボールギャグ"],
    ["hooded pose", "フード着用"],
    ["sit up beg", "お座りおねだり"],
    ["paws up", "前足上げ"],
    ["wand on thigh", "電マを太腿に"],
    ["remote vibe react", "リモコンバイブ反応"],
    ["afterglow lie", "余韻で横たわる"],
    ["cum on body pose", "体にかけられた状態"],
    ["licking lips after", "事後に唇を舐める"],
    ["leg tangle nude", "裸で脚を絡める"],
    ["choking gentle pose", "優しく喉に手"],
    ["denied orgasm", "寸止め"],
    ["marking bites", "キスマークポーズ"],
    ["hickey display", "吸い跡見せ"],
    ["rope marks pose", "縄跡ポーズ"],
    ["wax play pose", "蝋プレイポーズ"],
    ["oil massage nude", "オイルマッサージ"],
    ["body to body", "肌と肌"],
    ["tribbing pose", "トライバド"],
    ["self touch chest", "胸を触る"],
    ["pegging pose", "ペッギング"],
    ["semi public", "半公共"],
    ["under desk oral", "机の下オーラル"],
    ["phone sex pose", "電話プレイ"],
    ["window exhibition", "窓辺露出"],
    ["office after hours sex", "時間外オフィス"],
    ["capsule intimate", "狭い空間で密着"],
    ["blush heavy", "強い赤面"],
    ["drool pleasure", "快楽のよだれ"],
    ["mind break expression", "理性崩壊表情"],
    ["covering up after", "事後に隠す"],
    ["quick against wall", "壁で手短に"],
    ["collarbone kiss", "鎖骨キス"],
    ["biting shoulder", "肩を噛む"],
    ["scratching back pleasure", "快楽で背中を掻く"]
  ]),
};
