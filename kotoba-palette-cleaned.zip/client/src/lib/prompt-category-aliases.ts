import type { PromptCategory, PromptOption } from "./prompt-data";
import { promptDedupeKey } from "./prompt-data-integrity";
import { applyDictionaryCategoryOwnership } from "./prompt-dictionary-ownership";

/**
 * Phase 2 audit result: these prompt tokens represent the same output concept
 * but should remain reachable from more than one category in the dictionary UI.
 *
 * They must not become duplicate runtime tags or duplicate prompt output.
 */
export const auditedCategoryAliasEnglish = [
  "coral",
  "braid",
  "athletic",
  "toned",
  "bentover",
  "latex gloves",
  "couple",
  "headshot",
  "pale skin",
  "fair skin",
  "light skin",
  "medium skin",
  "tan skin",
  "dark skin",
  "porcelain skin",
  "glossy skin",
  "ornamental",
  "clean lineart",
  "detailed",
  "realistic",
  "portrait",
  "mentor",
  "companion",
  "library",
  "backpack",
  "shy",
  "laughing",
  "crying",
  "gentle",
  "fierce",
  "headphones",
  "feather",
  "standing",
  "pointing",
  "kissing",
  "hugging",
  "profile",
  "embracing",
  "beach",
  "underwater",
  "temple",
  "shrine",
  "castle",
  "fog",
  "mist",
  "gothic",
  "brutalist",
  "clock",
  "fisheye",
  "minimal",
  "illustration",
  "watercolor",
  "oilpainting",
  "charcoal",
  "gouache",
  "chibi",
  "cozy",
  "nostalgic",
  "silk",
  "dreamy",
  "playful",
  "yearning",
  "smoke",
  "particles",
  "glitch",
  "socks",
  "phoenix",
  "plaid",
  "foam",
  "sticky",
  "distant",
  "shiny",
  "leather",
  "lamp",
] as const;

/**
 * Same prompt identity and same meaning, but source Japanese labels differ.
 * Keep these as one canonical runtime option and preserve alternate Japanese
 * terms for search.
 */
export const auditedTranslationVariantEnglish = [
  "nipple clamps",
  "mandarin collar",
] as const;

// Translation variants no longer restore a second dictionary category merely
// because an older source file placed the same concept there. Category ownership
// decides browsing location; alternate Japanese labels remain searchable.
const auditedTranslationVariantCategoryReferenceEnglish = [] as const;

/**
 * Legacy typo corrections that collapse into an already-existing canonical
 * prompt still need their source categories restored in the dictionary UI.
 * Keep them separate from the Phase 2 CATEGORY_ALIAS count.
 */
const auditedLegacyCorrectionCategoryReferenceEnglish = [
  "balcony",
] as const;

const auditedCategoryReferenceKeys = new Set<string>(
  [
    ...auditedCategoryAliasEnglish,
    ...auditedTranslationVariantCategoryReferenceEnglish,
    ...auditedLegacyCorrectionCategoryReferenceEnglish,
  ].map((en) => promptDedupeKey(en)),
);

export type PromptCategoryAliasOptionIds = ReadonlyMap<string, readonly string[]>;

export function isAuditedCategoryAlias(option: PromptOption): boolean {
  return !option.negative && auditedCategoryReferenceKeys.has(promptDedupeKey(option.en));
}

function addAliasReferences(
  targetCategories: PromptCategory[],
  canonicalCategories: PromptCategory[],
  aliasOptionIds: PromptCategoryAliasOptionIds,
): PromptCategory[] {
  const optionById = new Map(
    canonicalCategories.flatMap((category) => category.options).map((option) => [option.id, option] as const),
  );

  return targetCategories.map((category) => {
    const referencedIds = aliasOptionIds.get(category.id) ?? [];
    if (!referencedIds.length) return category;

    const existingIds = new Set(category.options.map((option) => option.id));
    const additions = referencedIds
      .map((id) => optionById.get(id))
      .filter((option): option is PromptOption => option !== undefined && !existingIds.has(option.id));

    return additions.length ? { ...category, options: [...category.options, ...additions] } : category;
  });
}

/**
 * Build the dictionary-only category view.
 *
 * 1. Restore audited CATEGORY_ALIAS references without duplicating runtime tags.
 * 2. Normalize old broad-category options into their current dedicated owner
 *    category for browsing only.
 *
 * Favorites, history, prompt output and runtime ids keep their original stable
 * identities because the underlying PromptOption objects are reused.
 */
export function applyPromptCategoryAliases(
  targetCategories: PromptCategory[],
  canonicalCategories: PromptCategory[],
  aliasOptionIds: PromptCategoryAliasOptionIds,
): PromptCategory[] {
  const requestedIds = new Set(targetCategories.map((category) => category.id));
  const fullyAliased = addAliasReferences(canonicalCategories, canonicalCategories, aliasOptionIds);
  const owned = applyDictionaryCategoryOwnership(fullyAliased);
  const byId = new Map(owned.map((category) => [category.id, category] as const));

  return [...requestedIds]
    .map((id) => byId.get(id))
    .filter((category): category is PromptCategory => Boolean(category));
}
