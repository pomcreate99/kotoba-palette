import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

type ToolId =
  | "infinite-scroll-memo"
  | "oc-setting-sheet"
  | "memo-to-markdown"
  | "prompt-atlas"
  | "japanese-name-maker";

const tools: Array<{
  id: ToolId;
  name: string;
  description: string;
  href: string;
  accent: string;
}> = [
  {
    id: "infinite-scroll-memo",
    name: "無限メモ",
    description: "思いつきをすぐ残せるメモ",
    href: "https://memo.tkblab.jp/",
    accent: "#d9e8ff",
  },
  {
    id: "oc-setting-sheet",
    name: "キャラ設定帳",
    description: "創作キャラクターの設定を整理",
    href: "https://chara.tkblab.jp/",
    accent: "#dcebdc",
  },
  {
    id: "memo-to-markdown",
    name: "メモ整形",
    description: "普通のメモをMarkdownへ整形",
    href: "https://markdown.tkblab.jp/",
    accent: "#f4d9d2",
  },
  {
    id: "prompt-atlas",
    name: "ことばパレット",
    description: "画像生成用の英日タグを選択",
    href: "https://kotoba.tkblab.jp/",
    accent: "#ffe7a8",
  },
  {
    id: "japanese-name-maker",
    name: "なまえ帳",
    description: "日本人名を条件からまとめて生成",
    href: "https://name.tkblab.jp/",
    accent: "#f5dfd8",
  },
];

export function ToolSwitcher({ current }: { current: ToolId }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [open]);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="tool-switcher-btn inline-flex h-9 shrink-0 items-center gap-2 rounded-full border border-black/10 bg-white/80 px-2.5 text-xs font-bold text-[#222] shadow-sm backdrop-blur transition hover:bg-white sm:px-3"
        aria-label="POM TOOLSのツール一覧を開く"
      >
        <span className="grid h-5 w-5 grid-cols-2 gap-[2px]" aria-hidden="true">
          <i className="rounded-[3px] bg-[#a5d3ff]" />
          <i className="rounded-[3px] bg-[#f6b7c3]" />
          <i className="rounded-[3px] bg-[#ffe59a]" />
          <i className="rounded-[3px] bg-[#b7e1d1]" />
        </span>
        <span className="hidden sm:inline">POM TOOLS</span>
      </button>

      {open && createPortal(
        <div
          className="fixed inset-0 z-[2147483647] flex min-h-[100dvh] w-screen items-stretch justify-center overflow-y-auto bg-[#1f2621]/70 p-0 [isolation:isolate]"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setOpen(false);
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="pom-tools-title"
            className="min-h-[100dvh] w-full max-w-none bg-[#faf9f6] px-5 py-7 text-[#171717] shadow-2xl sm:px-[max(2rem,calc((100vw-58rem)/2))] sm:py-12"
          >
            <div className="mx-auto flex max-w-3xl items-start justify-between gap-4">
              <div>
                <p className="text-[10px] font-bold tracking-[0.2em] text-[#777]">CREATIVE WEB TOOLS</p>
                <h2 id="pom-tools-title" className="mt-1 text-2xl font-bold tracking-tight">POM TOOLS</h2>
                <p className="mt-1 text-xs leading-5 text-[#666]">使いたいツールを選んで移動できます。</p>
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-[#eceae5] text-lg font-bold"
                aria-label="ツール一覧を閉じる"
              >
                ×
              </button>
            </div>

            <div className="mx-auto mt-8 grid max-w-3xl gap-3 sm:grid-cols-2">
              {tools.map((tool) => {
                const isCurrent = tool.id === current;
                const content = (
                  <>
                    <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: tool.accent }} />
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-bold">{tool.name}</span>
                      <span className="mt-0.5 block text-[11px] leading-4 text-[#707070]">{tool.description}</span>
                    </span>
                    <span className="shrink-0 text-[10px] font-bold text-[#777]">{isCurrent ? "使用中" : "開く →"}</span>
                  </>
                );

                return isCurrent ? (
                  <div key={tool.id} aria-current="page" className="flex min-h-[72px] items-center gap-3 rounded-2xl border-2 border-[#222] bg-white px-3.5 py-3">
                    {content}
                  </div>
                ) : (
                  <a key={tool.id} href={tool.href} className="flex min-h-[72px] items-center gap-3 rounded-2xl border border-black/10 bg-white px-3.5 py-3 transition hover:-translate-y-0.5 hover:border-black/25 hover:shadow-md">
                    {content}
                  </a>
                );
              })}
            </div>
          </section>
        </div>,
        document.body,
      )}
    </>
  );
}
