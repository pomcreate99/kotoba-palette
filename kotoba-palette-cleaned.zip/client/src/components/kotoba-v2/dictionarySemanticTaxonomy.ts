import type { PromptCategory, PromptOption } from "@/lib/prompt-data";
import type { DictionarySection } from "./dictionaryTaxonomy";

type SemanticRule = {
  id: string;
  ja: string;
  en: string;
  terms: string[];
};

const semanticRules: Record<string, SemanticRule[]> = {
  quality: [
    { id: "grade", ja: "品質評価", en: "Quality grade", terms: ["masterpiece", "best quality", "amazing quality", "great quality", "perfect quality", "professional", "award-winning", "studio quality", "official art", "masterful", "polished", "score", "aesthetic"] },
    { id: "resolution", ja: "解像度", en: "Resolution", terms: ["highres", "ultradetailed", "finelydetailed", "absurdres", "4k", "8k", "16k", "uhd", "high definition", "ultra HD"] },
    { id: "detail", ja: "精細さ・シャープさ", en: "Detail & sharpness", terms: ["detail", "intricate", "sharp", "crisp", "clear", "focus"] },
    { id: "render", ja: "写実・媒体品質", en: "Rendering quality", terms: ["realistic", "photo", "film still", "movie still", "cinematic", "illustration", "concept art", "anime screenshot", "safe", "sensitive"] },
    { id: "era", ja: "年代・レーティング", en: "Era & rating", terms: ["year", "recent", "1980s", "1990s", "2000s", "retro artstyle"] },
    { id: "depth", ja: "構図・立体感", en: "Depth & composition", terms: ["composition", "lighting", "depth", "volume", "texture"] },
  ],
  physique: [
    { id: "frame", ja: "身長・骨格", en: "Height & frame", terms: ["tall", "short", "petite", "slender", "broad", "delicate", "frame", "build", "stature", "graceful", "giantess"] },
    { id: "muscle", ja: "筋肉・引き締まり", en: "Muscle & tone", terms: ["muscular", "athletic", "toned", "ripped", "defined muscle", "abs", "strong", "biceps"] },
    { id: "torso", ja: "胴体・腰", en: "Torso & waist", terms: ["waist", "hip", "shoulder", "chest", "belly", "midsection", "curvy"] },
    { id: "limbs", ja: "脚・腕", en: "Limbs", terms: ["thigh", "leg", "calf", "arm", "feet", "collarbone", "neck"] },
  ],
  skin: [
    { id: "tone", ja: "肌色", en: "Skin tone", terms: ["pale", "fair", "light skin", "medium skin", "tan", "dark skin", "porcelain", "olive", "brown skin"] },
    { id: "finish", ja: "肌の質感", en: "Skin finish", terms: ["flawless", "smooth", "soft skin", "glossy", "shiny", "wet", "oiled", "sweaty", "dewy", "subsurface"] },
    { id: "marks", ja: "痕・特徴", en: "Marks & features", terms: ["freckle", "scar", "mole", "tattoo", "mark", "tanline", "goosebump"] },
  ],
  "face-detail": [
    { id: "structure", ja: "顔立ち", en: "Facial structure", terms: ["facial", "face", "nose", "jaw", "chin", "dimple", "wrinkle"] },
    { id: "lips", ja: "唇・口元", en: "Lips", terms: ["lip", "mouth"] },
    { id: "eyes", ja: "目元・メイク", en: "Eyes & makeup", terms: ["eye", "eyelid", "eyeliner", "mascara", "eyeshadow", "makeup", "foundation", "highlighter"] },
    { id: "skin", ja: "頬・肌の特徴", en: "Skin details", terms: ["freckle", "mole", "scar", "blush", "cheek", "pale", "tanned", "bandage"] },
    { id: "expression", ja: "表情", en: "Expression", terms: ["smile", "reaction", "exaggerated"] },
  ],
  "eye-shape": [
    { id: "shape", ja: "目の形・大きさ", en: "Shape & size", terms: ["round", "almond", "upturned", "downturned", "wide eyes", "narrow", "large", "small", "fox eyes", "doe eyes", "cat eyes", "sharp eyes", "soft eyes", "tsurime", "tareme", "sanpaku", "crazy eyes", "beautiful eyes"] },
    { id: "lid-lash", ja: "まぶた・まつ毛", en: "Lids & lashes", terms: ["hooded", "monolid", "eyelid", "eyelash", "aegyo", "under-eye"] },
    { id: "gaze", ja: "視線", en: "Gaze", terms: ["looking", "gaze", "glance", "wink", "one eye closed"] },
    { id: "state", ja: "目の状態・印象", en: "Eye state", terms: ["sleepy", "half-closed", "half-lidded", "closed eyes", "droopy", "gentle eyes", "emotional", "distant"] },
    { id: "effect", ja: "瞳・特殊表現", en: "Pupils & effects", terms: ["sparkling", "teary", "empty eyes", "glass-like", "expressive", "detailed eyes", "pupil", "slit", "sclera", "dilated"] },
  ],
  headwear: [
    { id: "hats", ja: "帽子", en: "Hats", terms: ["hat", "cap", "beanie", "beret", "fedora", "bonnet", "bowler", "panama", "cowboy", "sunhat", "bucket", "newsboy", "cloche"] },
    { id: "hair-accessory", ja: "髪飾り", en: "Hair accessories", terms: ["hairclip", "hairband", "flowercrown", "tiara", "hairribbon", "scrunchie", "hairpin", "barrette", "comb", "ornament"] },
    { id: "covering", ja: "頭部を覆う物", en: "Head coverings", terms: ["helmet", "visor", "hood", "headscarf", "bandana"] },
    { id: "fantasy", ja: "耳・角・特殊頭部", en: "Fantasy headwear", terms: ["ears", "ear", "horn", "headpiece", "halo"] },
  ],
  "accessory-detail": [
    { id: "jewelry", ja: "ジュエリー", en: "Jewelry", terms: ["bracelet", "brooch", "ring", "necklace", "earring", "choker", "pendant"] },
    { id: "bags", ja: "バッグ", en: "Bags", terms: ["bag", "tote", "satchel", "purse", "wallet"] },
    { id: "utility", ja: "実用品・小物", en: "Utility", terms: ["watch", "belt", "badge", "lanyard", "keychain"] },
    { id: "hair", ja: "髪まわり", en: "Hair accessories", terms: ["hairpin", "barrette", "comb"] },
  ],
  "creature-features": [
    { id: "countershade", ja: "カウンターシェード", en: "Countershade", terms: ["countershading", "countershade", "underbelly", "cream chest", "white chest"] },
    { id: "pattern-markings", ja: "模様・マーキング", en: "Pattern markings", terms: ["striped", "stripes", "glowing stripes", "spots", "spotted", "rosettes", "blaze", "piebald", "calico", "tabby", "brindle", "speckles", "patches", "socks marking", "gloves marking", "mask marking", "muzzle marking", "saddle marking", "dorsal stripe", "tail tip", "tipped", "tuft", "inner ear fluff"] },
    { id: "fur-texture", ja: "体毛の質感", en: "Fur texture", terms: ["fluffy fur", "soft fur", "sleek fur", "shaggy fur", "long fur", "short fur", "thick fur", "sparse fur", "wet fur", "messy fur", "groomed fur", "fur detail", "detailed fur", "extremely detailed fur", "body fur", "wool", "feathers"] },
    { id: "fur-color", ja: "体毛色", en: "Fur color", terms: ["fur"] },
    { id: "body-color", ja: "体色", en: "Body color", terms: ["white body", "black body", "grey body", "brown body", "tan body", "orange body", "cream body", "two tone body", "multicolored body", "monotone body"] },
    { id: "anatomy-furry", ja: "ケモノ部位", en: "Furry anatomy", terms: ["snout", "muzzle", "nose", "whiskers", "paw", "pointy ears", "floppy ears", "bushy tail", "multiple tails", "animal hands", "digitigrade legs", "animal eyes"] },
    { id: "tentacles", ja: "触手", en: "Tentacles", terms: ["tentacle", "sucker"] },
    { id: "aquatic", ja: "水生特徴", en: "Aquatic", terms: ["fin", "gill", "webbed", "fish tail", "mermaid tail", "scale"] },
    { id: "beast", ja: "翼・角・牙・尾", en: "Wings, horns & tails", terms: ["wing", "horn", "tail", "claw", "fang", "teeth"] },
    { id: "insect", ja: "昆虫・多肢", en: "Insect & multi-limb", terms: ["antenna", "compound eyes", "multiple eyes", "extra arms", "multiple arms", "spider legs", "chitin", "exoskeleton"] },
    { id: "soft-plant", ja: "軟体・植物", en: "Soft body & plant", terms: ["slime", "translucent body", "gelatinous", "vine", "flower on head", "leaves for hair", "bark skin"] },
    { id: "otherworldly", ja: "発光・異質な身体", en: "Otherworldly", terms: ["bioluminescent", "glowing", "rune", "ethereal", "semi-transparent", "mist form", "shadow form", "crystalline", "stone skin", "metallic skin"] },
    { id: "general-markings", ja: "マーキング全般", en: "General markings", terms: ["markings", "marking"] },
  ],
  "shot-distance": [
    { id: "wide", ja: "遠景・ワイド", en: "Wide", terms: ["extreme wide", "wide shot", "long shot", "establishing"] },
    { id: "full", ja: "全身〜膝上", en: "Full", terms: ["full shot", "full body", "cowboy", "medium full"] },
    { id: "medium", ja: "中距離", en: "Medium", terms: ["medium shot", "waist shot", "upper body", "bust shot"] },
    { id: "close", ja: "クローズアップ", en: "Close-up", terms: ["medium close-up", "close-up", "headshot", "face focus", "portrait shot"] },
    { id: "special", ja: "視点・複数人", en: "Perspective & groups", terms: ["over the shoulder", "point of view", "insert shot", "two shot", "group shot"] },
  ],
  coloring: [
    { id: "format", ja: "表現形式", en: "Format", terms: ["digital painting", "visual novel style", "game illustration", "editorial illustration", "anime illustration", "key visual style", "light novel cover", "doujin style", "webtoon style", "manhwa style", "children's book illustration", "poster art", "cover art"] },
    { id: "realism", ja: "写実度", en: "Realism", terms: ["anime-style", "cartoonish", "semi-realistic", "near-realistic", "stylized realism", "painterly realism", "photographic realism", "hyper detailed realism"] },
    { id: "palette", ja: "色味・パレット", en: "Palette", terms: ["soft colors", "pastel colors", "washed out", "greyscale", "grayscale", "warm colors", "cool colors", "vibrant colors", "bold colors", "matte colors", "glossy colors", "color separation", "pastel pink", "pastel blue", "pastel purple", "pastel yellow", "ink-wash blues", "spot color"] },
    { id: "coloring", ja: "塗り・シェーディング", en: "Coloring & shading", terms: ["flat coloring", "anime coloring", "cel shading", "soft shading", "hard shading", "gradient shading", "painterly rendering", "blended shading", "airbrushed shading", "textured painting", "impasto", "watercolor wash", "ink wash shading", "screentone shading", "hatching shading", "cross-hatching", "toon shading", "smooth shading", "rough shading", "sketch coloring", "flat shading", "no shading", "manga coloring", "cel coloring", "semi-painterly", "soft painting", "blended painting", "selective coloring", "partially colored", "anime render", "realistic coloring"] },
    { id: "shadow", ja: "陰影・光の回り込み", en: "Shadows", terms: ["minimal shading", "subtle shading", "dramatic shading", "high-contrast shading", "soft facial shadows", "hard-edged shadows", "ambient occlusion", "rim shadows", "cast shadows", "core shadows", "reflected light", "subsurface scattering", "deep shadows", "soft shadows", "sharp shadows"] },
    { id: "line", ja: "線画・アウトライン", en: "Line art", terms: ["lineart", "linework", "sketchy lines", "rough linework", "lineless", "outlines", "broken lines", "flowing lines", "inked lines", "pencil lines", "contour lines", "crosshatching", "construction lines", "loose sketch"] },
    { id: "finish", ja: "仕上げ", en: "Finish", terms: ["finish", "highly detailed rendering", "simplified rendering", "dramatic rendering", "clean cel shading", "detailed shading", "soft realistic shading", "pencil drawing style", "rough brushwork", "scratchy brushstrokes", "glossy highlights", "semi-realistic anime", "muted colors", "dull colors", "low saturation", "gothic lolita illustration style", "trendy modern illustration", "visible brushstrokes", "brush strokes", "minimal portrait", "airy rendering", "soft portrait", "painted textures", "metallic highlights", "layered collage", "screen-print"] },
  ],
  design: [
    { id: "ornate", ja: "装飾・高密度", en: "Ornate", terms: ["ornate", "ornamental", "decorative", "luxurious", "opulent", "refined", "delicate", "intricate", "lace-like", "filigree", "engraved", "embossed", "relief"] },
    { id: "minimal", ja: "ミニマル・クリーン", en: "Minimal & clean", terms: ["minimalist", "clean design", "sleek", "subtle", "negative space"] },
    { id: "layout", ja: "形・レイアウト", en: "Shape & layout", terms: ["organic", "geometric", "symmetrical", "asymmetrical", "layered", "silhouette", "high contrast"] },
    { id: "historic", ja: "歴史・地域様式", en: "Historic & regional", terms: ["baroque", "art nouveau", "art deco", "gothic", "victorian", "japanese", "chinese", "scandinavian"] },
    { id: "modern", ja: "近現代・工業", en: "Modern & industrial", terms: ["industrial", "brutalist", "futuristic", "modern", "contemporary"] },
    { id: "aesthetic", ja: "雰囲気・美学", en: "Aesthetic", terms: ["rustic", "retro", "vintage", "whimsical", "soft aesthetic", "hard aesthetic", "ethereal", "dark design", "bright design", "pastel", "neon", "monochrome", "bold design"] },
  ],
  medium: [
    { id: "digital", ja: "デジタル・3D", en: "Digital & 3D", terms: ["digital", "vector", "raster", "3d", "cgi", "octane", "unreal", "blender", "render"] },
    { id: "paint", ja: "絵具・彩色", en: "Paint", terms: ["watercolor", "oil", "gouache", "acrylic", "tempera", "fresco", "pastel", "palette knife", "poster paint", "poster-color", "wash"] },
    { id: "drawing", ja: "描画・インク", en: "Drawing & ink", terms: ["sketch", "ink", "charcoal", "pencil", "marker", "ballpoint", "brush pen", "sumi", "crayon", "hand-drawn", "hand-painted", "chalk"] },
    { id: "print", ja: "版画・工芸", en: "Print & craft", terms: ["linocut", "woodcut", "etching", "screenprint", "mosaic", "stained glass", "embroidery", "collage"] },
    { id: "photo", ja: "写真・立体", en: "Photography & sculpture", terms: ["photography", "sculpture"] },
  ],
  mood: [
    { id: "positive", ja: "明るい・親しみ", en: "Positive", terms: ["kawaii", "cute", "beautiful", "playful", "romantic", "hopeful", "peaceful", "cozy", "lively", "triumphant"] },
    { id: "dreamy", ja: "静謎・幻想", en: "Serene & dreamy", terms: ["serene", "mysterious", "mystical", "dreamy", "hazy", "nostalgic", "whimsical", "chill", "quiet", "ethereal"] },
    { id: "dark", ja: "暗い・不穏", en: "Dark", terms: ["melancholic", "eerie", "tense", "ominous", "lonely", "dark", "haunting", "tragic", "absurd", "uncanny"] },
    { id: "dramatic", ja: "力強い・劇的", en: "Dramatic", terms: ["dramatic", "powerful", "epic", "solemn", "comedic", "surreal"] },
    { id: "temperature", ja: "温度・質感", en: "Temperature & feel", terms: ["warm", "cold", "soft", "harsh", "bright"] },
  ],
  interior: [
    { id: "home", ja: "住居", en: "Home", terms: ["kitchen", "bathroom", "hallway", "bedroom", "livingroom", "diningroom", "study", "attic", "basement", "closet", "wardrobe", "balcony", "veranda", "loft", "studioapartment"] },
    { id: "public", ja: "仕事・公共空間", en: "Work & public", terms: ["office", "cafe", "restaurant", "laboratory", "gym", "workshop", "theater", "greenhouse", "library"] },
    { id: "japanese", ja: "和風空間", en: "Japanese", terms: ["tatami", "washitsu", "genkan", "ofuro", "sento", "onsen", "ryokan", "engawa"] },
    { id: "hotel", ja: "宿泊", en: "Hotel", terms: ["hotelroom", "suite"] },
  ],
  scenery: [
    { id: "structure", ja: "建造物・街路", en: "Structures", terms: ["streetlamp", "fountain", "archway", "bridge", "gate"] },
    { id: "furniture", ja: "家具", en: "Furniture", terms: ["bookshelf", "staircase", "bench", "table", "sofa", "bed", "desk", "chair"] },
    { id: "textile", ja: "窓・布物", en: "Windows & textiles", terms: ["window", "curtain", "blinds", "rug", "carpet"] },
    { id: "decor", ja: "装飾・照明", en: "Decor & lighting", terms: ["fireplace", "piano", "signboard", "vendingmachine", "clock", "mirror", "painting", "poster", "calendar", "lamp", "chandelier", "candle", "incense"] },
    { id: "plants", ja: "植物", en: "Plants", terms: ["plant", "flowerpot"] },
    { id: "tableware", ja: "茶器", en: "Tea ware", terms: ["teapot", "teacup"] },
  ],
  "lighting-detail": [
    { id: "time", ja: "時間帯の光", en: "Time-based light", terms: ["goldenhour", "bluehour", "moonlight", "tropical daylight"] },
    { id: "source", ja: "光源", en: "Light sources", terms: ["firelight", "spotlight", "practical lighting", "windowlight", "streetlight", "torchlight", "bioluminescence"] },
    { id: "direction", ja: "方向・配置", en: "Direction", terms: ["underlighting", "sidelighting", "splitlighting"] },
    { id: "key", ja: "キー・露出傾向", en: "Key", terms: ["lowkey", "highkey", "ambient"] },
    { id: "dramatic", ja: "演出照明", en: "Dramatic", terms: ["noir lighting", "chiaroscuro"] },
  ],
  world: [
    { id: "historical", ja: "歴史・地域", en: "Historic & regional", terms: ["historical", "medieval", "western", "wuxia", "mythology"] },
    { id: "future", ja: "SF・未来", en: "Sci-fi & future", terms: ["scifi", "biopunk", "solarpunk", "dieselpunk", "dystopian", "dystopia", "apocalypse", "post-apocalyptic", "utopia"] },
    { id: "fantasy", ja: "ファンタジー", en: "Fantasy", terms: ["isekai", "darkfantasy", "gothic fantasy", "magical girl"] },
    { id: "genre", ja: "物語ジャンル", en: "Story genre", terms: ["school life", "slice of life", "romance", "adventure", "thriller", "mystery", "comedy", "drama", "yuri", "yaoi"] },
    { id: "aesthetic", ja: "コア・ウェーブ系", en: "Cores & waves", terms: ["kawaiipunk", "flowerpunk", "vaporwave", "synthwave", "trillwave", "retrowave", "happycore", "auroracore", "dreamcore", "weirdcore", "darkacademia"] },
  ],
  optics: [
    { id: "lens", ja: "レンズ・デジタル効果", en: "Lens & digital", terms: ["lensflare", "chromatic", "scanlines", "glitch", "lightleaks", "anamorphic"] },
    { id: "exposure", ja: "露光・焦点", en: "Exposure & focus", terms: ["exposure", "tiltshift", "softfocus", "dof"] },
    { id: "light", ja: "光線・ボケ", en: "Light & bokeh", terms: ["backlit", "sunrays", "bokeh", "godrays", "volumetric", "crepuscular"] },
    { id: "atmosphere", ja: "霧・煙・空気", en: "Atmosphere", terms: ["haze", "fog", "mist", "smoke", "steam", "dust"] },
    { id: "particles", ja: "粒子・舞うもの", en: "Particles", terms: ["embers", "sparks", "fireflies", "particles", "confetti", "falling petals", "falling leaves", "snowflakes", "raindrops", "waterdrops", "bubbles", "foam", "sparkle", "glitter", "pollen", "rain streaks", "snow particles", "cherry blossom petals"] },
  ],
  "adult-body": [
    { id: "frame", ja: "体格・身長", en: "Frame", terms: ["body", "frame", "build", "stature", "slim", "athletic", "muscular", "toned", "plump", "voluptuous", "curvy"] },
    { id: "waist", ja: "胴体・腰", en: "Torso & waist", terms: ["waist", "hip", "belly", "midsection", "chest", "abs"] },
    { id: "limbs", ja: "脚・腕・肩", en: "Limbs", terms: ["thigh", "calf", "leg", "arm", "shoulder", "collarbone", "neck", "feet", "soles"] },
    { id: "posture", ja: "身体の姿勢", en: "Body posture", terms: ["arched back"] },
  ],
  "adult-chest": [
    { id: "size", ja: "胸の大きさ・形", en: "Breast size & shape", terms: ["breasts", "sideboob", "underboob"] },
    { id: "cleavage", ja: "谷間", en: "Cleavage", terms: ["cleavage", "between breasts"] },
    { id: "nipple", ja: "乳首・乳輪", en: "Nipples & areola", terms: ["nipple", "areola"] },
    { id: "exposure", ja: "露出", en: "Exposure", terms: ["topless"] },
  ],
  "adult-genitals": [
    { id: "male", ja: "男性器", en: "Male anatomy", terms: ["penis", "foreskin", "circumcised", "testicle", "balls", "bulge"] },
    { id: "female", ja: "女性器", en: "Female anatomy", terms: ["vulva", "labia", "clitoris", "pussy", "cameltoe"] },
    { id: "rear", ja: "臀部・肛門", en: "Rear", terms: ["anus", "ass", "buttock"] },
    { id: "hair", ja: "陰毛・剃毛", en: "Pubic hair", terms: ["pubic hair", "shaved", "bush"] },
  ],
  "adult-skin": [
    { id: "surface", ja: "肌の質感", en: "Skin surface", terms: ["skin", "nude", "shiny", "glistening", "oiled", "wet", "sweaty", "soft", "firm"] },
    { id: "marks", ja: "痕・反応", en: "Marks & reactions", terms: ["freckle", "stretch mark", "scar", "love bite", "rope mark", "reddened", "goosebump", "trembling", "tanline"] },
    { id: "hair", ja: "体毛", en: "Body hair", terms: ["body hair", "chest hair", "happy trail", "armpit"] },
    { id: "parts", ja: "身体部位", en: "Body parts", terms: ["navel", "torso", "back", "shoulder", "hip", "thigh"] },
  ],
  "adult-reaction": [
    { id: "face", ja: "表情・呼吸", en: "Face & breathing", terms: ["ahegao", "orgasm face", "flushed face", "breathing", "tongue out", "tears"] },
    { id: "saliva", ja: "唾液", en: "Saliva", terms: ["saliva", "drool"] },
    { id: "fluids", ja: "体液表現", en: "Fluids", terms: ["precum", "cum", "creampie", "facial"] },
  ],
  "adult-anatomy": [
    { id: "exposure", ja: "露出・全身", en: "Exposure", terms: ["adult", "nude", "topless"] },
    { id: "torso", ja: "胴体", en: "Torso", terms: ["breast", "cleavage", "torso", "abs", "pectorals", "curves", "shoulder", "back", "collarbone", "navel"] },
    { id: "lower", ja: "腰・脚・臀部", en: "Lower body", terms: ["buttock", "thigh", "hip"] },
    { id: "skin", ja: "肌・質感", en: "Skin & texture", terms: ["skin", "tanline", "shiny", "glistening", "sweaty", "wet", "oiled", "soft", "firm"] },
    { id: "build", ja: "体格", en: "Build", terms: ["muscular", "plump", "slim", "athletic", "voluptuous", "petite", "tall", "short", "waist", "legs"] },
  ],
  "adult-mood": [
    { id: "desire", ja: "官能・欲望", en: "Desire", terms: ["sensual", "seductive", "erotic", "provocative", "sultry", "flirtatious", "aroused", "passionate", "alluring", "desire", "hungry"] },
    { id: "romance", ja: "親密・ロマンチック", en: "Intimacy", terms: ["intimate", "tender", "romantic", "yearning", "playful", "gentle", "warm"] },
    { id: "emotion", ja: "感情・状態", en: "Emotion & state", terms: ["breathless", "anticipation", "confident", "relaxed", "glamorous", "vulnerable", "shy", "bold", "intense", "fierce", "satiated", "exhausted", "energized", "drowsy", "awake", "dreamy", "lucid", "lost"] },
    { id: "texture", ja: "身体感覚・質感", en: "Physical feel", terms: ["rough", "slow", "urgent", "soft", "hard", "hot", "cold", "wet", "dry", "sweaty", "sticky", "slick", "smooth"] },
    { id: "social", ja: "開放・支配・関係", en: "Social dynamic", terms: ["private", "found", "hidden", "exposed", "covered", "revealed", "secret", "open", "closed", "inviting", "rejecting", "accepting", "surrendering", "dominating", "submitting", "equal"] },
    { id: "tone", ja: "場面の調子", en: "Scene tone", terms: ["serious", "casual", "formal", "ritual", "spontaneous", "planned", "accidental", "intentional"] },
  ],
};

function normalize(value: string): string {
  return value.toLowerCase().replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim();
}

function termMatches(option: PromptOption, term: string): boolean {
  const value = normalize(option.en);
  const target = normalize(term);
  if (!target) return false;
  if (target.includes(" ")) return value.includes(target);

  const tokens = value.split(" ");
  if (target.length <= 3) {
    return tokens.some((token) => token === target || token.startsWith(target));
  }
  return value.includes(target);
}

export function buildSemanticDictionarySections(category?: PromptCategory): DictionarySection[] | undefined {
  if (!category) return undefined;
  const categoryRules = semanticRules[category.id];
  if (!categoryRules) return undefined;

  const used = new Set<string>();
  const sections = categoryRules
    .map((rule) => {
      const optionIds = category.options
        .filter((option) => {
          if (used.has(option.id)) return false;
          const matched = rule.terms.some((term) => termMatches(option, term));
          if (matched) used.add(option.id);
          return matched;
        })
        .map((option) => option.id);
      return { id: rule.id, ja: rule.ja, en: rule.en, optionIds };
    })
    .filter((section) => section.optionIds.length > 0);

  const other = category.options.filter((option) => !used.has(option.id)).map((option) => option.id);
  if (other.length) sections.push({ id: "other", ja: "その他", en: "Other", optionIds: other });
  return sections;
}

export function hasSemanticTaxonomy(categoryId: string): boolean {
  return Boolean(semanticRules[categoryId]);
}
