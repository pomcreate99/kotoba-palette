import type { PromptCategory, PromptOption } from "@/lib/prompt-data";
import type { DictionarySection } from "./dictionaryTaxonomy";

type Rule = { id: string; ja: string; en: string; terms: string[] };

const rules: Record<string, Rule[]> = {
  composition: [
    { id: "layout", ja: "配置・構図", en: "Layout", terms: ["symmetry", "asymmetry", "ruleofthirds", "negativespace", "centered", "diagonal", "framing", "cropped", "layered", "minimal", "dynamic", "asymmetric composition", "dynamic diagonal"] },
    { id: "perspective", ja: "遠近・歪み", en: "Perspective", terms: ["extreme low angle", "dramatic foreshortening", "fisheye distortion", "barrel distortion", "extreme dutch angle"] },
    { id: "crop", ja: "フレーム・切り取り", en: "Frame & crop", terms: ["head out of frame", "silhouette"] },
    { id: "focus", ja: "焦点・ボケ", en: "Focus", terms: ["extreme bokeh"] },
    { id: "background", ja: "背景・演出要素", en: "Background elements", terms: ["starry sky", "shooting star", "light particles", "rose petals", "constellation", "aurora", "grand staircase", "mansion interior", "dim cafe interior"] },
    { id: "comic", ja: "漫画演出", en: "Comic", terms: ["reaction panel"] },
  ],
  clothing: [
    { id: "headwear", ja: "帽子・頭まわり", en: "Headwear", terms: ["hat", "cap", "beanie", "beret", "fedora", "bonnet", "headdress", "headband", "helmet", "toque", "earmuffs", "goggles on head", "visor"] },
    { id: "footwear", ja: "靴・脚まわり", en: "Footwear & hosiery", terms: ["sneaker", "shoe", "boot", "loafer", "geta", "zori", "socks", "tights", "leg warmers", "arm warmers", "mary jane"] },
    { id: "bags", ja: "バッグ・収納", en: "Bags & carry", terms: ["bag", "backpack", "pouch", "purse", "tote", "suitcase", "luggage", "basket", "case", "bento box", "thermos", "water bottle", "instrument case", "sketchbook"] },
    { id: "accessory", ja: "装身具・小物", en: "Accessories", terms: ["belt", "scarf", "gloves", "mittens", "bracelet", "choker", "tie", "badge", "lanyard", "ribbon", "epaulettes", "name tag", "wristlet", "stethoscope", "neck gaiter", "cravat"] },
    { id: "traditional", ja: "和装・民族衣装", en: "Traditional", terms: ["kimono", "yukata", "haori", "hakama", "jinbei", "samue", "qipao", "miko", "shrine maiden"] },
    { id: "uniform", ja: "制服・職業服", en: "Uniform & workwear", terms: ["uniform", "nurse", "maid", "butler", "tactical", "apron", "lab coat", "chef", "flight attendant", "military", "scrub", "firefighter", "pilot", "police", "artist smock", "work jumpsuit", "coverall", "gardening"] },
    { id: "outer", ja: "アウター", en: "Outerwear", terms: ["jacket", "coat", "parka", "cardigan", "bolero", "cape", "capelet", "poncho", "cloak", "blazer", "windbreaker", "raincoat", "puffer", "sherpa"] },
    { id: "onepiece", ja: "ワンピース・セット", en: "One-piece & sets", terms: ["dress", "gown", "robe", "jumpsuit", "overalls", "dungarees", "jersey set", "yoga set", "sailor maid hybrid"] },
    { id: "tops", ja: "トップス", en: "Tops", terms: ["shirt", "t-shirt", "tee", "sweater", "hoodie", "sweatshirt", "vest", "waistcoat", "top", "blouse", "bodice"] },
    { id: "bottoms", ja: "ボトムス", en: "Bottoms", terms: ["pants", "shorts", "skirt", "skort", "joggers", "sweatpants"] },
    { id: "detail", ja: "衣服の細部", en: "Clothing details", terms: ["sleeves", "neckline", "collar", "lace", "petticoat", "frill", "ruffle", "tulle", "organza", "underskirt", "scalloped", "fitted", "layered"] },
  ],
  pose: [
    { id: "stance", ja: "姿勢・座り方", en: "Stance & posture", terms: ["standing", "sitting", "recline", "lying", "kneeling", "dogeza", "prostration", "perched", "lean", "windowsill", "bed edge", "elbows on table", "chin on table", "lotus sit", "open stance", "feet together", "parade rest", "attention"] },
    { id: "hands", ja: "手・サイン", en: "Hands & signs", terms: ["claw pose", "paw pose", "horns pose", "gyaru v", "double v", "v over eye", "finger", "facepalm", "chin rest", "head rest", "cheek", "praying hands", "clenched fist", "raised fist", "arms", "reaching out", "peace", "shaka", "wave", "fist bump", "pointing", "hands together", "stop gesture", "come here", "counting on fingers", "clap once", "crossed fingers"] },
    { id: "object", ja: "持ち物・物との動作", en: "Objects", terms: ["holding", "hold", "phone", "mug", "chopsticks", "gift", "umbrella", "book", "pen", "binder", "guitar", "watch", "camera", "map", "controller", "tablet", "bag strap", "luggage", "balloon", "toast", "ice cream", "watering can", "ticket", "shopping bags", "selfie stick", "paint brush", "microphone"] },
    { id: "grooming", ja: "身支度・衣服操作", en: "Grooming & dressing", terms: ["brushing hair", "tucking hair", "playing with hair", "twirling hair", "braiding hair", "tying hair", "applying makeup", "putting on lipstick", "adjusting collar", "putting on shoes", "tying laces", "scarf wrap", "sunglasses", "mask pull", "hood up", "jacket half on", "coat over shoulders", "glove remove", "adjusting glove", "putting on gloves", "sleeve tug", "necklace touch", "hat tip"] },
    { id: "activity", ja: "日常・創作動作", en: "Daily & creative activity", terms: ["reading", "writing", "typing", "texting", "gaming", "cooking", "pouring tea", "gardening", "note taking", "playing piano", "smelling flower", "blowing dandelion", "straw sip", "lollipop", "checking watch", "fishing", "marshmallow roast", "build snowman"] },
    { id: "sport", ja: "運動・ダンス", en: "Sports & movement", terms: ["kick", "skipping", "dashing", "handstand", "landing", "yoga", "meditation", "bicycle", "puddle jump", "arabesque", "skateboard", "dive pose", "acrobatic", "lunge", "balanced pose", "spinning", "twirl", "stretch", "toe touch", "hip hop", "ballet", "scooter", "roller skate", "float on back", "beach ball"] },
    { id: "performance", ja: "交流・演技・撮影", en: "Social & performance", terms: ["selfie", "group photo", "incoming hug", "idol pose", "cheer pose", "blowing kiss", "air kiss", "curtsey", "presentation pose", "stage pose", "welcome pose", "champion pose", "singing pose", "dance break", "polaroid pose", "taking photo"] },
    { id: "combat", ja: "戦闘・ファンタジー", en: "Combat & fantasy", terms: ["casting spell", "ready stance", "karate", "drawing sword", "sheathing sword", "archery", "aiming bow", "staff raise", "shield guard", "kendo", "villain pose", "zombie pose", "ghost pose", "superhero landing"] },
    { id: "rest", ja: "休息・季節の動作", en: "Rest & seasonal", terms: ["sleepy", "sunbathing", "stargazing", "campfire", "sunrise", "moon gaze", "sunset", "snow angel", "leaf pile", "yawning", "wake up", "spring stretch", "autumn walk"] },
  ],
  "adult-wardrobe": [
    { id: "goods", ja: "成人向けグッズ", en: "Adult goods", terms: ["dildo", "strap-on", "magic wand", "vibrator", "vibe", "anal beads", "anal plug", "butt plug", "massager", "sex machine", "fucking machine", "sybian", "onahole", "fleshlight", "masturbator", "cock ring", "penis ring", "sounding rod", "urethral plug", "enema", "speculum", "suction cups", "anal hook", "nose hook", "tongue clamp"] },
    { id: "restraints", ja: "拘束具・BDSM用品", en: "Restraints & BDSM gear", terms: ["gag", "blindfold", "restraint", "bondage", "rope", "armbinder", "hogtie", "spreader bar", "shackle", "cuff", "chastity", "nipple clamp", "nipple weight", "clothespins", "riding crop", "flogger", "paddle", "whip", "cane", "spanking bench", "andrew's cross", "bondage frame", "collar", "leash", "harness", "straitjacket", "sleepsack", "vacuum bed", "posture collar", "thumb cuffs", "toe tie", "tazuki", "body tape"] },
    { id: "piercing", ja: "ピアス・身体装飾", en: "Piercing & body accessories", terms: ["nipple ring", "piercing", "body chain", "waist chain", "henna body", "temporary tattoo"] },
    { id: "underwear", ja: "下着・ランジェリー", en: "Underwear & lingerie", terms: ["bra", "panties", "briefs", "boxers", "underwear", "lingerie", "thong", "gstring", "teddy", "pasties", "garter"] },
    { id: "hosiery", ja: "ストッキング・靴", en: "Hosiery & footwear", terms: ["stocking", "tights", "pantyhose", "fishnet", "kneehigh", "thighhigh", "socks", "heels", "boots", "shoes"] },
    { id: "bodywear", ja: "ボディウェア・ドレス", en: "Bodywear & dresses", terms: ["bodysuit", "bodystocking", "leotard", "bustier", "corset", "chemise", "babydoll", "camisole", "catsuit", "dress", "robe", "gown", "shirt", "blouse", "skirt", "leggings", "sweater"] },
    { id: "swim", ja: "水着・極小衣装", en: "Swimwear", terms: ["bikini", "microbikini", "micro bikini", "highleg", "high cut swimsuit", "swimsuit"] },
    { id: "material", ja: "素材・透け・濡れ", en: "Materials & transparency", terms: ["latex", "leather", "lace", "satin", "silk", "mesh", "sheer", "transparent", "translucent", "opaque", "wetlook", "wet look", "velvet", "vinyl", "rubber", "pvc", "holographic", "patent leather", "see-through"] },
    { id: "state", ja: "開き・ずらし・脱衣状態", en: "Open & displaced clothing", terms: ["open", "unbuttoned", "unzipped", "zip open", "pulled aside", "pulled up", "rolled down", "around one ankle", "scattered floor", "kicked off", "on floor", "clothes in mouth", "underwear on head", "wind lifted", "after sex clothes", "rear zip", "shirt tent", "tent in pants", "outline", "bulge", "cameltoe", "wedgie"] },
    { id: "fit", ja: "フィット・カットアウト", en: "Fit & cutouts", terms: ["tight", "loose", "fitted", "oversized", "strapless", "halter", "racerback", "toeless", "crotchless", "open crotch", "cutout", "keyhole", "sideboob", "underboob", "low rise", "high cut", "shelf bra", "cupless", "slitted", "compression"] },
    { id: "cow", ja: "牛モチーフ・搾乳", en: "Cow theme", terms: ["cow print", "cow girl", "hucow", "lactation", "milking", "breast pump", "udder"] },
    { id: "accessory", ja: "衣装小物", en: "Wardrobe accessories", terms: ["choker", "ribbon", "gloves", "belt", "mask", "hood", "body chain"] },
  ],
  "adult-pose": [
    { id: "restraints", ja: "拘束・BDSM", en: "Restraints & BDSM", terms: ["tied", "restrained", "bound", "blindfold", "cuff", "gag", "collar", "leash", "rope", "suspension", "ceiling restraint", "cage", "pet play", "human furniture", "footrest", "full nelson", "arm lock", "choking", "wax play"] },
    { id: "toys", ja: "玩具・セルフタッチ", en: "Toys & self touch", terms: ["vibrator", "toy", "masturbation", "fingering", "self touch", "strapon", "strap-on", "sybian", "machine sex", "plug", "anal beads", "wand", "pegging", "ice play", "feather tease"] },
    { id: "positions", ja: "成人向け体位・行為", en: "Adult positions", terms: ["missionary", "doggy", "cowgirl", "reverse cowgirl", "spooning sex", "standing carry sex", "scissoring", "penetration", "spitroast", "prone bone", "wheelbarrow", "tribbing", "tabletop sex", "standing doggy", "legs behind head", "happy baby sex", "hard thrust", "grinding deep", "lazy morning sex", "wake up sex", "quickie", "floor missionary"] },
    { id: "contact", ja: "接触・キス・抱擁", en: "Contact & intimacy", terms: ["kiss", "cuddle", "spoon nude", "body to body", "forehead touch", "makeout", "neck kiss", "ear kiss", "licking neck", "collarbone kiss", "biting shoulder", "possessive hold", "intimate"] },
    { id: "tease", ja: "脱衣・じらし・露出", en: "Tease & exhibition", terms: ["striptease", "undressing", "shirt lift", "skirt lift", "pull aside", "stockings only", "heels only", "exhibition", "flash", "cam show", "recording selfie nude", "mirror nude", "covering up after", "bra strap slip", "sauna towel slip"] },
    { id: "reaction", ja: "反応・事後・余韻", en: "Reactions & aftercare", terms: ["ahegao", "orgasm", "after", "creampie", "facial", "satisfied", "embarrassed", "aftercare", "afterglow", "sensitive", "overstimulated", "scratch marks", "hickey", "marking bites", "rope marks", "covered in fluids", "squirting", "drool", "blush", "mind break", "rolling eyes", "crossed eyes", "empty eyes", "muffled moan", "pleasure"] },
    { id: "location", ja: "場所・シチュエーション", en: "Locations", terms: ["wall", "mirror sex", "bathtub", "shower", "office", "hotel", "hot spring", "changing room", "rooftop", "car ", "kitchen", "locker", "fitting room", "elevator", "balcony", "sauna", "medical exam", "stirrups", "window", "semi public", "under desk", "capsule", "massage table", "on table", "on floor", "on bed"] },
    { id: "posture", ja: "姿勢・身体動作", en: "Posture & body movement", terms: ["arched back", "hip thrust", "grinding pose", "crawl", "begging", "legs spread", "legs wrapped", "ankle lock", "lifted by thighs", "back arch", "spread on table", "paws up", "sit up beg", "leg tangle", "lap dance"] },
  ],
};

function normalize(value: string): string {
  return value.toLowerCase().replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim();
}

function matches(option: PromptOption, term: string): boolean {
  const value = normalize(option.en);
  const target = normalize(term);
  if (target.includes(" ")) return value.includes(target);
  return value.split(" ").some((token) => token === target || token.startsWith(target));
}

export function buildDictionaryOverrideSections(category?: PromptCategory): DictionarySection[] | undefined {
  if (!category) return undefined;
  const categoryRules = rules[category.id];
  if (!categoryRules) return undefined;

  const used = new Set<string>();
  const sections = categoryRules
    .map((rule) => {
      const optionIds = category.options.filter((option) => {
        if (used.has(option.id)) return false;
        const matched = rule.terms.some((term) => matches(option, term));
        if (matched) used.add(option.id);
        return matched;
      }).map((option) => option.id);
      return { id: rule.id, ja: rule.ja, en: rule.en, optionIds };
    })
    .filter((section) => section.optionIds.length > 0);

  const other = category.options.filter((option) => !used.has(option.id)).map((option) => option.id);
  if (other.length) sections.push({ id: "other", ja: "その他", en: "Other", optionIds: other });
  return sections;
}

export function hasDictionaryOverrideTaxonomy(categoryId: string): boolean {
  return Boolean(rules[categoryId]);
}
