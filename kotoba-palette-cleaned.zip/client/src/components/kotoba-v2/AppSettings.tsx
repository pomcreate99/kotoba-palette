import { Moon, Sun } from "lucide-react";
import type { UiLanguage } from "./types";

type AppSettingsProps = {
  language: UiLanguage;
  onLanguageChange: (language: UiLanguage) => void;
  theme: "light" | "dark";
  onThemeToggle: () => void;
  contentMode: "sfw" | "nsfw";
  onSfw: () => void;
  onNsfw: () => void;
};

export function AppSettings({ language, onLanguageChange, theme, onThemeToggle, contentMode, onSfw, onNsfw }: AppSettingsProps) {
  return (
    <div className="kp-v2-settings" aria-label={language === "ja" ? "表示設定" : "Display settings"}>
      <div className="kp-v2-segment" aria-label="SFW / NSFW">
        <button type="button" className={contentMode === "sfw" ? "is-active" : ""} onClick={onSfw}>SFW</button>
        <button type="button" className={contentMode === "nsfw" ? "is-active is-adult" : ""} onClick={onNsfw}>NSFW</button>
      </div>
      <div className="kp-v2-segment" aria-label={language === "ja" ? "言語" : "Language"}>
        <button type="button" className={language === "ja" ? "is-active" : ""} onClick={() => onLanguageChange("ja")}>日本語</button>
        <button type="button" className={language === "en" ? "is-active" : ""} onClick={() => onLanguageChange("en")}>English</button>
      </div>
      <button type="button" className="kp-v2-theme-button" onClick={onThemeToggle} aria-label={theme === "light" ? "ダークモードに切り替え" : "ライトモードに切り替え"}>
        {theme === "light" ? <Moon aria-hidden="true" /> : <Sun aria-hidden="true" />}
      </button>
    </div>
  );
}
