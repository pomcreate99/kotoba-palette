import type { PromptCategory, PromptOption } from "@/lib/prompt-data";
import type { DictionarySection } from "./dictionaryTaxonomy";

type SafeRule = {
  id: string;
  ja: string;
  en: string;
  terms: string[];
};

const categoryRules: Record<string, SafeRule[]> = {
  subject: [
    { id: "furry", ja: "ファーリー", en: "Furry", terms: ["fursona", "animal focus"] },
    { id: "identity", ja: "人物・主題", en: "Subject", terms: ["person", "human", "portrait", "figure", "individual", "anonymous"] },
    { id: "count", ja: "人数", en: "Count", terms: ["solo", "couple", "group", "crowd", "1person", "2people", "multiple people"] },
    { id: "framing", ja: "見え方・向き", en: "Framing", terms: ["headshot", "bust shot", "half body", "full body", "profile view", "three quarter view", "facing viewer", "from behind", "silhouette"] },
  ],
  count: [
    { id: "gendered", ja: "性別人数", en: "Gendered count", terms: ["1girl", "1boy", "2girls", "2boys", "3girls", "3boys", "multiple girls", "multiple boys", "1other", "2others", "3others"] },
    { id: "number", ja: "人数", en: "Number", terms: ["solo", "pair", "duo", "couple", "twins", "trio", "group", "ensemble", "lineup", "crowd"] },
    { id: "focus", ja: "フォーカス", en: "Focus", terms: ["male focus", "female focus", "solo focus"] },
  ],
  demographics: [
    { id: "male", ja: "男性表現", en: "Male", terms: ["man", "male", "gentleman", "youngman", "oldman", "elderlyman", "boy", "malechild", "schoolboy", "masculine"] },
    { id: "female", ja: "女性表現", en: "Female", terms: ["woman", "female", "lady", "youngwoman", "oldwoman", "elderlywoman", "girl", "femalechild", "schoolgirl", "feminine"] },
    { id: "neutral", ja: "中性・その他", en: "Neutral & other", terms: ["androgynous", "nonbinary"] },
    { id: "age", ja: "年齢", en: "Age", terms: ["adult", "child", "teenager", "schoolchild", "elderly", "mature", "young adult"] },
  ],
  hair: [
    { id: "length", ja: "長さ", en: "Length", terms: ["longhair", "shorthair", "mediumhair"] },
    { id: "texture", ja: "髪質・状態", en: "Texture", terms: ["curly", "wavy", "straight", "messyhair", "wet hair", "shinyhair", "fluffyhair"] },
    { id: "arrange", ja: "髪型", en: "Styles", terms: ["ponytail", "braid", "bangs"] },
    { id: "color", ja: "髪色", en: "Color", terms: ["blonde", "brunette", "silverhair", "redhair", "blackhair", "whitehair", "pinkhair", "bluehair", "purplehair", "greenhair", "orangehair", "ashbrown", "platinum", "two-tone", "gradienthair"] },
  ],
  "hair-style": [
    { id: "length", ja: "長さ", en: "Length", terms: ["long hair", "very long hair", "medium hair", "short hair", "shoulder", "waist", "floor", "neck-length", "nape"] },
    { id: "texture", ja: "髪質・ボリューム", en: "Texture", terms: ["straight", "wavy", "curly", "coily", "spiky", "fluffy", "messy", "shiny", "wet", "silky", "airy", "feathered", "uneven strands"] },
    { id: "arrange", ja: "結び・まとめ髪", en: "Updos", terms: ["ponytail", "twintails", "braid", "bun", "top knot", "half up", "tied hair", "dreadlocks", "cornrow"] },
    { id: "cut", ja: "カット・輪郭", en: "Cuts", terms: ["bob cut", "pixie cut", "wolf cut", "hime cut", "layered", "undercut", "mullet", "afro", "buzz cut", "mohawk", "korean idol hairstyle"] },
    { id: "bangs", ja: "前髪・分け目", en: "Bangs & part", terms: ["bangs", "center part", "side part", "sidelocks", "ahoge", "face-framing strands"] },
    { id: "color", ja: "複色・髪色表現", en: "Color treatment", terms: ["gradient hair", "gradient animal", "inner white", "black and white", "icy silver"] },
  ],
  "hair-detail": [
    { id: "cuts", ja: "カット", en: "Cuts", terms: ["bobcut", "pixiecut", "mullet", "undercut", "buzzcut", "mohawk", "wolfcut", "shag", "layered", "hime cut"] },
    { id: "updos", ja: "結び・まとめ髪", en: "Updos", terms: ["bun", "braid", "ponytail", "twintails", "halfup", "cornrows", "dreadlocks"] },
    { id: "bangs", ja: "前髪・横髪", en: "Bangs", terms: ["bangs", "sidelocks", "ahoge"] },
    { id: "texture", ja: "ボリューム・質感", en: "Texture", terms: ["afro", "undone"] },
  ],
  "hair-color": [
    { id: "natural", ja: "自然色", en: "Natural", terms: ["black hair", "brown hair", "ash brown", "blonde", "auburn", "ginger", "copper", "white hair", "silver hair", "gray hair", "natural hair color"] },
    { id: "warm", ja: "赤・暖色", en: "Warm colors", terms: ["red hair", "orange hair", "burgundy", "strawberry blonde", "golden blonde"] },
    { id: "cool", ja: "青・緑・紫", en: "Cool colors", terms: ["blue hair", "navy hair", "purple hair", "lavender", "green hair", "mint hair", "teal hair", "silver hair with subtle blue tint"] },
    { id: "pink", ja: "ピンク系", en: "Pink", terms: ["pink hair", "hot pink"] },
    { id: "mixed", ja: "複色・特殊", en: "Mixed", terms: ["rainbow", "multicolored", "ombre", "gradient", "two-tone", "dyed hair"] },
  ],
  eyes: [
    { id: "color", ja: "瞳色", en: "Eye color", terms: ["amber", "emerald", "violet", "blueeyes", "browneyes", "grey eyes", "redeyes"] },
    { id: "gaze", ja: "視線", en: "Gaze", terms: ["looking", "gazing", "sideglance", "downcast"] },
    { id: "shape", ja: "開き方・形", en: "Shape", terms: ["wide", "closed", "halfclosed", "narrowedeyes"] },
    { id: "effect", ja: "特殊表現", en: "Effects", terms: ["glowing", "sparkling", "tearyeyes", "emptyeyes", "heterochromia"] },
  ],
  expression: [
    { id: "positive", ja: "笑顔・喜び", en: "Positive", terms: ["smiling", "joyful", "laughing", "grinning", "excited", "gentle", "confident", "softsmile", "doyagao", "smug", "ecstatic"] },
    { id: "negative", ja: "悲しみ・怒り", en: "Negative", terms: ["sad", "angry", "crying", "frowning", "nervous", "bored", "fierce", "annoyed", "furious", "shocked", "scared", "fear", "worried", "tired"] },
    { id: "quiet", ja: "静かな表情", en: "Quiet", terms: ["serious", "calm", "sleepy", "thoughtful", "determined", "shy"] },
    { id: "mouth", ja: "口元", en: "Mouth", terms: ["closedmouth", "openmouth", "tonguesout", "pouting", "smirk"] },
    { id: "face", ja: "顔色・目元", en: "Face", terms: ["blush", "embarrassed", "wideeyes", "surprised"] },
  ],
  role: [
    { id: "creative", ja: "創作・芸能", en: "Creative", terms: ["artist", "musician", "dancer", "idol", "model", "actor", "writer", "poet"] },
    { id: "service", ja: "日常・サービス", en: "Everyday jobs", terms: ["chef", "teacher", "barista", "gardener", "librarian", "mechanic", "doctor", "nurse", "student", "officeworker"] },
    { id: "science", ja: "科学・探索", en: "Science", terms: ["scientist", "pilot", "astronaut", "explorer", "inventor", "philosopher"] },
    { id: "fantasy", ja: "魔法・宗教", en: "Fantasy", terms: ["magician", "witch", "priest", "nun", "alchemist", "witchdoctor", "shaman", "oracle", "prophet"] },
    { id: "combat", ja: "戦闘・冒険", en: "Combat", terms: ["knight", "samurai", "ninja", "hero", "villain", "mercenary", "assassin", "thief", "pirate", "soldier", "general"] },
    { id: "royal", ja: "王族", en: "Royalty", terms: ["king", "queen", "prince", "princess", "emperor", "empress"] },
    { id: "story", ja: "物語上の役割", en: "Story roles", terms: ["antihero", "mentor", "apprentice", "captain", "detective", "athlete", "traveler"] },
  ],
  species: [
    { id: "furry", ja: "ファーリー・ケモノ", en: "Furry", terms: ["furry", "anthro", "feral", "kemono", "beastman", "animal humanoid", "humanoid", "semi-anthro", "taur", "digitigrade", "plantigrade", "unguligrade", "biped", "quadruped", "scalie", "chibikemo", "fox girl", "wolf girl", "cat boy", "red fox", "arctic fox", "mexican wolf", "canine", "feline", "mustelid", "lagomorph", "sergal", "protogen", "dutch angel dragon", "furry female", "furry male"] },
    { id: "aquatic", ja: "水生・蛇型", en: "Aquatic", terms: ["mermaid", "merman", "merfolk", "siren", "sea serpent", "kraken", "leviathan", "naga", "lamia", "selkie", "kelpie", "cephalopod", "octopus person", "squid person", "tentacle"] },
    { id: "celestial", ja: "天使・精霊", en: "Celestial", terms: ["angel", "fairy", "nymph", "dryad", "spirit", "elemental", "celestial"] },
    { id: "demonic", ja: "悪魔・吸血種", en: "Demonic", terms: ["demon", "vampire", "succubus", "incubus", "imp", "abyssal"] },
    { id: "beast", ja: "獣人・幻獣", en: "Beasts", terms: ["werewolf", "centaur", "dragon", "phoenix", "unicorn", "griffin", "sphinx", "minotaur", "satyr", "harpy", "wyvern", "basilisk", "cockatrice", "kirin", "qilin", "dragonkin", "half-dragon", "draconic"] },
    { id: "humanoid", ja: "亜人・獣人", en: "Humanoids", terms: ["elf", "dwarf", "halfling", "orc", "goblin", "troll", "ogre", "kobold", "giant", "person", "insectoid", "arachnid"] },
    { id: "undead", ja: "アンデッド", en: "Undead", terms: ["lich", "skeleton", "zombie", "ghost"] },
    { id: "yokai", ja: "妖怪・和風", en: "Yokai", terms: ["kitsune", "yokai", "oni", "tengu", "kappa", "nue", "bakeneko", "nekomata", "inari", "foxspirit", "baku", "tsuchigumo", "jorogumo", "yuki-onna", "nurarihyon", "amabie"] },
    { id: "construct", ja: "人工・軟体・植物", en: "Constructs & unusual beings", terms: ["slime", "gelatinous", "alraune", "plant person", "chimera", "hybrid", "homunculus", "golem", "automaton", "living doll"] },
    { id: "cosmic", ja: "異質・宇宙的", en: "Cosmic", terms: ["alien", "gorgon", "medusa", "cyclops", "titan", "shadow creature", "void entity", "eldritch", "outer god"] },
  ],
  animals: [
    { id: "mammal", ja: "単乳類", en: "Mammals", terms: ["dog", "cat", "fox", "horse", "rabbit", "wolf", "tiger", "lion", "elephant", "panda", "deer", "bear", "mouse", "rat", "hamster", "squirrel", "chipmunk", "hedgehog", "raccoon", "ferret", "otter", "seal", "walrus", "koala", "kangaroo", "giraffe", "zebra", "hippo", "rhino", "camel", "llama", "alpaca", "goat", "sheep", "cow", "pig", "bat", "flying fox", "leopard", "cheetah", "lynx", "hare", "pony", "skunk", "hyena"] },
    { id: "birds", ja: "鳥類", en: "Birds", terms: ["bird", "owl", "eagle", "hawk", "crow", "raven", "sparrow", "crane", "swan", "duck", "goose", "peacock", "chicken", "rooster", "penguin", "phoenix"] },
    { id: "aquatic", ja: "水生生物", en: "Aquatic", terms: ["whale", "fish", "shark", "dolphin", "octopus", "jellyfish", "crab", "squid", "cuttlefish", "nautilus", "sea anemone", "starfish", "sea urchin", "mantis shrimp", "eel", "ray", "seahorse", "coral"] },
    { id: "reptile", ja: "爬虫・両生類", en: "Reptiles & amphibians", terms: ["snake", "lizard", "frog", "turtle", "dragon", "axolotl", "salamander", "newt", "chameleon", "gecko", "iguana", "crocodile", "alligator"] },
    { id: "insect", ja: "昆虫・節足・軟体", en: "Insects & invertebrates", terms: ["butterfly", "moth", "dragonfly", "firefly", "bee", "ant", "spider", "scorpion", "mantis", "centipede", "millipede", "snail", "slug", "worm"] },
  ],
  machines: [
    { id: "computer", ja: "コンピュータ", en: "Computers", terms: ["computer", "server", "terminal", "console", "monitor", "keyboard", "mouse", "ai", "circuit"] },
    { id: "camera", ja: "撮影・音響機材", en: "Camera & audio gear", terms: ["camera", "lens", "tripod", "microphone", "headphones"] },
    { id: "vehicle", ja: "乗り物機械", en: "Vehicles", terms: ["drone", "helicopter", "jet", "engine"] },
    { id: "space", ja: "宇宙機", en: "Space", terms: ["satellite", "rocket", "spaceship", "starship"] },
    { id: "mecha", ja: "ロボット・メカ", en: "Robots & mecha", terms: ["robot", "mecha", "mech", "android", "cyborg", "exosuit", "powerarmor", "exoskeleton"] },
    { id: "cyber", ja: "身体拡張・ナノ", en: "Cybernetics", terms: ["prosthetic", "cybernetic", "nanomachine"] },
    { id: "mechanical", ja: "機構", en: "Mechanisms", terms: ["gear", "machine"] },
  ],
  clothing: [
    { id: "tops", ja: "トップス", en: "Tops", terms: ["shirt", "blouse", "sweater", "hoodie", "cardigan", "vest", "top", "tunic", "camisole", "tank top", "polo"] },
    { id: "bottoms", ja: "ボトムス", en: "Bottoms", terms: ["pants", "trousers", "jeans", "shorts", "skirt"] },
    { id: "outer", ja: "アウター", en: "Outerwear", terms: ["jacket", "coat", "parka", "cloak", "cape", "windbreaker", "blazer", "poncho"] },
    { id: "onepiece", ja: "ワンピース・全身", en: "One-piece", terms: ["dress", "gown", "robe", "jumpsuit", "overalls", "bodysuit"] },
    { id: "uniform", ja: "制服・職業服", en: "Uniforms", terms: ["uniform", "school", "military", "maid", "nurse", "labcoat", "apron"] },
    { id: "traditional", ja: "民族・伝統衣装", en: "Traditional", terms: ["kimono", "hanfu", "sari", "traditional", "yukata", "qipao", "cheongsam", "hakama"] },
    { id: "special", ja: "特殊衣装", en: "Special", terms: ["armor", "swimsuit", "leotard", "costume", "fantasy", "bunny"] },
  ],
  "clothing-detail": [
    { id: "tops", ja: "トップス種類", en: "Tops", terms: ["shirt", "blouse", "cardigan", "turtleneck", "vest", "tanktop", "camisole", "crop top", "polo"] },
    { id: "bottoms", ja: "ボトムス種類", en: "Bottoms", terms: ["denim", "shorts", "trousers", "skirt", "overalls"] },
    { id: "neck", ja: "裾・首元", en: "Necklines", terms: ["neck", "collar", "halter", "shoulder", "lapel"] },
    { id: "sleeve", ja: "袖", en: "Sleeves", terms: ["sleeve", "cuff"] },
    { id: "decor", ja: "装飾・柄", en: "Decor", terms: ["frill", "ruffle", "lace", "embroidery", "print", "pattern", "stripe", "check", "plaid", "floral", "polkadot"] },
    { id: "fit", ja: "丈・フィット", en: "Fit & cut", terms: ["tight", "loose", "oversized", "fitted", "cropped", "high waist", "low rise", "open front", "backless", "slit"] },
  ],
  accessory: [
    { id: "head", ja: "頭・顔", en: "Head & face", terms: ["glasses", "hat", "mask", "headphone", "crown", "ribbon", "veil", "flower", "feather"] },
    { id: "jewelry", ja: "ジュエリー", en: "Jewelry", terms: ["earring", "necklace", "bracelet", "ring", "brooch", "choker", "pendant"] },
    { id: "bags", ja: "バッグ・携帯品", en: "Bags", terms: ["bag", "backpack", "purse", "handbag", "tote", "wallet", "keychain", "satchel"] },
    { id: "wear", ja: "身につける物", en: "Wearables", terms: ["scarf", "gloves", "watch", "belt", "badge", "pin"] },
    { id: "props", ja: "持ち物", en: "Props", terms: ["umbrella", "fan", "parasol"] },
  ],
  footwear: [
    { id: "shoes", ja: "靴", en: "Shoes", terms: ["sneaker", "loafer", "heel", "flat", "mary", "oxford", "brogue", "mule", "clog", "espadrille", "slipper"] },
    { id: "boots", ja: "ブーツ", en: "Boots", terms: ["boot"] },
    { id: "sandals", ja: "サンダル・和履物", en: "Sandals", terms: ["sandal", "flipflop", "geta", "zori", "waraji"] },
    { id: "hosiery", ja: "靴下・脚まわり", en: "Hosiery", terms: ["sock", "kneehigh", "thighhigh", "legwarmer", "tabi"] },
    { id: "bare", ja: "裸足", en: "Barefoot", terms: ["barefoot"] },
  ],
  action: [
    { id: "travel", ja: "移動", en: "Movement", terms: ["walking", "running", "flying", "swimming", "jumping", "falling", "climbing", "chasing"] },
    { id: "pose", ja: "姿勢", en: "Posture", terms: ["sitting", "standing", "kneeling", "crouching", "leaning", "stretching", "sleeping"] },
    { id: "hands", ja: "手・物との動作", en: "Hands & objects", terms: ["holding", "reaching", "waving", "pointing", "carrying", "pushing", "pulling", "throwing", "catching"] },
    { id: "daily", ja: "日常動作", en: "Daily", terms: ["reading", "writing", "painting", "drinking", "eating", "singing", "playing", "working"] },
    { id: "emotion", ja: "対人・感情", en: "Interaction", terms: ["kissing", "hugging", "crying", "laughing", "hiding", "looking"] },
    { id: "combat", ja: "戦闘", en: "Combat", terms: ["fighting"] },
  ],
  pose: [
    { id: "stance", ja: "立ち・座り", en: "Stance", terms: ["standing", "sitting", "kneeling", "crouching", "crosslegged", "contrapposto"] },
    { id: "lying", ja: "寝姿勢", en: "Lying", terms: ["lying", "reclining", "fetal", "side lying"] },
    { id: "hands", ja: "腕・手", en: "Arms & hands", terms: ["arms", "hands", "hand", "covering", "salute", "bowing"] },
    { id: "dynamic", ja: "動き・動的", en: "Dynamic", terms: ["jump", "stretch", "lean", "turn", "dynamic", "action", "power", "warrior", "treepose", "yoga"] },
    { id: "presentation", ja: "見せ方", en: "Presentation", terms: ["elegant", "casual", "lookingback", "profile", "front", "back"] },
    { id: "interaction", ja: "対人・組み合わせ", en: "Interaction", terms: ["embracing", "hugging", "couple", "pair", "together"] },
  ],
  interaction: [
    { id: "touch", ja: "接触・抱く", en: "Touch & carry", terms: ["hugging", "handshake", "highfive", "holdinghands", "armaround", "piggyback", "bridal carry"] },
    { id: "affection", ja: "なでる・親しみ", en: "Affection", terms: ["headpat", "patting", "pinkypromise"] },
    { id: "social", ja: "会話・協力", en: "Social", terms: ["conversation", "greeting", "cheering", "helping", "teamwork"] },
  ],
  angle: [
    { id: "front", ja: "正面・目線", en: "Front & eye level", terms: ["eyelevel", "frontal", "front view"] },
    { id: "high", ja: "上から・俯瞰", en: "High & overhead", terms: ["highangle", "overhead", "birdseye", "aerial"] },
    { id: "low", ja: "下から", en: "Low angle", terms: ["lowangle", "wormsview"] },
    { id: "side", ja: "横・後方・斜め", en: "Side, rear & dutch", terms: ["sidetrack", "side view", "rearview", "dutchangle"] },
    { id: "projection", ja: "投影", en: "Projection", terms: ["isometric"] },
  ],
  placement: [
    { id: "depth", ja: "前後・距離", en: "Depth & distance", terms: ["foreground", "background", "distant", "intimate"] },
    { id: "side", ja: "左右", en: "Left & right", terms: ["leftside", "rightside", "offcenter"] },
    { id: "body", ja: "身体の範囲", en: "Body crop", terms: ["upperbody", "lowerbody"] },
    { id: "direction", ja: "見る方向", en: "Viewpoint", terms: ["frombehind", "fromabove", "frombelow"] },
    { id: "frame", ja: "フレーム外・水中", en: "Out of frame & water", terms: ["out of frame", "partially underwater"] },
  ],
  setting: [
    { id: "nature", ja: "自然・屋外", en: "Nature", terms: ["forest", "beach", "garden", "desert", "mountain", "underwater", "cave", "park"] },
    { id: "urban", ja: "街・公共空間", en: "Urban", terms: ["city", "alley", "street", "rooftop", "station", "airport", "market", "bookstore", "museum", "gallery", "theater", "stadium", "gym"] },
    { id: "indoor", ja: "屋内・生活空間", en: "Indoor", terms: ["library", "studio", "cafe", "bedroom", "bathroom", "kitchen", "livingroom", "office", "classroom", "hospital", "apartment", "mansion", "paper background"] },
    { id: "traditional", ja: "伝統・歴史", en: "Traditional", terms: ["temple", "shrine", "castle", "ruins", "ryokan", "onsen"] },
    { id: "travel", ja: "宿泊・移動先", en: "Travel", terms: ["cottage", "cabin", "tent", "pier", "bridge", "courtyard", "balcony"] },
    { id: "fantasy", ja: "SF・特殊空間", en: "Special", terms: ["space", "spaceship"] },
  ],
  nature: [
    { id: "weather", ja: "天候", en: "Weather", terms: ["rain", "snow", "fog", "cloud", "storm", "wind", "lightning", "mist", "hail", "thunder", "rainbow", "aurora"] },
    { id: "plants", ja: "植物", en: "Plants", terms: ["flower", "leaves", "petal", "blossom", "bamboo", "pine", "maple", "lotus", "sunflower", "rose", "lily", "grass", "moss"] },
    { id: "terrain", ja: "地形", en: "Terrain", terms: ["field", "meadow", "hill", "valley", "cliff", "rock", "sand", "dune", "ice", "frost"] },
    { id: "water", ja: "水・水景", en: "Water", terms: ["wave", "waterfall", "dew"] },
    { id: "sky", ja: "空・時間光", en: "Sky & light", terms: ["starry", "moonlight", "sunbeam", "dusk", "dawn"] },
  ],
  water: [
    { id: "inland", ja: "川・湖・池", en: "Inland", terms: ["river", "lake", "pond", "stream"] },
    { id: "sea", ja: "海・海岸", en: "Sea", terms: ["ocean", "harbor", "island", "shore", "beach", "coast", "bay", "cove", "coral"] },
    { id: "structures", ja: "水辺の建造物", en: "Structures", terms: ["lighthouse", "pier", "boat", "fountain", "aquarium", "pool"] },
    { id: "hotwater", ja: "温泉", en: "Hot springs", terms: ["hot spring", "onsen"] },
    { id: "surface", ja: "水面・動き", en: "Surface", terms: ["surface", "reflection", "ripple", "wave", "foam", "splash", "underwater"] },
  ],
  sky: [
    { id: "sunmoon", ja: "太陽・月", en: "Sun & moon", terms: ["sun", "moon", "eclipse"] },
    { id: "stars", ja: "星・宇宙", en: "Stars & space", terms: ["star", "galaxy", "comet", "planet", "constellation", "meteor", "nebula", "milkyway"] },
    { id: "atmosphere", ja: "空模様", en: "Sky conditions", terms: ["cloud", "clear", "overcast", "rainbow", "aurora"] },
    { id: "timeofday", ja: "時間帯", en: "Time of day", terms: ["sunset", "sunrise", "night"] },
  ],
  architecture: [
    { id: "historic", ja: "歴史様式", en: "Historic", terms: ["gothic", "victorian", "artdeco", "baroque", "traditional"] },
    { id: "modern", ja: "近現代", en: "Modern", terms: ["modern", "futuristic", "industrial", "minimalist", "brutalist"] },
    { id: "japan", ja: "和風建築", en: "Japanese", terms: ["japanese", "pagoda", "torii", "shrine", "temple", "engawa", "shoji", "tatami", "fusuma"] },
    { id: "buildings", ja: "建物", en: "Buildings", terms: ["castle", "western-style house", "skyscraper", "tower", "dome", "ruins"] },
    { id: "elements", ja: "建築要素", en: "Elements", terms: ["bridge", "arch", "column", "pillar", "staircase", "balcony", "veranda"] },
  ],
  object: [
    { id: "writing", ja: "文具・創作", en: "Writing & art", terms: ["book", "notebook", "pen", "pencil", "brush", "palette", "easel", "frame", "photo", "letter", "envelope", "map"] },
    { id: "tech", ja: "機器", en: "Tech", terms: ["camera", "phone", "smartphone", "laptop", "tablet", "telescope", "binocular"] },
    { id: "tableware", ja: "食器・容器", en: "Tableware", terms: ["cup", "bottle", "glass", "plate", "bowl", "chopsticks", "fork", "knife", "spoon"] },
    { id: "decor", ja: "家具・装飾", en: "Decor", terms: ["lantern", "mirror", "chair", "clock", "candle", "vase", "lamp"] },
    { id: "travel", ja: "携行・収納", en: "Carry & storage", terms: ["key", "compass", "umbrella", "fan", "parasol", "basket", "box", "chest"] },
    { id: "fantasy", ja: "武器", en: "Weapons", terms: ["sword"] },
  ],
  light: [
    { id: "natural", ja: "自然光", en: "Natural", terms: ["sunlight", "overcastlight", "naturallight", "ambientlight", "moonlight"] },
    { id: "studio", ja: "撮影照明", en: "Studio", terms: ["studiolight", "keylight", "filllight", "rimlight", "backlight", "softlight", "hardlight"] },
    { id: "dramatic", ja: "演出照明", en: "Dramatic", terms: ["cinematiclighting", "dramaticlighting", "chiaroscuro", "rembrandtlighting", "volumetriclight", "godrays", "lightbeams"] },
    { id: "practical", ja: "人工・実用光", en: "Practical", terms: ["neonlight", "candlelight"] },
    { id: "soft", ja: "柔らかい光", en: "Soft", terms: ["diffusedlight", "softlighting"] },
  ],
  style: [
    { id: "anime", ja: "アニメ・漫画", en: "Anime & comics", terms: ["anime", "manga", "manhwa", "webtoon", "cartoon", "comic", "chibi", "superdeformed", "celshaded", "lineart", "gag manga", "ligne claire", "yume kawaii", "fairy kei", "cel anime", "graphic novel", "ben-day"] },
    { id: "painting", ja: "絵画・画材", en: "Painting", terms: ["oilpainting", "watercolor", "gouache", "pastel", "inkwash", "sumie", "chinese painting", "japanese painting", "pencilsketch", "charcoal", "painting", "ukiyo-e woodblock", "sketch style"] },
    { id: "art-history", ja: "美術様式", en: "Art history", terms: ["impressionism", "expressionism", "surrealism", "cubism", "baroque", "rococo", "renaissance", "romanticism", "symbolism", "artnouveau", "artdeco", "dada", "futurism", "dark romanticism"] },
    { id: "digital", ja: "デジタル表現", en: "Digital", terms: ["digitalart", "3d", "lowpoly", "voxel", "pixel", "conceptart", "mattepainting", "stylized", "semi realistic"] },
    { id: "retro", ja: "レトロ・サイバー", en: "Retro & cyber", terms: ["cyber", "steampunk", "dieselpunk", "atompunk", "solarpunk", "vaporwave", "synthwave", "retrowave", "outrun", "cassettefuturism", "glitchart", "clockpunk", "raypunk"] },
    { id: "genre", ja: "ジャンル・世界観", en: "Genre", terms: ["fantasy", "noir", "gothic", "cozy", "cottagecore", "goblincore", "fairycore", "angelcore", "devilcore", "traumacore", "weirdcore", "dreamcore", "liminal", "nostalgic", "vintage", "retro", "modern", "contemporary", "cheerful summer atmosphere"] },
    { id: "render", ja: "描画処理", en: "Rendering", terms: ["flat", "softshading", "hardshading", "photorealistic", "hyperrealism", "realism", "abstract", "geometric", "brutalist", "clean lineart", "bold outlines", "minimal shading", "simple hatching"] },
  ],
  material: [
    { id: "metal", ja: "金属", en: "Metals", terms: ["metal", "gold", "silver", "bronze", "copper", "iron", "steel", "aluminum", "chrome", "brass"] },
    { id: "textile", ja: "布・繊維", en: "Textiles", terms: ["fabric", "velvet", "silk", "leather", "cotton", "linen", "wool", "cashmere", "fur", "feather", "nylon", "polyester"] },
    { id: "stone", ja: "石・鉱物", en: "Stone & gems", terms: ["stone", "marble", "granite", "crystal", "diamond", "ruby", "sapphire", "emerald", "amber", "jade", "obsidian", "quartz", "pearl"] },
    { id: "natural", ja: "木・天然素材", en: "Natural", terms: ["paper", "wood", "bone", "ivory"] },
    { id: "ceramic", ja: "陶磁・建材", en: "Ceramic & masonry", terms: ["ceramic", "porcelain", "concrete", "brick", "clay", "glass"] },
    { id: "synthetic", ja: "合成素材", en: "Synthetic", terms: ["plastic", "rubber", "latex", "vinyl"] },
  ],
  patterns: [
    { id: "classic", ja: "定番柄", en: "Classic", terms: ["stripes", "polkadots", "checkerboard", "plaid", "gingham", "houndstooth", "argyle", "tartan", "herringbone"] },
    { id: "ornament", ja: "装飾・民族柄", en: "Ornamental", terms: ["floral", "paisley", "ornamental", "damask", "brocade", "jacquard", "ikat", "batik", "mandala"] },
    { id: "natural", ja: "自然素材柄", en: "Natural", terms: ["marble", "woodgrain", "stone", "leather texture", "snake", "leopard", "zebra", "tiger", "giraffe", "scale", "feather", "wave", "cloud"] },
    { id: "geometry", ja: "幾何・図形", en: "Geometric", terms: ["geometric", "zigzag", "star", "moon", "sun", "heart", "diamond", "circle", "square", "triangle", "hexagon", "mosaic", "fractal"] },
    { id: "gradient", ja: "グラデーション・特殊", en: "Gradient & special", terms: ["tie dye", "ombre", "gradient", "noise", "glitch"] },
  ],
  surface: [
    { id: "finish", ja: "表面仕上げ", en: "Finish", terms: ["smooth", "rough", "glossy", "matte", "polished", "brushed", "satin", "velvet", "textured", "fuzzy", "soft", "hard", "sticky", "slippery", "porous", "dense", "absorptive", "paper texture"] },
    { id: "transparency", ja: "透明・反射", en: "Transparency", terms: ["transparent", "translucent", "opaque", "reflective", "iridescent", "frosted", "metallic"] },
    { id: "damage", ja: "経年・ダメージ", en: "Wear & damage", terms: ["weathered", "worn", "cracked", "rust", "corrosion", "oxidation", "tarnish", "scratched", "dented", "torn", "ripped", "frayed"] },
    { id: "craft", ja: "加工・工芸", en: "Craft", terms: ["embossed", "etched", "engraved", "carved", "molded", "cast", "forged", "welded", "riveted", "screwed", "nailed", "glued", "stitched", "woven", "knitted", "crocheted", "embroidered", "printed", "painted", "lacquered", "varnished", "oiled", "waxed", "patina"] },
    { id: "shape", ja: "変形・状態", en: "Shape & state", terms: ["bent", "warped", "twisted", "folded", "crumpled", "wrinkled", "pleated", "gathered", "ruffled", "cut", "sliced", "chopped", "shattered", "fragmented", "powdered", "granular", "crystalline", "amorphous", "fibrous", "cellular", "spongy"] },
    { id: "physical", ja: "物性", en: "Physical", terms: ["elastic", "brittle", "ductile", "malleable", "resilient", "flexible", "rigid", "stiff", "limp", "flimsy", "sturdy", "delicate", "fragile", "durable", "ephemeral", "permanent", "temporary", "eternal"] },
  ],
  effect: [
    { id: "film", ja: "フィルム・粒子", en: "Film", terms: ["filmgrain", "halftone", "grain", "noise", "scanlines", "vignette"] },
    { id: "light", ja: "光・レンズ", en: "Light & lens", terms: ["glow", "bloom", "lensflare", "lightleak", "reflections", "refractions", "bokeh"] },
    { id: "blur", ja: "ぼかし・焦点", en: "Blur & focus", terms: ["blur", "focus", "depthoffield", "tiltshift", "anamorphic", "fisheye", "exposure"] },
    { id: "color", ja: "色調補正", en: "Color", terms: ["chromatic", "duotone", "tritone", "toning", "colorgrading", "lut", "contrast", "desaturated", "oversaturated", "warmtones", "cooltones", "sepia", "monochrome", "blackandwhite"] },
    { id: "distort", ja: "変形・デジタル", en: "Distortion", terms: ["glitch", "distortion", "warping", "pixelation", "posterization", "solarization", "crossprocess", "hdr"] },
    { id: "particles", ja: "煙・粒子", en: "Particles", terms: ["smoke", "sparks", "dust", "particles"] },
  ],
  "adult-wardrobe": [
    { id: "underwear", ja: "下着", en: "Underwear", terms: ["bra", "panties", "briefs", "boxers", "underwear", "lingerie", "thong", "gstring"] },
    { id: "hosiery", ja: "ストッキング・タイツ", en: "Hosiery", terms: ["stocking", "tights", "pantyhose", "fishnet", "kneehigh", "thighhigh", "socks", "garter"] },
    { id: "bodywear", ja: "ボディウェア", en: "Bodywear", terms: ["bodysuit", "bodystocking", "leotard", "bustier", "corset", "chemise", "babydoll", "camisole"] },
    { id: "swim", ja: "水着", en: "Swimwear", terms: ["bikini", "microbikini", "highleg"] },
    { id: "material", ja: "素材・透け", en: "Materials", terms: ["latex", "leather", "lace", "satin", "silk", "mesh", "sheer", "transparent", "translucent", "opaque", "wetlook", "velvet", "net"] },
    { id: "fit", ja: "フィット・形", en: "Fit", terms: ["tight", "loose", "fitted", "oversized", "strapless", "halter", "racerback", "toeless", "crotchless", "open crotch", "see through", "stretch"] },
    { id: "special", ja: "特殊衣装・小物", en: "Special wardrobe", terms: ["bunny", "collar", "harness", "gloves", "heels", "ribbon", "choker"] },
  ],
  "adult-pose": [
    { id: "stance", ja: "基本姿勢", en: "Stance", terms: ["standing", "sitting", "kneeling", "lying", "reclining", "prone", "allfours", "sidepose", "onback", "sprawled", "lounging"] },
    { id: "legs", ja: "脚", en: "Legs", terms: ["leg", "knee", "straddling", "tiptoe", "bridge"] },
    { id: "arms", ja: "腕・手", en: "Arms & hands", terms: ["arm", "hand", "covering", "revealing", "presenting", "displaying", "offering"] },
    { id: "face", ja: "顔・視線", en: "Face", terms: ["looking", "eyes", "mouth", "tongue", "lip", "peeking"] },
    { id: "interaction", ja: "接触・交流", en: "Interaction", terms: ["touching", "caressing", "kissing", "nuzzling", "cuddling", "spooning", "embracing", "teasing", "inviting", "licking"] },
    { id: "sexual", ja: "成人向け体位", en: "Adult positions", terms: ["missionary", "doggy", "cowgirl", "lotus", "sex", "vaginal", "anal", "oral", "fellatio", "paizuri", "penetration", "pantyshot", "upskirt"] },
    { id: "location", ja: "場所", en: "Location", terms: ["wall", "table", "floor", "bed", "shower", "bath", "outdoors", "indoors"] },
    { id: "motion", ja: "動き・身体表現", en: "Motion", terms: ["arching", "undressing", "posing", "dancing", "leaning", "stretching", "hiding"] },
    { id: "restraint", ja: "拘束", en: "Restraint", terms: ["bondage", "restrained", "gagged"] },
  ],
  "adult-scene": [
    { id: "place", ja: "場所・背景", en: "Setting", terms: ["boudoir", "bedroom", "mirror", "curtain", "sheet", "pillow", "bathtub", "dressingroom", "private room", "night", "underwater"] },
    { id: "framing", ja: "構図・距離", en: "Framing", terms: ["closeup", "rearview", "lowangle", "cropped", "silhouette", "backview", "profile", "wide", "narrow", "distant", "close", "far"] },
    { id: "light", ja: "照明・空気", en: "Lighting", terms: ["light", "volumetric", "godrays", "haze", "smoke", "steam", "fog", "dust", "particles", "bokeh"] },
    { id: "focus", ja: "焦点・質感", en: "Focus & texture", terms: ["focus", "blur", "sharp", "grain", "noise", "film", "analog", "digital"] },
    { id: "style", ja: "画風・表現", en: "Style", terms: ["cinematic", "photographic", "painterly", "illustration", "realistic", "stylized", "abstract", "minimal", "maximal", "detailed", "simple", "complex"] },
    { id: "density", ja: "画面密度", en: "Density", terms: ["busy", "empty", "full", "crowded", "sparse", "intimate"] },
    { id: "scale", ja: "大きさ・縦横", en: "Scale", terms: ["tall", "short", "large", "small", "huge", "tiny"] },
  ],
  avoid: [
    { id: "quality", ja: "低品質", en: "Low quality", terms: ["worst quality", "low quality", "bad quality", "normal quality", "poorly drawn", "amateur", "beginner", "unfinished", "incomplete"] },
    { id: "displeasing", ja: "不快・損傷", en: "Displeasing", terms: ["ugly", "morbid", "mutilated", "displeasing"] },
    { id: "anatomy", ja: "人体の崩れ", en: "Anatomy", terms: ["bad anatomy", "bad hands", "bad proportions", "bad feet", "bad legs", "extra limbs", "extra legs", "extra fingers", "extra digit", "missing fingers", "missing arms", "missing legs", "fewer digits", "fused fingers", "fused limbs", "too many fingers", "mutated", "mutation", "disfigured", "long neck", "malformed", "gross proportions"] },
    { id: "artifacts", ja: "ノイズ・署名", en: "Artifacts", terms: ["blurry", "jpeg artifacts", "signature", "username", "artist name", "cut off", "error", "text", "logo", "watermark", "blur", "deformed", "duplicate", "cropped", "lowres", "artifact", "noise", "frame", "clutter"] },
  ],
};

function normalize(value: string): string {
  return value.toLowerCase().replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim();
}

function matches(option: PromptOption, term: string): boolean {
  const value = normalize(option.en);
  const target = normalize(term);
  if (!target) return false;
  if (target.includes(" ")) return value.includes(target);

  const tokens = value.split(" ");
  return tokens.some((token) => token === target || token.startsWith(target));
}

export function buildSafeDictionarySections(category?: PromptCategory): DictionarySection[] | undefined {
  if (!category) return undefined;
  const rules = categoryRules[category.id];
  if (!rules) return undefined;

  const used = new Set<string>();
  const sections = rules
    .map((rule) => {
      const optionIds = category.options
        .filter((option) => {
          if (used.has(option.id)) return false;
          const matched = rule.terms.some((term) => matches(option, term));
          if (matched) used.add(option.id);
          return matched;
        })
        .map((option) => option.id);
      return { id: rule.id, ja: rule.ja, en: rule.en, optionIds };
    })
    .filter((section) => section.optionIds.length > 0);

  const other = category.options.filter((option) => !used.has(option.id)).map((option) => option.id);
  if (other.length) sections.push({ id: "other", ja: "その他", en: "Other", optionIds: other });
  return sections;
}

export function hasSafeDictionaryTaxonomy(categoryId: string): boolean {
  return Boolean(categoryRules[categoryId]);
}
