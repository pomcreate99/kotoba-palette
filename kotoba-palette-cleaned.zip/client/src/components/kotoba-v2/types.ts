export type KotobaTab = "recipes" | "home" | "dictionary" | "library";

export type UiLanguage = "ja" | "en";

export const kotobaTabs: Array<{ id: KotobaTab; labelJa: string; labelEn: string }> = [
  { id: "recipes", labelJa: "レシピ", labelEn: "Recipes" },
  { id: "home", labelJa: "ホーム", labelEn: "Home" },
  { id: "dictionary", labelJa: "単語帳", labelEn: "Dictionary" },
  { id: "library", labelJa: "ライブラリ", labelEn: "Library" },
];
