import { describe, expect, it } from "vitest";
import { categories, type PromptCategory, type PromptOption } from "@/lib/prompt-data";
import { extraEyeColorCategory } from "@/lib/prompt-data-extra-hair-eyes";
import { mergeExtraCategories } from "@/lib/prompt-data-merge";
import { dictionaryGroups } from "./KotobaV2Workspace";
import { buildAccessibleDictionarySections, getUsefulGenderTargets, hasUsefulGenderFilter } from "./dictionaryUx";
import { hasSemanticTaxonomy } from "./dictionarySemanticTaxonomy";
import { hasSafeDictionaryTaxonomy } from "./dictionarySafeTaxonomy";
import { hasDictionaryOverrideTaxonomy } from "./dictionarySafeTaxonomyOverrides";
import { deriveGenderTarget } from "./genderTarget";

const category: PromptCategory = {
  id: "demographics",
  label: "性別・年齢",
  labelEn: "Gender & age",
  hint: "test",
  options: [],
};

const option = (id: string, en: string, ja = en): PromptOption => ({ id, en, ja });

function sectionFor(category: PromptCategory, en: string) {
  const target = category.options.find((item) => item.en === en);
  if (!target) return undefined;
  return buildAccessibleDictionarySections(category).find((section) => section.optionIds.includes(target.id));
}

describe("deriveGenderTarget", () => {
  it("does not classify female as male", () => {
    expect(deriveGenderTarget(option("demographics-female", "female", "女性"), category)).toBe("female");
  });

  it("does not classify woman as man", () => {
    expect(deriveGenderTarget(option("demographics-woman", "woman", "女性"), category)).toBe("female");
  });

  it("classifies explicit male tokens", () => {
    expect(deriveGenderTarget(option("demographics-male", "male", "男性"), category)).toBe("male");
  });

  it("classifies nonbinary separately", () => {
    expect(deriveGenderTarget(option("demographics-nonbinary", "nonbinary", "ノンバイナリー"), category)).toBe("other");
  });

  it("keeps neutral tags unisex in a relevant category", () => {
    expect(deriveGenderTarget(option("demographics-adult", "adult", "成人"), category)).toBe("unisex");
  });
});

describe("dictionary usability helpers", () => {
  it("keeps every real eye-color tag in a clear color subgroup", () => {
    const sections = buildAccessibleDictionarySections(extraEyeColorCategory);
    const warm = sections.find((section) => section.id === "warm");

    expect(warm?.optionIds).toEqual([
      "eye-color-ambereyes",
      "eye-color-goldeyes",
      "eye-color-yelloweyes",
    ]);
    expect(sections.some((section) => section.id === "identity" || section.id === "age")).toBe(false);

    const groupedIds = sections.flatMap((section) => section.optionIds);
    expect(groupedIds).toHaveLength(extraEyeColorCategory.options.length);
    expect(new Set(groupedIds).size).toBe(extraEyeColorCategory.options.length);
    expect(new Set(groupedIds)).toEqual(new Set(extraEyeColorCategory.options.map((item) => item.id)));
  });

  it("hides the secondary gender filter for eye colors because it cannot narrow the list", () => {
    expect(getUsefulGenderTargets(extraEyeColorCategory)).toEqual(["unisex"]);
    expect(hasUsefulGenderFilter(extraEyeColorCategory)).toBe(false);
  });

  it("keeps the secondary gender filter only when it can actually narrow choices", () => {
    const demographics: PromptCategory = {
      id: "demographics",
      label: "性別・年齢",
      labelEn: "Gender & age",
      hint: "性別表記と年齢層をまとめて選ぶ",
      options: [
        option("demographics-man", "man", "男性"),
        option("demographics-woman", "woman", "女性"),
        option("demographics-adult", "adult", "成人"),
      ],
    };

    expect(getUsefulGenderTargets(demographics)).toEqual(["male", "female", "unisex"]);
    expect(hasUsefulGenderFilter(demographics)).toBe(true);
  });

  it("keeps short categories flat instead of adding unnecessary subgroup tabs", () => {
    const shortCategory: PromptCategory = {
      id: "test-short",
      label: "短いカテゴリ",
      labelEn: "Short",
      hint: "test",
      options: Array.from({ length: 12 }, (_, index) => option(`short-${index}`, `tag ${index}`)),
    };
    expect(buildAccessibleDictionarySections(shortCategory)).toEqual([
      { id: "all", ja: "すべて", en: "All", optionIds: shortCategory.options.map((item) => item.id) },
    ]);
  });

  it("makes every runtime category reachable from the dictionary except recipe-only data", () => {
    const groupedCategoryIds = new Set<string>(dictionaryGroups.flatMap((group) => [...group.ids]));
    const runtime = mergeExtraCategories(categories).filter((item) => item.id !== "recipe-style" && item.options.length > 0);

    for (const item of runtime) {
      expect(groupedCategoryIds.has(item.id), item.id).toBe(true);
    }
  });

  it("covers every runtime option exactly once in its small-classification sections", () => {
    const runtime = mergeExtraCategories(categories).filter((item) => item.id !== "recipe-style");

    for (const item of runtime) {
      const sections = buildAccessibleDictionarySections(item);
      const groupedIds = sections.flatMap((section) => section.optionIds);
      expect(groupedIds.length, item.id).toBe(item.options.length);
      expect(new Set(groupedIds).size, item.id).toBe(item.options.length);
      expect(new Set(groupedIds), item.id).toEqual(new Set(item.options.map((entry) => entry.id)));
    }
  });

  it("requires every large runtime category to bypass the legacy id-substring taxonomy", () => {
    const runtime = mergeExtraCategories(categories).filter((item) => item.id !== "recipe-style" && item.options.length > 12);
    const uncovered = runtime
      .filter((item) => item.id !== "eye-color")
      .filter((item) => !hasDictionaryOverrideTaxonomy(item.id) && !hasSemanticTaxonomy(item.id) && !hasSafeDictionaryTaxonomy(item.id))
      .map((item) => item.id);

    expect(uncovered).toEqual([]);
  });

  it("does not fall back to arbitrary order chunks for large runtime categories", () => {
    const runtime = mergeExtraCategories(categories).filter((item) => item.id !== "recipe-style" && item.options.length > 12);
    const mechanicalFallbacks = runtime
      .filter((item) => buildAccessibleDictionarySections(item)[0]?.id === "basic")
      .map((item) => item.id);

    expect(mechanicalFallbacks).toEqual([]);
  });

  it("keeps male and female demographic terms separated by tokens", () => {
    const demographics = mergeExtraCategories(categories).find((item) => item.id === "demographics");
    expect(demographics).toBeDefined();
    if (!demographics) return;

    expect(sectionFor(demographics, "man")?.id).toBe("male");
    expect(sectionFor(demographics, "youngman")?.id).toBe("male");
    expect(sectionFor(demographics, "woman")?.id).toBe("female");
    expect(sectionFor(demographics, "youngwoman")?.id).toBe("female");
  });

  it("keeps shadow and line-art concepts separate in coloring", () => {
    const coloring = mergeExtraCategories(categories).find((item) => item.id === "coloring");
    expect(coloring).toBeDefined();
    if (!coloring) return;

    expect(sectionFor(coloring, "cast shadows")?.id).toBe("shadow");
    expect(sectionFor(coloring, "soft facial shadows")?.id).toBe("shadow");
    expect(sectionFor(coloring, "reflected light")?.id).toBe("shadow");

    expect(sectionFor(coloring, "clean lineart")?.id).toBe("line");
    expect(sectionFor(coloring, "crisp linework")?.id).toBe("line");
    expect(sectionFor(coloring, "thick outlines")?.id).toBe("line");
  });

  it("separates eye shape, lids, gaze and effects by meaning", () => {
    const eyes = mergeExtraCategories(categories).find((item) => item.id === "eye-shape");
    expect(eyes).toBeDefined();
    if (!eyes) return;

    expect(sectionFor(eyes, "almond eyes")?.id).toBe("shape");
    expect(sectionFor(eyes, "heavy lower eyelids")?.id).toBe("lid-lash");
    expect(sectionFor(eyes, "looking at viewer")?.id).toBe("gaze");
    expect(sectionFor(eyes, "vertically slit pupils")?.id).toBe("effect");
  });

  it("separates headwear by actual use instead of the category-id prefix", () => {
    const headwear = mergeExtraCategories(categories).find((item) => item.id === "headwear");
    expect(headwear).toBeDefined();
    if (!headwear) return;

    expect(sectionFor(headwear, "beanie")?.id).toBe("hats");
    expect(sectionFor(headwear, "hairclip")?.id).toBe("hair-accessory");
    expect(sectionFor(headwear, "helmet")?.id).toBe("covering");
  });

  it("keeps audited renamed tags in meaningful dictionary sections", () => {
    const architecture = mergeExtraCategories(categories).find((item) => item.id === "architecture");
    const patterns = mergeExtraCategories(categories).find((item) => item.id === "patterns");
    expect(architecture).toBeDefined();
    expect(patterns).toBeDefined();
    if (!architecture || !patterns) return;

    expect(sectionFor(architecture, "western-style house")?.id).toBe("buildings");
    expect(sectionFor(patterns, "leather texture")?.id).toBe("natural");
  });

  it("separates mixed composition data and adult goods explicitly", () => {
    const composition = mergeExtraCategories(categories).find((item) => item.id === "composition");
    const wardrobe = mergeExtraCategories(categories).find((item) => item.id === "adult-wardrobe");
    expect(composition).toBeDefined();
    expect(wardrobe).toBeDefined();
    if (!composition || !wardrobe) return;

    expect(sectionFor(composition, "mansion interior")?.id).toBe("background");
    expect(sectionFor(composition, "extreme low angle")?.id).toBe("perspective");
    expect(sectionFor(wardrobe, "nipple clamps")?.id).toBe("restraints");
    expect(sectionFor(wardrobe, "dildo")?.id).toBe("goods");
  });

  it("separates mixed SFW clothing chunks by actual item type", () => {
    const clothing = mergeExtraCategories(categories).find((item) => item.id === "clothing");
    expect(clothing).toBeDefined();
    if (!clothing) return;

    expect(sectionFor(clothing, "chinstrap hat")?.id).toBe("headwear");
    expect(sectionFor(clothing, "hiking sneakers")?.id).toBe("footwear");
    expect(sectionFor(clothing, "crossbody bag")?.id).toBe("bags");
    expect(sectionFor(clothing, "yukata casual")?.id).toBe("traditional");
    expect(sectionFor(clothing, "butler suit")?.id).toBe("uniform");
    expect(sectionFor(clothing, "cardigan long")?.id).toBe("outer");
    expect(sectionFor(clothing, "tulle lolita dress")?.id).toBe("onepiece");
    expect(sectionFor(clothing, "oversized t-shirt")?.id).toBe("tops");
    expect(sectionFor(clothing, "track pants")?.id).toBe("bottoms");
    expect(sectionFor(clothing, "square neckline")?.id).toBe("detail");
  });

  it("separates mixed SFW pose chunks by action meaning", () => {
    const pose = mergeExtraCategories(categories).find((item) => item.id === "pose");
    expect(pose).toBeDefined();
    if (!pose) return;

    expect(sectionFor(pose, "claw pose")?.id).toBe("hands");
    expect(sectionFor(pose, "holding flower")?.id).toBe("object");
    expect(sectionFor(pose, "putting on lipstick")?.id).toBe("grooming");
    expect(sectionFor(pose, "typing pose")?.id).toBe("activity");
    expect(sectionFor(pose, "acrobatic pose")?.id).toBe("sport");
    expect(sectionFor(pose, "selfie")?.id).toBe("performance");
    expect(sectionFor(pose, "drawing sword")?.id).toBe("combat");
    expect(sectionFor(pose, "stargazing")?.id).toBe("rest");
  });

  it("separates mixed adult wardrobe chunks by garments, gear and state", () => {
    const wardrobe = mergeExtraCategories(categories).find((item) => item.id === "adult-wardrobe");
    expect(wardrobe).toBeDefined();
    if (!wardrobe) return;

    expect(sectionFor(wardrobe, "remote panty vibe")?.id).toBe("goods");
    expect(sectionFor(wardrobe, "hogtie rope")?.id).toBe("restraints");
    expect(sectionFor(wardrobe, "clit piercing visible")?.id).toBe("piercing");
    expect(sectionFor(wardrobe, "neon lingerie")?.id).toBe("underwear");
    expect(sectionFor(wardrobe, "shiny pantyhose")?.id).toBe("hosiery");
    expect(sectionFor(wardrobe, "crotchless bodysuit")?.id).toBe("bodywear");
    expect(sectionFor(wardrobe, "wet micro bikini")?.id).toBe("swim");
    expect(sectionFor(wardrobe, "patent leather outfit")?.id).toBe("material");
    expect(sectionFor(wardrobe, "shirt unbuttoned fully")?.id).toBe("bodywear");
  });

  it("separates mixed adult pose chunks by restraints, acts and situation", () => {
    const adultPose = mergeExtraCategories(categories).find((item) => item.id === "adult-pose");
    expect(adultPose).toBeDefined();
    if (!adultPose) return;

    expect(sectionFor(adultPose, "ankle cuffs spread")?.id).toBe("restraints");
    expect(sectionFor(adultPose, "vibrator hold")?.id).toBe("toys");
    expect(sectionFor(adultPose, "missionary deep")?.id).toBe("positions");
    expect(sectionFor(adultPose, "neck kiss pose")?.id).toBe("contact");
    expect(sectionFor(adultPose, "striptease pose")?.id).toBe("tease");
    expect(sectionFor(adultPose, "aftercare towel")?.id).toBe("reaction");
    expect(sectionFor(adultPose, "hotel room sex")?.id).toBe("location");
    expect(sectionFor(adultPose, "crawl toward viewer")?.id).toBe("posture");
  });
});
