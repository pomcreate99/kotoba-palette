import type { PromptCategory } from "@/lib/prompt-data";
import { buildDictionarySections, type DictionarySection } from "./dictionaryTaxonomy";
import { buildSemanticDictionarySections } from "./dictionarySemanticTaxonomy";
import { buildSafeDictionarySections } from "./dictionarySafeTaxonomy";
import { buildDictionaryOverrideSections } from "./dictionarySafeTaxonomyOverrides";
import { getGenderTarget, isGenderFilterRelevant, type GenderTarget } from "./genderTarget";

const eyeColorGroups = [
  { id: "natural-dark", ja: "黒・茶・灰", en: "Black, brown & gray", values: ["black eyes", "dark brown eyes", "brown eyes", "light brown eyes", "hazel eyes", "gray eyes", "charcoal gray eyes"] },
  { id: "blue", ja: "青系", en: "Blue", values: ["dark blue eyes", "blue eyes", "light blue eyes", "pale blue eyes", "deep sea-blue eyes"] },
  { id: "green", ja: "緑系", en: "Green", values: ["green eyes", "emerald eyes"] },
  { id: "warm", ja: "金・黄・琥珀", en: "Gold, yellow & amber", values: ["amber eyes", "gold eyes", "yellow eyes"] },
  { id: "red-purple", ja: "赤・紫・ピンク", en: "Red, purple & pink", values: ["red eyes", "pink eyes", "purple eyes", "violet eyes"] },
  { id: "special", ja: "特殊", en: "Special", values: ["silver eyes", "heterochromia", "glowing eyes", "dull eyes"] },
] as const;

export function buildAccessibleDictionarySections(category?: PromptCategory): DictionarySection[] {
  if (!category || !category.options.length) return [];

  // A short list is faster to scan directly than through extra classification tabs.
  if (category.options.length <= 12) {
    return [{ id: "all", ja: "すべて", en: "All", optionIds: category.options.map((option) => option.id) }];
  }

  if (category.id === "eye-color") {
    const byEnglish = new Map(category.options.map((option) => [option.en.toLowerCase(), option.id]));
    const sections: DictionarySection[] = eyeColorGroups
      .map((group) => ({
        id: group.id,
        ja: group.ja,
        en: group.en,
        optionIds: group.values.map((value) => byEnglish.get(value)).filter((id): id is string => Boolean(id)),
      }))
      .filter((section) => section.optionIds.length > 0);

    const used = new Set(sections.flatMap((section) => section.optionIds));
    const other = category.options.filter((option) => !used.has(option.id)).map((option) => option.id);
    if (other.length) sections.push({ id: "other", ja: "その他", en: "Other", optionIds: other });
    return sections;
  }

  return buildDictionaryOverrideSections(category)
    ?? buildSemanticDictionarySections(category)
    ?? buildSafeDictionarySections(category)
    ?? buildDictionarySections(category);
}

export function getUsefulGenderTargets(category?: PromptCategory): GenderTarget[] {
  if (!category || !isGenderFilterRelevant(category)) return [];
  const targets = new Set(category.options.map((option) => getGenderTarget(option, category)));
  return (["male", "female", "unisex", "other"] as const).filter((target) => targets.has(target));
}

export function hasUsefulGenderFilter(category?: PromptCategory): boolean {
  return getUsefulGenderTargets(category).length > 1;
}
