import { useEffect, useMemo, useState } from "react";
import { Check, Copy, Dices, PlusCircle, RotateCcw, Save, Search, ShieldCheck, Sparkles, Star, Trash2, X } from "lucide-react";
import { categories as baseCategories, nsfwOptionIds, youthOptionIds, type ContentMode, type PromptCategory, type PromptOption } from "@/lib/prompt-data";
import { mergeExtraCategoriesWithAliases } from "@/lib/prompt-data-merge";
import { applyPromptCategoryAliases } from "@/lib/prompt-category-aliases";
import { generateCuratedRandom } from "@/lib/prompt-random-recipes";
import { findPromptMatches } from "@/lib/prompt-search";
import { useTheme } from "@/contexts/ThemeContext";
import { AppNavigation } from "./AppNavigation";
import { AppSettings } from "./AppSettings";
import { DictionaryAttributeFilter } from "./DictionaryAttributeFilter";
import { PaletteMark } from "./PaletteMark";
import { SelectedTagsDock } from "./SelectedTagsDock";
import { TagCard } from "./TagCard";
import { buildAccessibleDictionarySections } from "./dictionaryUx";
import { getGenderTarget, isGenderFilterRelevant, withGenderTarget, type GenderTarget } from "./genderTarget";
import type { KotobaTab, UiLanguage } from "./types";

const mergedPromptData = mergeExtraCategoriesWithAliases(baseCategories);
const baseMergedCategories = mergedPromptData.categories.map(withGenderTarget);
const baseCategoryAliasOptionIds = mergedPromptData.categoryAliasOptionIds;
const recipeOptions = baseMergedCategories.find((category) => category.id === "recipe-style")?.options ?? [];

const storageKeys = {
  favorites: "prompt-atlas:favorites",
  customTags: "prompt-atlas:custom-tags",
  history: "prompt-atlas:history",
  presets: "prompt-atlas:custom-presets",
};

type HistoryItem = { id: string; prompt: string; negativePrompt?: string; options: PromptOption[]; createdAt: string; favorite?: boolean; };
type CustomPreset = { id: string; name: string; options: PromptOption[]; };
type LibraryTab = "favorites" | "history" | "history-favorites" | "custom";

function loadStored<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try { const raw = window.localStorage.getItem(key); return raw ? (JSON.parse(raw) as T) : fallback; } catch { return fallback; }
}

export const dictionaryGroups = [
  { id: "person", ja: "人物", en: "People", ids: ["subject", "demographics", "count", "relationships", "physique", "skin", "face-detail", "brows", "eye-color", "eye-shape", "eyes", "pupils", "hair-color", "hair-style", "hair", "hair-detail", "expression", "role"] },
  { id: "creatures", ja: "動物・幻獣", en: "Creatures", ids: ["animals", "species", "creature-features", "mascot"] },
  { id: "objects", ja: "機械・物", en: "Machines & things", ids: ["machines", "transport", "object", "school-hobby-props", "food", "dessert", "drinks"] },
  { id: "wardrobe", ja: "衣装", en: "Wardrobe", ids: ["clothing", "clothing-detail", "headwear", "accessory", "accessory-detail", "footwear"] },
  { id: "motion", ja: "ポーズ・動き", en: "Motion", ids: ["action", "pose", "gesture", "interaction", "hobby-sport"] },
  { id: "scene", ja: "背景・場所", en: "Backgrounds", ids: ["setting", "school-background", "interior", "architecture", "nature", "water", "sky", "time", "scenery", "places"] },
  { id: "frame", ja: "画面・撮影", en: "Framing", ids: ["camera", "shot-distance", "camera-tech", "angle", "placement", "composition", "comic-meta"] },
  { id: "finish", ja: "光・画風・仕上げ", en: "Finish", ids: ["quality", "design", "coloring", "light", "lighting-detail", "color", "tone", "medium", "style", "world", "material", "patterns", "surface", "art-materials", "mood", "effect", "optics", "anime-detail"] },
  { id: "exclude", ja: "除外候補", en: "Negative", ids: ["avoid"] },
  { id: "adult", ja: "NSFW", en: "Adult", ids: ["adult-body", "adult-chest", "adult-genitals", "adult-skin", "adult-reaction", "adult-anatomy", "adult-wardrobe", "adult-mood", "adult-pose", "adult-scene"] },
] as const;

type DictionaryGroupId = (typeof dictionaryGroups)[number]["id"];

export function KotobaV2Workspace() {
  const [activeTab, setActiveTab] = useState<KotobaTab>("home");
  const [language, setLanguage] = useState<UiLanguage>("ja");
  const [contentMode, setContentMode] = useState<ContentMode>("sfw");
  const [nsfwConfirmed, setNsfwConfirmed] = useState(false);
  const [showNsfwDialog, setShowNsfwDialog] = useState(false);
  const [selected, setSelected] = useState<PromptOption[]>([]);
  const [query, setQuery] = useState("");
  const [dictionaryGroup, setDictionaryGroup] = useState<DictionaryGroupId>(dictionaryGroups[0].id);
  const [dictionaryCategory, setDictionaryCategory] = useState<string>(dictionaryGroups[0].ids[0]);
  const [dictionarySection, setDictionarySection] = useState("");
  const [genderFilter, setGenderFilter] = useState<"all" | GenderTarget>("all");
  const [selectionTarget, setSelectionTarget] = useState<"positive" | "negative">("positive");
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => loadStored<string[]>(storageKeys.favorites, []));
  const [customTags, setCustomTags] = useState<PromptOption[]>(() => loadStored<PromptOption[]>(storageKeys.customTags, []));
  const [history, setHistory] = useState<HistoryItem[]>(() => loadStored<HistoryItem[]>(storageKeys.history, []));
  const [customPresets, setCustomPresets] = useState<CustomPreset[]>(() => loadStored<CustomPreset[]>(storageKeys.presets, []));
  const [libraryTab, setLibraryTab] = useState<LibraryTab>("favorites");
  const [customTagEn, setCustomTagEn] = useState("");
  const [customTagJa, setCustomTagJa] = useState("");
  const [presetName, setPresetName] = useState("");
  const [copied, setCopied] = useState<"positive" | "negative" | "both" | null>(null);
  const [lastRandomRecipe, setLastRandomRecipe] = useState<string | null>(null);
  const { theme, toggleTheme } = useTheme();

  const categories = useMemo<PromptCategory[]>(() => customTags.length ? [...baseMergedCategories, { id: "custom", label: "自作タグ", labelEn: "Custom tags", hint: "端末に保存した自分だけのタグ", options: customTags }] : baseMergedCategories, [customTags]);
  const visibleCategories = useMemo(() => categories.filter((category) => (category.mode !== "nsfw" || contentMode === "nsfw") && (contentMode !== "nsfw" || category.audience !== "youth")), [categories, contentMode]);
  const selectableCategories = useMemo(() => visibleCategories.filter((category) => selectionTarget === "negative" ? category.id !== "recipe-style" : category.id !== "avoid"), [selectionTarget, visibleCategories]);
  const visibleDictionaryGroups = useMemo(() => dictionaryGroups.filter((group) => selectableCategories.some((category) => group.ids.includes(category.id as never))), [selectableCategories]);
  const dictionaryCategories = useMemo(() => {
    const group = dictionaryGroups.find((item) => item.id === dictionaryGroup) ?? dictionaryGroups[0];
    const canonicalCategories = group.ids.map((id) => selectableCategories.find((category) => category.id === id)).filter((category): category is PromptCategory => Boolean(category));
    return applyPromptCategoryAliases(canonicalCategories, selectableCategories, baseCategoryAliasOptionIds);
  }, [dictionaryGroup, selectableCategories]);
  const searchable = useMemo(() => selectableCategories.flatMap((category) => category.options).filter((option) => contentMode !== "nsfw" || option.audience !== "youth"), [selectableCategories, contentMode]);
  const searchMatches = useMemo(() => query.trim() ? findPromptMatches(query, searchable).matches.slice(0, 12) : [], [query, searchable]);
  const activeDictionaryCategory = useMemo(() => dictionaryCategories.find((category) => category.id === dictionaryCategory) ?? dictionaryCategories[0], [dictionaryCategories, dictionaryCategory]);
  const dictionarySections = useMemo(() => buildAccessibleDictionarySections(activeDictionaryCategory), [activeDictionaryCategory]);
  const activeDictionarySection = useMemo(() => dictionarySections.find((section) => section.id === dictionarySection) ?? dictionarySections[0], [dictionarySection, dictionarySections]);
  const groupOptions = useMemo(() => {
    let source = (activeDictionaryCategory?.options ?? []).filter((option) => contentMode !== "nsfw" || option.audience !== "youth");
    if (genderFilter !== "all" && isGenderFilterRelevant(activeDictionaryCategory)) source = source.filter((option) => getGenderTarget(option, activeDictionaryCategory) === genderFilter);
    if (!activeDictionarySection) return source;
    const allowed = new Set(activeDictionarySection.optionIds);
    return source.filter((option) => allowed.has(option.id));
  }, [activeDictionaryCategory, activeDictionarySection, contentMode, genderFilter]);
  const allOptions = useMemo(() => [...baseMergedCategories.flatMap((category) => category.options), ...customTags], [customTags]);
  const favoriteOptions = useMemo(() => allOptions.filter((option) => favoriteIds.includes(option.id)), [allOptions, favoriteIds]);
  const favoriteHistory = useMemo(() => history.filter((item) => item.favorite), [history]);
  const positive = selected.filter((option) => !option.negative);
  const negative = selected.filter((option) => option.negative);
  const positiveText = positive.map((option) => option.en).join(", ");
  const negativeText = negative.map((option) => option.en).join(", ");

  useEffect(() => { window.localStorage.setItem(storageKeys.favorites, JSON.stringify(favoriteIds)); }, [favoriteIds]);
  useEffect(() => { window.localStorage.setItem(storageKeys.customTags, JSON.stringify(customTags)); }, [customTags]);
  useEffect(() => { window.localStorage.setItem(storageKeys.history, JSON.stringify(history)); }, [history]);
  useEffect(() => { window.localStorage.setItem(storageKeys.presets, JSON.stringify(customPresets)); }, [customPresets]);
  useEffect(() => {
    if (!visibleDictionaryGroups.some((group) => group.id === dictionaryGroup)) setDictionaryGroup((visibleDictionaryGroups[0]?.id ?? "person") as DictionaryGroupId);
  }, [dictionaryGroup, visibleDictionaryGroups]);
  useEffect(() => {
    if (!dictionaryCategories.some((category) => category.id === dictionaryCategory)) setDictionaryCategory(dictionaryCategories[0]?.id ?? "");
  }, [dictionaryCategories, dictionaryCategory]);

  const chooseDictionaryGroup = (groupId: DictionaryGroupId) => {
    setDictionaryGroup(groupId);
    setGenderFilter("all");
    const group = dictionaryGroups.find((item) => item.id === groupId);
    const nextCategory = group?.ids.find((id) => selectableCategories.some((category) => category.id === id));
    if (nextCategory) {
      setDictionaryCategory(nextCategory);
      setDictionarySection("");
    }
  };

  const toggleOption = (option: PromptOption, forceTarget = selectionTarget) => {
    const isStyleRecipe = option.id.startsWith("recipe-style-");
    const shouldBeNegative = forceTarget === "negative" && !isStyleRecipe;
    setSelected((current) => {
      const existing = current.find((item) => item.id === option.id);
      if (existing && Boolean(existing.negative) === shouldBeNegative) return current.filter((item) => item.id !== option.id);
      return [...current.filter((item) => item.id !== option.id && (!isStyleRecipe || !item.id.startsWith("recipe-style-"))), { ...option, negative: shouldBeNegative }];
    });
  };

  const toggleFavorite = (option: PromptOption) => setFavoriteIds((current) => current.includes(option.id) ? current.filter((id) => id !== option.id) : [...current, option.id]);
  const toggleHistoryFavorite = (historyId: string) => setHistory((current) => current.map((item) => item.id === historyId ? { ...item, favorite: !item.favorite } : item));
  const deleteHistory = (historyId: string) => setHistory((current) => current.filter((item) => item.id !== historyId));

  const addCustomTag = () => {
    const en = customTagEn.trim().replace(/\s+/g, " ");
    const ja = customTagJa.trim() || en;
    if (!en) return;
    const newTag: PromptOption = { id: `custom-${Date.now()}`, en, ja };
    setCustomTags((current) => [newTag, ...current]);
    setFavoriteIds((current) => current.includes(newTag.id) ? current : [newTag.id, ...current]);
    setCustomTagEn(""); setCustomTagJa("");
  };
  const removeCustomTag = (id: string) => { setCustomTags((current) => current.filter((option) => option.id !== id)); setFavoriteIds((current) => current.filter((favoriteId) => favoriteId !== id)); setSelected((current) => current.filter((option) => option.id !== id)); };

  const saveCustomPreset = () => {
    const name = presetName.trim();
    if (!name || !selected.length) return;
    setCustomPresets((current) => [{ id: `preset-${Date.now()}`, name, options: selected.map((option) => ({ ...option })) }, ...current]);
    setPresetName("");
  };
  const applyPreset = (preset: CustomPreset) => { setSelected((current) => { const keyed = new Map(current.map((option) => [`${option.id}:${Boolean(option.negative)}`, option])); preset.options.forEach((option) => keyed.set(`${option.id}:${Boolean(option.negative)}`, { ...option })); return [...keyed.values()]; }); setActiveTab("home"); };
  const removePreset = (id: string) => setCustomPresets((current) => current.filter((preset) => preset.id !== id));

  const enableSfw = () => { setContentMode("sfw"); setSelected((current) => current.filter((option) => !nsfwOptionIds.has(option.id))); };
  const requestNsfw = () => { if (nsfwConfirmed) { setContentMode("nsfw"); setSelected((current) => current.filter((option) => !youthOptionIds.has(option.id))); return; } setShowNsfwDialog(true); };
  const enableNsfw = () => { setNsfwConfirmed(true); setContentMode("nsfw"); setSelected((current) => current.filter((option) => !youthOptionIds.has(option.id))); setShowNsfwDialog(false); };
  const restoreHistory = (item: HistoryItem) => { setSelected(item.options.filter((option) => (contentMode === "nsfw" || !nsfwOptionIds.has(option.id)) && (contentMode !== "nsfw" || !youthOptionIds.has(option.id))).map((option) => ({ ...option }))); setActiveTab("home"); };
  const clearAll = () => { setSelected([]); setCopied(null); setLastRandomRecipe(null); };
  const runRandom = () => { const generated = generateCuratedRandom(categories, contentMode); setSelected(generated.options); setLastRandomRecipe(generated.label); setCopied(null); };

  const copyText = async (text: string) => {
    if (!text) return;
    try { await navigator.clipboard.writeText(text); } catch { const textArea = document.createElement("textarea"); textArea.value = text; document.body.appendChild(textArea); textArea.select(); document.execCommand("copy"); textArea.remove(); }
  };
  const copyPrompt = async (target: "positive" | "negative" | "both") => {
    const combined = [positiveText && `Positive prompt:\n${positiveText}`, negativeText && `Negative prompt:\n${negativeText}`].filter(Boolean).join("\n\n");
    const text = target === "positive" ? positiveText : target === "negative" ? negativeText : combined;
    if (!text) return;
    await copyText(text); setCopied(target);
    const historyKey = `${positiveText}\u0000${negativeText}`;
    setHistory((current) => {
      const previous = current.find((item) => `${item.prompt}\u0000${item.negativePrompt ?? ""}` === historyKey);
      const next: HistoryItem[] = [{ id: previous?.id ?? `${Date.now()}`, prompt: positiveText, negativePrompt: negativeText, options: selected.map((option) => ({ ...option })), createdAt: new Date().toLocaleString("ja-JP"), favorite: previous?.favorite ?? false }, ...current.filter((item) => `${item.prompt}\u0000${item.negativePrompt ?? ""}` !== historyKey)];
      let regularCount = 0; return next.filter((item) => item.favorite || regularCount++ < 12);
    });
    window.setTimeout(() => setCopied(null), 1800);
  };

  const renderTagCard = (option: PromptOption) => <TagCard key={option.id} option={option} language={language} selected={selected.some((item) => item.id === option.id)} favorite={favoriteIds.includes(option.id)} onToggle={() => toggleOption(option)} onFavorite={() => toggleFavorite(option)} />;

  return (
    <div className={`kp-v2-shell ${activeTab !== "home" && selected.length ? "has-selection-dock" : ""}`}>
      <header className="kp-v2-header"><div className="kp-v2-brand"><PaletteMark className="kp-v2-brand-mark" /><div><strong>ことばパレット</strong><small>-AI画像プロンプト単語帳-</small></div></div><AppSettings language={language} onLanguageChange={setLanguage} theme={theme} onThemeToggle={() => toggleTheme?.()} contentMode={contentMode} onSfw={enableSfw} onNsfw={requestNsfw} /></header>
      {contentMode === "nsfw" && <div className="kp-v2-adult-notice"><ShieldCheck />NSFWモード：成人（18歳以上）の架空人物のみを対象にします。</div>}
      <div className="kp-v2-layout">
        <aside className="kp-v2-sidebar"><AppNavigation activeTab={activeTab} language={language} onChange={setActiveTab} variant="desktop" /><div className="kp-v2-sidebar-gacha"><span><Dices />{language === "ja" ? "今日のランダムガチャ" : "Random draw"}</span><small>{lastRandomRecipe ?? (language === "ja" ? "雰囲気ごとまとめて選びます" : "Build a balanced prompt")}</small><button type="button" onClick={runRandom}>{language === "ja" ? "まわす！" : "Draw"}</button></div><small className="kp-v2-sidebar-copy">© 2026 Kotoba Palette</small></aside>
        <main className="kp-v2-content">
          {activeTab === "home" && <section className="kp-v2-panel kp-v2-home-live">
            <div className="kp-v2-section-heading"><div><p className="kp-v2-eyebrow">PROMPT HOME</p><h2>{language === "ja" ? "生成したい内容を入力" : "Describe what you want to generate"}</h2></div><Sparkles /></div>
            <div className="kp-v2-input-card"><div className="kp-v2-home-card-heading"><span>{language === "ja" ? "生成したい内容を入力" : "Describe what you want to generate"}</span><small>{query.length} / 500</small></div><label className="kp-v2-search-box"><Search /><textarea value={query} maxLength={500} rows={3} onChange={(event) => setQuery(event.target.value)} placeholder={language === "ja" ? "例：魔法の森にいる少女、夕暮れ、ファンタジー" : "e.g. a girl in a magical forest at sunset, fantasy"} /></label>{searchMatches.length > 0 && <div className="kp-v2-suggestion-area"><span>{language === "ja" ? "サジェスト" : "Suggestions"}</span><div className="kp-v2-suggestion-grid">{searchMatches.map(renderTagCard)}</div></div>}</div>
            <div className="kp-v2-gacha-card"><div className="kp-v2-home-card-heading"><span>{language === "ja" ? "ランダムガチャ" : "Random draw"}</span><Dices /></div><div className="kp-v2-gacha-options"><span><Sparkles />{language === "ja" ? "アニメ人物" : "Anime character"}</span><span><Sparkles />{language === "ja" ? "やわらかいイラスト" : "Soft illustration"}</span><span><Sparkles />{language === "ja" ? "シネマティック" : "Cinematic"}</span></div><button className="kp-v2-random-card" type="button" onClick={runRandom}><Dices /><span><strong>{language === "ja" ? "ガチャをまわす" : "Run random draw"}</strong><small>{lastRandomRecipe ? `${language === "ja" ? "今回のレシピ" : "Recipe"}: ${lastRandomRecipe}` : language === "ja" ? "雰囲気に合うタグをまとめて選択" : "Pick a balanced set of tags"}</small></span></button></div>
            <div className="kp-v2-selected-strip"><div className="kp-v2-selected-head"><strong>{language === "ja" ? "選択中のタグ" : "Selected tags"}<span>{selected.length}</span></strong><button type="button" onClick={clearAll} disabled={!selected.length}><Trash2 />{language === "ja" ? "すべてクリア" : "Clear all"}</button></div><div>{selected.map((option) => <button key={`${option.id}-${option.negative ? "n" : "p"}`} onClick={() => toggleOption(option, option.negative ? "negative" : "positive")}><span>{option.en}<small>{option.ja}</small></span><X /></button>)}</div></div>
            <div className="kp-v2-output-block"><div className="kp-v2-output-heading"><strong>{language === "ja" ? "プロンプト出力" : "Prompt output"}</strong></div><div className="kp-v2-prompt-preview"><div><span>Positive prompt <b>{positive.length}</b></span><p>{positiveText || (language === "ja" ? "選んだタグがここにまとまります。" : "Selected tags will appear here.")}</p><button type="button" onClick={() => copyPrompt("positive")}>{copied === "positive" ? <Check /> : <Copy />}{copied === "positive" ? (language === "ja" ? "コピーしました" : "Copied") : (language === "ja" ? "コピー" : "Copy")}</button></div><div className="is-negative"><span>Negative prompt <b>{negative.length}</b></span><p>{negativeText || (language === "ja" ? "除外したいタグがここにまとまります。" : "Negative tags will appear here.")}</p><button type="button" onClick={() => copyPrompt("negative")}>{copied === "negative" ? <Check /> : <Copy />}{copied === "negative" ? (language === "ja" ? "コピーしました" : "Copied") : (language === "ja" ? "コピー" : "Copy")}</button></div></div>
            <div className="kp-v2-copy-both-card"><span>{language === "ja" ? "両方コピー" : "Copy both"}</span><p>{language === "ja" ? "ポジティブとネガティブをまとめてコピー" : "Copy positive and negative prompts together"}</p><button className="kp-v2-copy-both" type="button" disabled={!positiveText && !negativeText} onClick={() => copyPrompt("both")}>{copied === "both" ? <Check /> : <Copy />}{copied === "both" ? (language === "ja" ? "両方コピーしました" : "Copied both") : (language === "ja" ? "両方コピーする" : "Copy both")}</button></div></div>
            <div className="kp-v2-target-switch"><button className={selectionTarget === "positive" ? "is-active" : ""} onClick={() => setSelectionTarget("positive")}>{language === "ja" ? "ポジティブへ追加" : "Add to positive"}</button><button className={selectionTarget === "negative" ? "is-active is-negative" : ""} onClick={() => setSelectionTarget("negative")}>{language === "ja" ? "ネガティブへ追加" : "Add to negative"}</button></div>
            <button className="kp-v2-reset" type="button" onClick={clearAll}><RotateCcw />{language === "ja" ? "選択をリセット" : "Reset selection"}</button>
          </section>}

          {activeTab === "recipes" && <section className="kp-v2-panel">
            <div className="kp-v2-section-heading"><div><p className="kp-v2-eyebrow">STYLE RECIPES</p><h2>{language === "ja" ? "画風レシピ" : "Style recipes"}</h2></div></div><p className="kp-v2-lead">{language === "ja" ? "ひとつ選ぶだけで、画風・塗り・光・品質をまとめて追加します。" : "Add style, rendering, lighting and quality in one selection."}</p>
            <div className="kp-v2-recipe-grid">{recipeOptions.map((option) => <button type="button" key={option.id} className={selected.some((item) => item.id === option.id) ? "is-selected" : ""} onClick={() => toggleOption(option, "positive")}><strong>{language === "ja" ? option.ja : option.en}</strong><small>{language === "ja" ? option.en : option.ja}</small></button>)}</div>
            <div className="kp-v2-preset-builder"><div><strong>{language === "ja" ? "自作プリセット" : "Custom preset"}</strong><small>{language === "ja" ? "現在選択中のタグを、まとめて呼び出せるセットとして保存します。" : "Save the current tag selection as a reusable set."}</small></div><div className="kp-v2-inline-form"><input value={presetName} onChange={(event) => setPresetName(event.target.value)} placeholder={language === "ja" ? "プリセット名" : "Preset name"} /><button type="button" disabled={!presetName.trim() || !selected.length} onClick={saveCustomPreset}><Save />{language === "ja" ? "保存" : "Save"}</button></div></div>
            {customPresets.length > 0 && <div className="kp-v2-custom-preset-list">{customPresets.map((preset) => <article key={preset.id}><div><strong>{preset.name}</strong><small>{language === "ja" ? `${preset.options.length}タグ` : `${preset.options.length} tags`}</small></div><div><button type="button" onClick={() => applyPreset(preset)}>{language === "ja" ? "使う" : "Apply"}</button><button type="button" className="is-delete" onClick={() => removePreset(preset.id)} aria-label={language === "ja" ? "プリセットを削除" : "Delete preset"}><Trash2 /></button></div></article>)}</div>}
          </section>}

          {activeTab === "dictionary" && <section className="kp-v2-panel">
            <div className="kp-v2-section-heading"><div><p className="kp-v2-eyebrow">WORD BOOK</p><h2>{language === "ja" ? "単語帳" : "Word book"}</h2></div></div>
            <div className="kp-v2-dictionary-target"><span>{language === "ja" ? "タグの追加先" : "Add selected tags to"}</span><div><button type="button" className={selectionTarget === "positive" ? "is-active" : ""} onClick={() => setSelectionTarget("positive")}>{language === "ja" ? "ポジティブ" : "Positive"}</button><button type="button" className={selectionTarget === "negative" ? "is-active is-negative" : ""} onClick={() => setSelectionTarget("negative")}>{language === "ja" ? "ネガティブ" : "Negative"}</button></div></div>
            <div className="kp-v2-category-strip kp-v2-group-strip">{visibleDictionaryGroups.map((group) => <button type="button" className={dictionaryGroup === group.id ? "is-active" : ""} key={group.id} onClick={() => chooseDictionaryGroup(group.id)}>{language === "ja" ? group.ja : group.en}</button>)}</div>
            {dictionaryCategories.length > 0 && <div className="kp-v2-subcategory-strip">{dictionaryCategories.map((category) => <button type="button" className={dictionaryCategory === category.id ? "is-active" : ""} key={category.id} onClick={() => { setDictionaryCategory(category.id); setDictionarySection(""); setGenderFilter("all"); }}><span>{language === "ja" ? category.label : category.labelEn}</span><small>{category.options.length}</small></button>)}</div>}
            {dictionarySections.length > 0 && <div className="kp-v2-microcategory-wrap"><span>{language === "ja" ? "小分類" : "Subgroup"}</span><div className="kp-v2-microcategory-strip">{dictionarySections.map((section) => <button type="button" className={activeDictionarySection?.id === section.id ? "is-active" : ""} key={section.id} onClick={() => setDictionarySection(section.id)}><span>{language === "ja" ? section.ja : section.en}</span><small>{section.optionIds.length}</small></button>)}</div></div>}
            <DictionaryAttributeFilter category={activeDictionaryCategory} value={genderFilter} language={language} onChange={setGenderFilter} />
            {activeDictionaryCategory && <div className="kp-v2-dictionary-caption"><strong>{language === "ja" ? activeDictionaryCategory.label : activeDictionaryCategory.labelEn}</strong><span>{language === "ja" ? activeDictionaryCategory.hint : `${activeDictionaryCategory.options.length} tags`}</span></div>}
            <div className="kp-v2-tag-grid">{groupOptions.map(renderTagCard)}</div>
          </section>}

          {activeTab === "library" && <section className="kp-v2-panel">
            <div className="kp-v2-section-heading"><div><p className="kp-v2-eyebrow">MY LIBRARY</p><h2>{language === "ja" ? "マイライブラリ" : "My library"}</h2></div></div>
            <div className="kp-v2-library-tabs"><button className={libraryTab === "favorites" ? "is-active" : ""} onClick={() => setLibraryTab("favorites")}>{language === "ja" ? "お気に入りタグ" : "Favorite tags"}</button><button className={libraryTab === "history" ? "is-active" : ""} onClick={() => setLibraryTab("history")}>{language === "ja" ? "生成履歴" : "History"}</button><button className={libraryTab === "history-favorites" ? "is-active" : ""} onClick={() => setLibraryTab("history-favorites")}>{language === "ja" ? "お気に入り履歴" : "Favorite history"}</button><button className={libraryTab === "custom" ? "is-active" : ""} onClick={() => setLibraryTab("custom")}>{language === "ja" ? "自作タグ" : "Custom tags"}</button></div>
            {libraryTab === "favorites" && <div className="kp-v2-tag-grid kp-v2-library-content">{favoriteOptions.length ? favoriteOptions.map(renderTagCard) : <p className="kp-v2-empty">{language === "ja" ? "お気に入りタグはまだありません。" : "No favorite tags yet."}</p>}</div>}
            {(libraryTab === "history" || libraryTab === "history-favorites") && <div className="kp-v2-history-list kp-v2-library-content">{(libraryTab === "history" ? history : favoriteHistory).length ? (libraryTab === "history" ? history : favoriteHistory).map((item) => <article className="kp-v2-history-card" key={item.id}><button className={`kp-v2-history-star ${item.favorite ? "is-active" : ""}`} onClick={() => toggleHistoryFavorite(item.id)} aria-label={language === "ja" ? "履歴のお気に入り切替" : "Toggle favorite history"}><Star className={item.favorite ? "fill-current" : ""} /></button><button className="kp-v2-history-delete" onClick={() => deleteHistory(item.id)} aria-label={language === "ja" ? "履歴を削除" : "Delete history"}><Trash2 /></button><p><strong>Positive</strong>{item.prompt || "—"}</p><p className="is-negative"><strong>Negative</strong>{item.negativePrompt || "—"}</p><small>{item.createdAt}</small><button className="kp-v2-history-restore" onClick={() => restoreHistory(item)}>{language === "ja" ? "この履歴を復元" : "Restore this history"}</button></article>) : <p className="kp-v2-empty">{language === "ja" ? "履歴はまだありません。" : "No history yet."}</p>}</div>}
            {libraryTab === "custom" && <div className="kp-v2-library-content"><div className="kp-v2-custom-tag-form"><div><PlusCircle /><span><strong>{language === "ja" ? "自作タグを追加" : "Add custom tag"}</strong><small>{language === "ja" ? "英語タグと日本語訳をセットで保存します。" : "Save an English tag with its Japanese translation."}</small></span></div><div className="kp-v2-custom-tag-fields"><input value={customTagEn} onChange={(event) => setCustomTagEn(event.target.value)} placeholder="English tag 例: cozy room" /><input value={customTagJa} onChange={(event) => setCustomTagJa(event.target.value)} placeholder="日本語訳 例: 居心地のよい部屋" /><button type="button" disabled={!customTagEn.trim()} onClick={addCustomTag}>{language === "ja" ? "追加" : "Add"}</button></div></div><div className="kp-v2-tag-grid">{customTags.length ? customTags.map((option) => <div className="kp-v2-custom-row" key={option.id}>{renderTagCard(option)}<button className="kp-v2-custom-delete" onClick={() => removeCustomTag(option.id)} aria-label={language === "ja" ? "自作タグを削除" : "Delete custom tag"}><Trash2 /></button></div>) : <p className="kp-v2-empty">{language === "ja" ? "自作タグはまだありません。" : "No custom tags yet."}</p>}</div></div>}
          </section>}
        </main>
      </div>
      {activeTab !== "home" && <SelectedTagsDock selected={selected} language={language} onRemove={(option) => toggleOption(option, option.negative ? "negative" : "positive")} onClear={clearAll} />}
      <AppNavigation activeTab={activeTab} language={language} onChange={setActiveTab} variant="mobile" />
      {showNsfwDialog && <div className="kp-v2-modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="kp-nsfw-title"><div className="kp-v2-modal"><button className="kp-v2-modal-close" type="button" onClick={() => setShowNsfwDialog(false)} aria-label={language === "ja" ? "閉じる" : "Close"}><X /></button><ShieldCheck className="kp-v2-modal-icon" /><p className="kp-v2-eyebrow">CONTENT MODE</p><h2 id="kp-nsfw-title">{language === "ja" ? "NSFWの単語を表示しますか？" : "Show NSFW tags?"}</h2><p>{language === "ja" ? "このモードは、成人（18歳以上）の架空人物だけを対象にした成人向けキーワードを表示します。" : "This mode shows adult-oriented keywords intended only for fictional adults aged 18 or older."}</p><div className="kp-v2-modal-actions"><button type="button" onClick={() => setShowNsfwDialog(false)}>{language === "ja" ? "戻る" : "Back"}</button><button type="button" className="is-primary" onClick={enableNsfw}><ShieldCheck />{language === "ja" ? "18歳以上" : "I am 18+"}</button></div></div></div>}
    </div>
  );
}
