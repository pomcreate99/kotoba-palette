import { Check, Plus, Star } from "lucide-react";
import type { PromptOption } from "@/lib/prompt-data";
import type { UiLanguage } from "./types";

type TagCardProps = {
  option: PromptOption;
  language?: UiLanguage;
  selected?: boolean;
  favorite?: boolean;
  onToggle?: (option: PromptOption) => void;
  onFavorite?: (option: PromptOption) => void;
};

export function TagCard({ option, language = "ja", selected = false, favorite = false, onToggle, onFavorite }: TagCardProps) {
  const primary = language === "ja" ? option.ja : option.en;
  const secondary = language === "ja" ? option.en : option.ja;

  return (
    <div className={`kp-v2-tag-card ${selected ? "is-selected" : ""}`}>
      <button
        type="button"
        className="kp-v2-tag-main"
        onClick={() => onToggle?.(option)}
        disabled={!onToggle}
        aria-pressed={onToggle ? selected : undefined}
        aria-label={onToggle ? `${primary}：${selected ? (language === "ja" ? "選択済み" : "Selected") : (language === "ja" ? "未選択" : "Not selected")}` : undefined}
      >
        <span className="kp-v2-tag-copy">
          <span className="kp-v2-tag-primary">{primary}</span>
          <span className="kp-v2-tag-secondary">{secondary}</span>
        </span>
        <span className="kp-v2-tag-state" aria-hidden="true">
          {selected ? <Check /> : <Plus />}
        </span>
      </button>
      {onFavorite && (
        <button
          type="button"
          className={`kp-v2-tag-favorite ${favorite ? "is-favorite" : ""}`}
          aria-label={favorite ? "お気に入りから外す" : "お気に入りに追加"}
          onClick={() => onFavorite(option)}
        >
          <Star className={favorite ? "fill-current" : ""} />
        </button>
      )}
    </div>
  );
}
