import { Trash2, X } from "lucide-react";
import type { PromptOption } from "@/lib/prompt-data";
import type { UiLanguage } from "./types";

type Props = {
  selected: PromptOption[];
  language: UiLanguage;
  onRemove: (option: PromptOption) => void;
  onClear: () => void;
};

export function SelectedTagsDock({ selected, language, onRemove, onClear }: Props) {
  if (!selected.length) return null;

  return (
    <aside className="kp-v2-selection-dock" aria-label={language === "ja" ? "選択中のタグ" : "Selected tags"} aria-live="polite">
      <div className="kp-v2-selection-dock-head">
        <strong>{language === "ja" ? "選択中" : "Selected"}<span>{selected.length}</span></strong>
        <button type="button" onClick={onClear}><Trash2 />{language === "ja" ? "クリア" : "Clear"}</button>
      </div>
      <div className="kp-v2-selection-dock-tags">
        {selected.map((option) => (
          <button type="button" className={option.negative ? "is-negative" : ""} key={`${option.id}-${option.negative ? "n" : "p"}`} onClick={() => onRemove(option)} title={language === "ja" ? `${option.ja}を解除` : `Remove ${option.en}`}>
            <span>{language === "ja" ? option.ja : option.en}<small>{language === "ja" ? option.en : option.ja}</small></span>
            <X />
          </button>
        ))}
      </div>
    </aside>
  );
}
