import type { PromptCategory } from "@/lib/prompt-data";

export type DictionarySection = {
  id: string;
  ja: string;
  en: string;
  optionIds: string[];
};

type Rule = {
  id: string;
  ja: string;
  en: string;
  keywords: string[];
};

const rules: Record<string, Rule[]> = {
  demographics: [
    { id: "male", ja: "男性表現", en: "Male", keywords: ["man", "male", "gentleman", "boy", "masculine"] },
    { id: "female", ja: "女性表現", en: "Female", keywords: ["woman", "female", "lady", "girl", "feminine"] },
    { id: "neutral", ja: "中性・その他", en: "Neutral & other", keywords: ["androgynous", "nonbinary"] },
    { id: "age", ja: "年齢", en: "Age", keywords: ["young", "old", "elderly", "adult", "child", "teen", "school"] },
  ],
  "hair-style": [
    { id: "length", ja: "長さ", en: "Length", keywords: ["long", "short", "medium", "shoulder", "waist", "floor", "length"] },
    { id: "texture", ja: "髪質", en: "Texture", keywords: ["straight", "wavy", "curly", "fluffy", "messy", "wet", "shiny", "spiky", "silky"] },
    { id: "arrange", ja: "結び・まとめ髪", en: "Updos", keywords: ["ponytail", "twintail", "braid", "bun", "updo", "halfup", "pigtail", "dread", "cornrow"] },
    { id: "cut", ja: "カット・輪郭", en: "Cuts", keywords: ["bob", "pixie", "wolf", "mullet", "undercut", "buzz", "mohawk", "shag", "layered", "hime"] },
    { id: "bangs", ja: "前髪・横髪", en: "Bangs", keywords: ["bang", "fringe", "sidelock", "curtain", "ahoge"] },
  ],
  hair: [
    { id: "length", ja: "長さ", en: "Length", keywords: ["longhair", "shorthair", "mediumhair"] },
    { id: "texture", ja: "髪質・状態", en: "Texture", keywords: ["curly", "wavy", "straight", "messy", "wet", "shiny", "fluffy"] },
    { id: "arrange", ja: "髪型", en: "Styles", keywords: ["ponytail", "braid", "bang"] },
    { id: "color", ja: "髪色", en: "Color", keywords: ["blonde", "brunette", "hair", "platinum", "ashbrown", "two-tone", "gradient"] },
  ],
  "hair-detail": [
    { id: "cuts", ja: "カット", en: "Cuts", keywords: ["bob", "pixie", "mullet", "undercut", "buzz", "mohawk", "wolf", "shag", "layered", "hime"] },
    { id: "updos", ja: "結び・まとめ髪", en: "Updos", keywords: ["bun", "braid", "ponytail", "twintail", "halfup", "cornrow", "dread"] },
    { id: "bangs", ja: "前髪・横髪", en: "Bangs", keywords: ["bang", "sidelock", "ahoge"] },
    { id: "texture", ja: "ボリューム・質感", en: "Texture", keywords: ["afro", "undone", "messy"] },
  ],
  "hair-color": [
    { id: "natural", ja: "自然色", en: "Natural", keywords: ["black", "brown", "brunette", "blonde", "auburn", "ginger", "gray", "grey", "silver", "white"] },
    { id: "vivid", ja: "カラー", en: "Vivid", keywords: ["red", "orange", "yellow", "green", "blue", "purple", "violet", "pink", "cyan", "teal"] },
    { id: "mixed", ja: "複色・特殊", en: "Mixed", keywords: ["two", "dual", "gradient", "ombre", "streak", "highlight", "multicolor", "rainbow", "split"] },
  ],
  eyes: [
    { id: "color", ja: "瞳色", en: "Eye color", keywords: ["amber", "emerald", "violet", "blue", "brown", "grey", "red"] },
    { id: "gaze", ja: "視線", en: "Gaze", keywords: ["looking", "gazing", "glance", "downcast"] },
    { id: "shape", ja: "開き方・形", en: "Shape", keywords: ["wide", "closed", "halfclosed", "narrowed"] },
    { id: "effect", ja: "特殊表現", en: "Effects", keywords: ["glowing", "sparkling", "teary", "empty", "heterochromia"] },
  ],
  expression: [
    { id: "positive", ja: "笑顔・喜び", en: "Positive", keywords: ["smil", "joy", "laugh", "grin", "excited", "gentle", "confident"] },
    { id: "negative", ja: "悲しみ・怒り", en: "Negative", keywords: ["sad", "angry", "cry", "frown", "nervous", "bored", "fierce"] },
    { id: "quiet", ja: "静かな表情", en: "Quiet", keywords: ["serious", "calm", "sleepy", "thoughtful", "determined", "shy"] },
    { id: "mouth", ja: "口元", en: "Mouth", keywords: ["mouth", "tongue", "pout", "smirk"] },
    { id: "face", ja: "顔色・目元", en: "Face", keywords: ["blush", "embarrassed", "wideeyes"] },
  ],
  clothing: [
    { id: "tops", ja: "トップス", en: "Tops", keywords: ["shirt", "blouse", "sweater", "hoodie", "cardigan", "vest", "top", "tunic", "camisole"] },
    { id: "bottoms", ja: "ボトムス", en: "Bottoms", keywords: ["pants", "trousers", "jeans", "shorts", "skirt"] },
    { id: "outer", ja: "アウター", en: "Outerwear", keywords: ["jacket", "coat", "parka", "cloak", "cape", "windbreaker", "blazer"] },
    { id: "onepiece", ja: "ワンピース・全身", en: "One-piece", keywords: ["dress", "gown", "robe", "jumpsuit", "overalls", "bodysuit"] },
    { id: "uniform", ja: "制服・職業服", en: "Uniforms", keywords: ["uniform", "school", "military", "maid", "nurse", "labcoat", "apron"] },
    { id: "traditional", ja: "民族・伝統衣装", en: "Traditional", keywords: ["kimono", "hanfu", "sari", "traditional", "yukata", "qipao", "cheongsam"] },
    { id: "special", ja: "特殊衣装", en: "Special", keywords: ["armor", "swimsuit", "leotard", "costume", "fantasy"] },
  ],
  "clothing-detail": [
    { id: "tops", ja: "トップス種類", en: "Tops", keywords: ["shirt", "blouse", "cardigan", "turtleneck", "vest", "tanktop", "camisole", "crop", "polo"] },
    { id: "bottoms", ja: "ボトムス種類", en: "Bottoms", keywords: ["denim", "shorts", "trousers", "skirt", "overalls"] },
    { id: "neck", ja: "襟・首元", en: "Necklines", keywords: ["neck", "collar", "halter", "shoulder", "lapel"] },
    { id: "sleeve", ja: "袖", en: "Sleeves", keywords: ["sleeve", "cuff"] },
    { id: "decor", ja: "装飾・柄", en: "Decor", keywords: ["frill", "ruffle", "lace", "embroidery", "print", "pattern", "stripe", "check", "plaid", "floral", "polkadot"] },
  ],
  accessory: [
    { id: "head", ja: "頭・顔", en: "Head & face", keywords: ["glasses", "hat", "mask", "headphone", "crown", "ribbon", "veil", "flower", "feather"] },
    { id: "jewelry", ja: "ジュエリー", en: "Jewelry", keywords: ["earring", "necklace", "bracelet", "ring", "brooch", "choker", "pendant"] },
    { id: "bags", ja: "バッグ・携帯品", en: "Bags", keywords: ["bag", "backpack", "purse", "handbag", "tote", "wallet", "keychain"] },
    { id: "wear", ja: "身につける物", en: "Wearables", keywords: ["scarf", "gloves", "watch", "belt", "badge", "pin"] },
    { id: "props", ja: "持ち物", en: "Props", keywords: ["umbrella"] },
  ],
  footwear: [
    { id: "shoes", ja: "靴", en: "Shoes", keywords: ["sneaker", "loafer", "heel", "flat", "mary", "oxford", "brogue", "mule", "clog", "espadrille"] },
    { id: "boots", ja: "ブーツ", en: "Boots", keywords: ["boot"] },
    { id: "sandals", ja: "サンダル・和履物", en: "Sandals", keywords: ["sandal", "flipflop", "geta", "zori", "waraji"] },
    { id: "hosiery", ja: "靴下・脚まわり", en: "Hosiery", keywords: ["sock", "high", "legwarmer", "tabi"] },
    { id: "bare", ja: "裸足", en: "Barefoot", keywords: ["barefoot"] },
  ],
  role: [
    { id: "creative", ja: "創作・芸能", en: "Creative", keywords: ["artist", "musician", "dancer", "idol", "model", "actor", "writer", "poet"] },
    { id: "service", ja: "日常・サービス", en: "Everyday jobs", keywords: ["chef", "teacher", "barista", "gardener", "librarian", "mechanic", "doctor", "nurse", "student", "officeworker"] },
    { id: "science", ja: "科学・探索", en: "Science", keywords: ["scientist", "pilot", "astronaut", "explorer", "inventor", "philosopher"] },
    { id: "fantasy", ja: "魔法・宗教", en: "Fantasy", keywords: ["magician", "witch", "priest", "nun", "alchemist", "shaman", "oracle", "prophet"] },
    { id: "combat", ja: "戦闘・冒険", en: "Combat", keywords: ["knight", "samurai", "ninja", "hero", "villain", "mercenary", "assassin", "thief", "pirate", "soldier", "general"] },
    { id: "royal", ja: "王族", en: "Royalty", keywords: ["king", "queen", "prince", "princess", "emperor", "empress"] },
    { id: "relationship", ja: "物語上の役割", en: "Story roles", keywords: ["mentor", "apprentice", "antihero", "captain"] },
  ],
  action: [
    { id: "travel", ja: "移動", en: "Movement", keywords: ["walking", "running", "flying", "swimming", "jumping", "falling", "climbing", "chasing"] },
    { id: "pose", ja: "姿勢", en: "Posture", keywords: ["sitting", "standing", "kneeling", "crouching", "leaning", "stretching", "sleeping"] },
    { id: "hands", ja: "手・物との動作", en: "Hands & objects", keywords: ["holding", "reaching", "waving", "pointing", "carrying", "pushing", "pulling", "throwing", "catching"] },
    { id: "daily", ja: "日常動作", en: "Daily", keywords: ["reading", "writing", "painting", "drinking", "eating", "singing", "playing", "working"] },
    { id: "emotion", ja: "対人・感情", en: "Interaction", keywords: ["kissing", "hugging", "crying", "laughing", "hiding", "looking"] },
    { id: "combat", ja: "戦闘", en: "Combat", keywords: ["fighting"] },
  ],
  pose: [
    { id: "stance", ja: "立ち・座り", en: "Stance", keywords: ["standing", "sitting", "kneeling", "crouching", "crosslegged", "contrapposto"] },
    { id: "lying", ja: "寝姿勢", en: "Lying", keywords: ["lying", "reclining", "fetal", "side"] },
    { id: "hands", ja: "腕・手", en: "Arms & hands", keywords: ["arms", "hands", "hand", "covering", "salute", "bowing"] },
    { id: "dynamic", ja: "動き・動的", en: "Dynamic", keywords: ["jump", "stretch", "lean", "turn", "dynamic", "action", "power", "warrior", "treepose", "yoga"] },
    { id: "presentation", ja: "見せ方", en: "Presentation", keywords: ["elegant", "casual", "lookingback", "profile", "front", "back"] },
  ],
  setting: [
    { id: "nature", ja: "自然・屋外", en: "Nature", keywords: ["forest", "beach", "garden", "desert", "mountain", "underwater", "cave", "park"] },
    { id: "urban", ja: "街・公共空間", en: "Urban", keywords: ["city", "alley", "street", "rooftop", "station", "airport", "market", "bookstore", "museum", "gallery", "theater", "stadium", "gym"] },
    { id: "indoor", ja: "屋内・生活空間", en: "Indoor", keywords: ["library", "studio", "cafe", "bedroom", "bathroom", "kitchen", "living", "office", "classroom", "hospital", "apartment", "mansion"] },
    { id: "traditional", ja: "伝統・歴史", en: "Traditional", keywords: ["temple", "shrine", "castle", "ruins", "ryokan", "onsen"] },
    { id: "travel", ja: "宿泊・移動先", en: "Travel", keywords: ["cottage", "cabin", "tent", "pier", "bridge", "courtyard", "balcony"] },
    { id: "fantasy", ja: "SF・特殊空間", en: "Special", keywords: ["space", "spaceship"] },
  ],
  nature: [
    { id: "weather", ja: "天候", en: "Weather", keywords: ["rain", "snow", "fog", "cloud", "storm", "wind", "lightning", "mist", "hail", "thunder", "rainbow", "aurora"] },
    { id: "plants", ja: "植物", en: "Plants", keywords: ["flower", "leave", "petal", "blossom", "bamboo", "pine", "maple", "lotus", "sunflower", "rose", "lily", "grass", "moss"] },
    { id: "terrain", ja: "地形", en: "Terrain", keywords: ["field", "meadow", "hill", "valley", "cliff", "rock", "sand", "dune", "ice", "frost"] },
    { id: "water", ja: "水・水景", en: "Water", keywords: ["wave", "waterfall", "dew"] },
    { id: "sky", ja: "空・時間光", en: "Sky & light", keywords: ["starry", "moonlight", "sunbeam", "dusk", "dawn"] },
  ],
  water: [
    { id: "inland", ja: "川・湖・池", en: "Inland", keywords: ["river", "lake", "pond", "stream"] },
    { id: "sea", ja: "海・海岸", en: "Sea", keywords: ["ocean", "harbor", "island", "shore", "beach", "coast", "bay", "cove", "coral"] },
    { id: "structures", ja: "水辺の建造物", en: "Structures", keywords: ["lighthouse", "pier", "boat", "fountain", "aquarium", "pool"] },
    { id: "hotwater", ja: "温泉", en: "Hot springs", keywords: ["hot spring", "onsen"] },
    { id: "surface", ja: "水面・動き", en: "Surface", keywords: ["surface", "reflection", "ripple", "wave", "foam", "splash", "underwater"] },
  ],
  sky: [
    { id: "sunmoon", ja: "太陽・月", en: "Sun & moon", keywords: ["sun", "moon", "eclipse"] },
    { id: "stars", ja: "星・宇宙", en: "Stars & space", keywords: ["star", "galaxy", "comet", "planet", "constellation", "meteor", "nebula", "milky"] },
    { id: "atmosphere", ja: "空模様", en: "Sky conditions", keywords: ["cloud", "clear", "overcast", "rainbow", "aurora"] },
    { id: "timeofday", ja: "時間帯", en: "Time of day", keywords: ["sunset", "sunrise", "night"] },
  ],
  architecture: [
    { id: "historic", ja: "歴史様式", en: "Historic", keywords: ["gothic", "victorian", "artdeco", "baroque", "traditional"] },
    { id: "modern", ja: "近現代", en: "Modern", keywords: ["modern", "futuristic", "industrial", "minimalist", "brutalist"] },
    { id: "japan", ja: "和風建築", en: "Japanese", keywords: ["japanese", "pagoda", "torii", "shrine", "temple", "engawa", "shoji", "tatami", "fusuma"] },
    { id: "buildings", ja: "建物", en: "Buildings", keywords: ["castle", "mansion", "skyscraper", "tower", "dome", "ruins"] },
    { id: "elements", ja: "建築要素", en: "Elements", keywords: ["bridge", "arch", "column", "pillar", "staircase", "balcony", "veranda"] },
  ],
  object: [
    { id: "writing", ja: "文具・創作", en: "Writing & art", keywords: ["book", "notebook", "pen", "pencil", "brush", "palette", "easel", "frame", "photo", "letter", "envelope", "map"] },
    { id: "tech", ja: "機器", en: "Tech", keywords: ["camera", "phone", "smartphone", "laptop", "tablet", "telescope", "binocular"] },
    { id: "tableware", ja: "食器・容器", en: "Tableware", keywords: ["cup", "bottle", "glass", "plate", "bowl", "chopsticks", "fork", "knife", "spoon"] },
    { id: "decor", ja: "家具・装飾", en: "Decor", keywords: ["mirror", "chair", "clock", "candle", "vase", "lamp"] },
    { id: "travel", ja: "携行・収納", en: "Carry & storage", keywords: ["key", "compass", "umbrella", "fan", "parasol", "basket", "box", "chest"] },
    { id: "fantasy", ja: "武器", en: "Weapons", keywords: ["sword"] },
  ],
  roleV2: [
    { id: "creative", ja: "創作・芸能", en: "Creative", keywords: ["artist", "musician", "dancer", "idol", "model", "actor", "writer", "poet"] },
    { id: "daily", ja: "日常職", en: "Everyday", keywords: ["chef", "teacher", "barista", "gardener", "librarian", "mechanic", "doctor", "nurse", "student", "officeworker"] },
    { id: "science", ja: "科学・探索", en: "Science", keywords: ["scientist", "pilot", "astronaut", "explorer", "inventor"] },
    { id: "fantasy", ja: "魔法・信仰", en: "Fantasy", keywords: ["magician", "witch", "priest", "nun", "alchemist", "shaman", "oracle", "prophet"] },
    { id: "combat", ja: "戦闘・冒険", en: "Combat", keywords: ["knight", "samurai", "ninja", "hero", "villain", "mercenary", "assassin", "thief", "pirate", "soldier", "general"] },
    { id: "royal", ja: "王族", en: "Royalty", keywords: ["king", "queen", "prince", "princess", "emperor", "empress"] },
  ],
  species: [
    { id: "celestial", ja: "天使・精霊", en: "Celestial", keywords: ["angel", "fairy", "nymph", "dryad", "spirit", "elemental"] },
    { id: "demonic", ja: "悪魔・吸血種", en: "Demonic", keywords: ["demon", "vampire", "succubus", "incubus"] },
    { id: "beast", ja: "獣人・幻獣", en: "Beasts", keywords: ["werewolf", "centaur", "dragon", "phoenix", "unicorn", "griffin", "sphinx", "minotaur", "satyr", "harpy"] },
    { id: "humanoid", ja: "亜人", en: "Humanoids", keywords: ["elf", "mermaid", "dwarf", "halfling", "orc", "goblin", "troll", "ogre", "kobold", "giant"] },
    { id: "undead", ja: "アンデッド", en: "Undead", keywords: ["lich", "skeleton", "zombie", "ghost"] },
    { id: "yokai", ja: "妖怪・和風", en: "Yokai", keywords: ["kitsune", "yokai", "oni", "tengu", "kappa", "nue", "bakeneko", "nekomata", "inari", "foxspirit"] },
    { id: "myth", ja: "神話生物", en: "Mythic", keywords: ["gorgon", "medusa", "cyclops", "titan", "alien", "siren"] },
  ],
  animals: [
    { id: "mammal", ja: "哺乳類", en: "Mammals", keywords: ["dog", "cat", "fox", "horse", "rabbit", "wolf", "tiger", "lion", "elephant", "panda", "deer", "bear", "mouse", "rat", "hamster", "squirrel", "hedgehog", "raccoon", "ferret", "otter", "seal", "walrus", "koala", "kangaroo", "giraffe", "zebra", "hippo", "rhino", "camel", "llama", "alpaca", "goat", "sheep", "cow", "pig"] },
    { id: "birds", ja: "鳥類", en: "Birds", keywords: ["bird", "owl", "eagle", "hawk", "crow", "raven", "sparrow", "crane", "swan", "duck", "goose", "peacock", "chicken", "rooster", "phoenix"] },
    { id: "aquatic", ja: "水生生物", en: "Aquatic", keywords: ["whale", "fish", "shark", "dolphin", "octopus", "jellyfish", "crab"] },
    { id: "reptile", ja: "爬虫・両生類", en: "Reptiles", keywords: ["snake", "lizard", "frog", "turtle", "dragon"] },
    { id: "insect", ja: "昆虫・節足動物", en: "Insects", keywords: ["butterfly", "moth", "dragonfly", "firefly", "bee", "ant", "spider", "scorpion"] },
  ],
  machines: [
    { id: "computer", ja: "コンピュータ", en: "Computers", keywords: ["computer", "server", "terminal", "console", "monitor", "keyboard", "mouse", "ai", "circuit"] },
    { id: "camera", ja: "撮影機材", en: "Camera gear", keywords: ["camera", "lens", "tripod", "microphone", "headphone"] },
    { id: "vehicle", ja: "乗り物機械", en: "Vehicles", keywords: ["drone", "helicopter", "jet", "engine"] },
    { id: "space", ja: "宇宙機", en: "Space", keywords: ["satellite", "rocket", "spaceship", "starship"] },
    { id: "mecha", ja: "ロボット・メカ", en: "Robots & mecha", keywords: ["robot", "mecha", "mech", "android", "cyborg", "exosuit", "powerarmor", "exoskeleton"] },
    { id: "cyber", ja: "身体拡張・ナノ", en: "Cybernetics", keywords: ["prosthetic", "cybernetic", "nanomachine"] },
    { id: "mechanical", ja: "機構", en: "Mechanisms", keywords: ["gear", "machine"] },
  ],
  light: [
    { id: "natural", ja: "自然光", en: "Natural", keywords: ["sun", "overcast", "natural", "ambient", "moon"] },
    { id: "studio", ja: "撮影照明", en: "Studio", keywords: ["studio", "keylight", "filllight", "rim", "backlight", "softlight", "hardlight"] },
    { id: "dramatic", ja: "演出照明", en: "Dramatic", keywords: ["cinematic", "dramatic", "chiaroscuro", "rembrandt", "volumetric", "godrays", "beam"] },
    { id: "practical", ja: "人工・実用光", en: "Practical", keywords: ["neon", "candle"] },
    { id: "soft", ja: "柔らかい光", en: "Soft", keywords: ["diffused", "softlighting"] },
  ],
  style: [
    { id: "anime", ja: "アニメ・漫画", en: "Anime & comics", keywords: ["anime", "manga", "manhwa", "webtoon", "comic", "chibi", "cel", "lineart"] },
    { id: "painting", ja: "絵画・画材", en: "Painting", keywords: ["oil", "watercolor", "gouache", "pastel", "ink", "pencil", "charcoal", "painting", "sketch"] },
    { id: "art-history", ja: "美術様式", en: "Art history", keywords: ["impression", "expression", "surreal", "cubism", "baroque", "rococo", "renaissance", "romantic", "symbol", "artnouveau", "artdeco", "dada", "futurism"] },
    { id: "digital", ja: "デジタル表現", en: "Digital", keywords: ["digital", "3d", "lowpoly", "voxel", "pixel", "concept", "matte", "stylized"] },
    { id: "retro", ja: "レトロ・サイバー", en: "Retro & cyber", keywords: ["cyber", "steampunk", "dieselpunk", "atompunk", "solarpunk", "vapor", "synth", "retro", "cassette", "glitch"] },
    { id: "genre", ja: "ジャンル・世界観", en: "Genre", keywords: ["fantasy", "noir", "gothic", "cozy", "cottage", "fairy", "angel", "dream", "weird", "liminal", "nostalgic"] },
  ],
  material: [
    { id: "metal", ja: "金属", en: "Metals", keywords: ["metal", "gold", "silver", "bronze", "copper", "iron", "steel", "aluminum", "chrome", "brass"] },
    { id: "textile", ja: "布・繊維", en: "Textiles", keywords: ["fabric", "velvet", "silk", "leather", "cotton", "linen", "wool", "cashmere", "fur", "feather", "nylon", "polyester"] },
    { id: "stone", ja: "石・鉱物", en: "Stone & gems", keywords: ["stone", "marble", "granite", "crystal", "diamond", "ruby", "sapphire", "emerald", "amber", "jade", "obsidian", "quartz", "pearl"] },
    { id: "natural", ja: "木・天然素材", en: "Natural", keywords: ["paper", "wood", "bone", "ivory"] },
    { id: "ceramic", ja: "陶磁・建材", en: "Ceramic & masonry", keywords: ["ceramic", "porcelain", "concrete", "brick", "clay", "glass"] },
    { id: "synthetic", ja: "合成素材", en: "Synthetic", keywords: ["plastic", "rubber", "latex", "vinyl"] },
  ],
  surface: [
    { id: "finish", ja: "表面仕上げ", en: "Finish", keywords: ["smooth", "rough", "glossy", "matte", "polished", "brushed", "satin", "velvet", "textured"] },
    { id: "transparency", ja: "透明・反射", en: "Transparency", keywords: ["transparent", "translucent", "opaque", "reflective", "iridescent", "frosted"] },
    { id: "damage", ja: "経年・ダメージ", en: "Wear & damage", keywords: ["weathered", "worn", "cracked", "rust", "corrosion", "oxidation", "tarnish", "scratched", "dented", "torn", "ripped", "frayed"] },
    { id: "craft", ja: "加工・工芸", en: "Craft", keywords: ["etched", "engraved", "carved", "molded", "cast", "forged", "welded", "riveted", "stitched", "woven", "knitted", "crocheted", "embroidered", "lacquered"] },
    { id: "shape", ja: "変形・状態", en: "Shape & state", keywords: ["bent", "warped", "twisted", "folded", "crumpled", "wrinkled", "pleated", "gathered", "shattered", "fragmented", "powdered", "granular", "crystalline"] },
    { id: "physical", ja: "物性", en: "Physical", keywords: ["elastic", "brittle", "ductile", "malleable", "resilient", "flexible", "rigid", "stiff", "flimsy", "sturdy", "delicate", "fragile", "durable"] },
  ],
  effect: [
    { id: "film", ja: "フィルム・粒子", en: "Film", keywords: ["film", "grain", "noise", "scanline"] },
    { id: "light", ja: "光・レンズ", en: "Light & lens", keywords: ["glow", "bloom", "flare", "lightleak", "reflection", "refraction", "bokeh"] },
    { id: "blur", ja: "ぼかし・焦点", en: "Blur & focus", keywords: ["blur", "focus", "depthoffield", "tiltshift", "anamorphic", "fisheye"] },
    { id: "color", ja: "色調補正", en: "Color", keywords: ["chromatic", "duotone", "tritone", "toning", "grading", "lut", "contrast", "desaturated", "oversaturated", "warmtones", "cooltones", "sepia", "monochrome", "blackandwhite"] },
    { id: "distort", ja: "変形・デジタル", en: "Distortion", keywords: ["glitch", "distortion", "warping", "pixelation", "posterization", "solarization", "crossprocess", "hdr"] },
    { id: "particles", ja: "煙・粒子", en: "Particles", keywords: ["smoke", "spark", "dust", "particle"] },
  ],
  patterns: [
    { id: "classic", ja: "定番柄", en: "Classic", keywords: ["stripe", "polka", "checker", "plaid", "gingham", "houndstooth", "argyle", "tartan", "herringbone"] },
    { id: "ornament", ja: "装飾・民族柄", en: "Ornamental", keywords: ["floral", "paisley", "ornamental", "damask", "brocade", "jacquard", "ikat", "batik", "mandala"] },
    { id: "natural", ja: "自然素材柄", en: "Natural", keywords: ["marble", "woodgrain", "stone", "leather", "snake", "leopard", "zebra", "tiger", "giraffe", "scale", "feather", "wave", "cloud"] },
    { id: "geometry", ja: "幾何・図形", en: "Geometric", keywords: ["geometric", "zigzag", "star", "moon", "sun", "heart", "diamond", "circle", "square", "triangle", "hexagon", "mosaic", "fractal"] },
    { id: "gradient", ja: "グラデーション・特殊", en: "Gradient & special", keywords: ["tie dye", "ombre", "gradient", "noise", "glitch"] },
  ],
  "adult-wardrobe": [
    { id: "underwear", ja: "下着", en: "Underwear", keywords: ["bra", "panties", "briefs", "boxers", "underwear", "lingerie", "thong", "gstring"] },
    { id: "hosiery", ja: "ストッキング・タイツ", en: "Hosiery", keywords: ["stocking", "tights", "pantyhose", "fishnet", "kneehigh", "thighhigh", "socks", "garter"] },
    { id: "bodywear", ja: "ボディウェア", en: "Bodywear", keywords: ["bodysuit", "bodystocking", "leotard", "bustier", "corset", "chemise", "babydoll", "camisole"] },
    { id: "swim", ja: "水着", en: "Swimwear", keywords: ["bikini", "microbikini", "highleg"] },
    { id: "material", ja: "素材・透け", en: "Materials", keywords: ["latex", "leather", "lace", "satin", "silk", "mesh", "sheer", "transparent", "translucent", "opaque", "wetlook", "velvet"] },
    { id: "fit", ja: "フィット・形", en: "Fit", keywords: ["tight", "loose", "fitted", "oversized", "strapless", "halter", "racerback"] },
  ],
  "adult-pose": [
    { id: "stance", ja: "基本姿勢", en: "Stance", keywords: ["standing", "sitting", "kneeling", "lying", "reclining", "prone", "allfours", "sidepose"] },
    { id: "legs", ja: "脚", en: "Legs", keywords: ["leg", "knee", "straddling", "tiptoe", "bridge"] },
    { id: "arms", ja: "腕・手", en: "Arms & hands", keywords: ["arm", "hand", "covering", "revealing", "presenting", "displaying"] },
    { id: "face", ja: "顔・視線", en: "Face", keywords: ["looking", "eyes", "mouth", "tongue", "lip", "peeking"] },
    { id: "interaction", ja: "接触・交流", en: "Interaction", keywords: ["touching", "caressing", "kissing", "nuzzling", "cuddling", "spooning", "embracing"] },
    { id: "location", ja: "場所", en: "Location", keywords: ["wall", "table", "floor", "bed", "shower", "bath", "outdoors", "indoors"] },
  ],
  "adult-scene": [
    { id: "place", ja: "場所・背景", en: "Setting", keywords: ["boudoir", "bedroom", "mirror", "curtain", "sheet", "pillow", "bathtub", "room", "private"] },
    { id: "framing", ja: "構図・距離", en: "Framing", keywords: ["closeup", "rearview", "lowangle", "cropped", "silhouette", "backview", "profile", "wide", "narrow", "distant", "close", "far"] },
    { id: "light", ja: "照明", en: "Lighting", keywords: ["light", "volumetric", "godrays", "haze", "smoke", "steam", "fog", "dust", "particle", "bokeh"] },
    { id: "focus", ja: "焦点・質感", en: "Focus & texture", keywords: ["focus", "blur", "sharp", "grain", "noise", "film", "analog", "digital"] },
    { id: "style", ja: "画風・表現", en: "Style", keywords: ["cinematic", "photographic", "painterly", "illustration", "realistic", "stylized", "abstract", "minimal", "maximal", "detailed", "simple", "complex"] },
    { id: "density", ja: "画面密度", en: "Density", keywords: ["busy", "empty", "full", "crowded", "sparse", "intimate"] },
    { id: "scale", ja: "大きさ・縦横", en: "Scale", keywords: ["tall", "short", "large", "small", "huge", "tiny"] },
  ],
};

const groupFallbackRules: Record<string, Rule[]> = {
  person: [
    { id: "identity", ja: "人物・属性", en: "Identity", keywords: ["person", "human", "male", "female", "man", "woman", "boy", "girl", "adult", "young", "old", "androgyn", "nonbinary"] },
    { id: "body", ja: "身体", en: "Body", keywords: ["body", "skin", "tall", "short", "slim", "muscular", "curvy", "athletic", "petite", "broad", "thigh", "hip", "waist", "shoulder"] },
    { id: "face", ja: "顔・目", en: "Face", keywords: ["eye", "brow", "face", "lip", "cheek", "freckle", "makeup", "scar"] },
    { id: "hair", ja: "髪", en: "Hair", keywords: ["hair", "bang", "ponytail", "braid", "bun"] },
    { id: "emotion", ja: "表情・感情", en: "Expression", keywords: ["smil", "sad", "angry", "calm", "cry", "laugh", "shy", "confident"] },
    { id: "role", ja: "役割", en: "Role", keywords: ["artist", "teacher", "doctor", "student", "knight", "hero", "king", "queen", "witch"] },
  ],
  wardrobe: [
    { id: "tops", ja: "トップス", en: "Tops", keywords: ["shirt", "blouse", "sweater", "hood", "cardigan", "vest", "top", "tunic", "camisole"] },
    { id: "bottoms", ja: "ボトムス", en: "Bottoms", keywords: ["pants", "trousers", "jeans", "shorts", "skirt"] },
    { id: "outer", ja: "アウター", en: "Outerwear", keywords: ["jacket", "coat", "parka", "cloak", "cape", "blazer"] },
    { id: "onepiece", ja: "全身衣装", en: "One-piece", keywords: ["dress", "robe", "gown", "jumpsuit", "uniform", "kimono", "sari", "hanfu"] },
    { id: "head", ja: "頭部", en: "Headwear", keywords: ["hat", "cap", "beret", "hood", "hair", "crown", "helmet"] },
    { id: "accessories", ja: "装身具", en: "Accessories", keywords: ["ring", "necklace", "bracelet", "earring", "belt", "bag", "watch", "glove", "scarf"] },
    { id: "feet", ja: "足元", en: "Footwear", keywords: ["shoe", "boot", "sandal", "sock", "heel", "barefoot", "geta", "zori"] },
  ],
  motion: [
    { id: "stance", ja: "姿勢", en: "Stance", keywords: ["stand", "sit", "kneel", "crouch", "lie", "recline", "lean"] },
    { id: "movement", ja: "移動・動き", en: "Movement", keywords: ["walk", "run", "jump", "fly", "swim", "dance", "climb"] },
    { id: "hands", ja: "手・腕", en: "Hands", keywords: ["hand", "arm", "wave", "point", "hold", "salut", "pray"] },
    { id: "interaction", ja: "交流", en: "Interaction", keywords: ["hug", "kiss", "handshake", "highfive", "conversation", "help", "cheer"] },
    { id: "activity", ja: "活動", en: "Activity", keywords: ["read", "write", "draw", "sport", "play", "sing", "work", "garden"] },
  ],
  scene: [
    { id: "outdoor", ja: "屋外・自然", en: "Outdoor", keywords: ["forest", "mountain", "beach", "river", "lake", "ocean", "field", "park", "garden", "sky"] },
    { id: "indoor", ja: "屋内", en: "Indoor", keywords: ["room", "kitchen", "bath", "office", "cafe", "restaurant", "library", "classroom", "studio", "hotel"] },
    { id: "urban", ja: "街・交通", en: "Urban", keywords: ["city", "street", "alley", "station", "airport", "market", "bridge", "building"] },
    { id: "historic", ja: "伝統・歴史", en: "Historic", keywords: ["temple", "shrine", "castle", "traditional", "gothic", "victorian", "ruins"] },
    { id: "nature", ja: "自然現象", en: "Nature", keywords: ["rain", "snow", "fog", "cloud", "wind", "storm", "flower", "tree", "moon", "sun", "star"] },
    { id: "time", ja: "時間・季節", en: "Time", keywords: ["morning", "noon", "afternoon", "sunset", "twilight", "night", "spring", "summer", "autumn", "winter"] },
  ],
  frame: [
    { id: "distance", ja: "距離・範囲", en: "Distance", keywords: ["close", "medium", "full", "wide", "macro", "distant", "body"] },
    { id: "angle", ja: "角度", en: "Angle", keywords: ["angle", "overhead", "eye", "bird", "worm", "aerial", "rear", "front", "side"] },
    { id: "focus", ja: "焦点・レンズ", en: "Focus", keywords: ["focus", "bokeh", "lens", "fisheye", "telephoto", "depth", "f1.", "f2.", "iso"] },
    { id: "composition", ja: "構図", en: "Composition", keywords: ["symmetry", "third", "center", "diagonal", "space", "framing", "crop", "layer", "minimal", "dynamic"] },
    { id: "comic", ja: "漫画演出", en: "Comic", keywords: ["panel", "bubble", "line", "caption", "dialogue", "manga", "sound"] },
  ],
  finish: [
    { id: "quality", ja: "品質", en: "Quality", keywords: ["quality", "detail", "sharp", "crisp", "highres", "8k", "master", "polish"] },
    { id: "light", ja: "光", en: "Lighting", keywords: ["light", "glow", "bloom", "flare", "ray", "ambient", "shadow"] },
    { id: "color", ja: "色・トーン", en: "Color", keywords: ["color", "red", "blue", "green", "pink", "yellow", "warm", "cool", "pastel", "mono", "contrast", "sepia"] },
    { id: "style", ja: "画風", en: "Style", keywords: ["anime", "manga", "real", "paint", "watercolor", "sketch", "digital", "pixel", "fantasy", "gothic", "retro", "cyber"] },
    { id: "material", ja: "素材・質感", en: "Material", keywords: ["metal", "wood", "paper", "glass", "fabric", "silk", "leather", "stone", "texture", "surface"] },
    { id: "effect", ja: "効果", en: "Effects", keywords: ["grain", "noise", "blur", "glitch", "particle", "smoke", "bokeh", "chromatic", "exposure"] },
  ],
  creatures: [
    { id: "mammal", ja: "哺乳・獣", en: "Mammals", keywords: ["dog", "cat", "fox", "wolf", "bear", "horse", "rabbit", "lion", "tiger", "deer"] },
    { id: "bird", ja: "鳥", en: "Birds", keywords: ["bird", "owl", "eagle", "crow", "swan", "duck", "phoenix"] },
    { id: "water", ja: "水生", en: "Aquatic", keywords: ["fish", "whale", "shark", "dolphin", "octopus", "jelly"] },
    { id: "fantasy", ja: "幻獣・人外", en: "Fantasy", keywords: ["dragon", "elf", "mermaid", "angel", "demon", "fairy", "vampire", "yokai", "oni", "goblin"] },
    { id: "small", ja: "小動物・虫", en: "Small creatures", keywords: ["mouse", "hamster", "squirrel", "butterfly", "bee", "spider", "frog", "lizard"] },
  ],
  objects: [
    { id: "tech", ja: "機械・デジタル", en: "Tech", keywords: ["computer", "phone", "camera", "robot", "machine", "drone", "engine", "circuit", "tablet", "laptop"] },
    { id: "transport", ja: "乗り物", en: "Transport", keywords: ["train", "bus", "car", "bicycle", "ship", "airplane", "spaceship", "taxi", "motorcycle"] },
    { id: "daily", ja: "日用品", en: "Daily objects", keywords: ["book", "cup", "chair", "clock", "key", "bottle", "plate", "bag", "umbrella"] },
    { id: "food", ja: "飲食", en: "Food & drink", keywords: ["coffee", "tea", "cake", "bread", "sushi", "ramen", "fruit", "water", "juice", "wine", "beer"] },
    { id: "school", ja: "学用品・遊び", en: "School & hobby", keywords: ["notebook", "pencil", "crayon", "backpack", "toy", "ball", "puzzle"] },
  ],
  adult: [
    { id: "body", ja: "身体", en: "Body", keywords: ["body", "skin", "breast", "chest", "hip", "thigh", "waist", "shoulder", "back", "torso", "abs"] },
    { id: "wardrobe", ja: "衣装", en: "Wardrobe", keywords: ["lingerie", "bra", "panties", "stocking", "corset", "bikini", "bodysuit", "latex", "lace"] },
    { id: "pose", ja: "ポーズ", en: "Pose", keywords: ["standing", "sitting", "kneeling", "lying", "hand", "leg", "looking"] },
    { id: "mood", ja: "雰囲気", en: "Mood", keywords: ["sensual", "romantic", "intimate", "playful", "confident", "shy", "warm", "soft"] },
    { id: "scene", ja: "構図・背景", en: "Scene", keywords: ["bedroom", "boudoir", "closeup", "light", "focus", "cinematic", "mirror"] },
  ],
};

const groupByCategory: Record<string, keyof typeof groupFallbackRules> = {};
[
  ["person", ["subject", "demographics", "count", "relationships", "physique", "skin", "face-detail", "brows", "eye-color", "eye-shape", "hair-color", "hair-style", "hair", "hair-detail", "expression", "role"]],
  ["creatures", ["animals", "species", "creature-features", "mascot"]],
  ["objects", ["machines", "transport", "object", "school-hobby-props", "food", "dessert", "drinks"]],
  ["wardrobe", ["clothing", "clothing-detail", "headwear", "accessory", "accessory-detail", "footwear"]],
  ["motion", ["action", "pose", "gesture", "interaction", "hobby-sport"]],
  ["scene", ["setting", "school-background", "interior", "architecture", "nature", "water", "sky", "time", "scenery", "places"]],
  ["frame", ["camera", "shot-distance", "camera-tech", "angle", "placement", "composition", "comic-meta"]],
  ["finish", ["quality", "design", "coloring", "light", "lighting-detail", "color", "tone", "medium", "style", "world", "material", "patterns", "surface", "art-materials", "mood", "effect", "optics", "anime-detail"]],
  ["adult", ["adult-body", "adult-chest", "adult-genitals", "adult-skin", "adult-reaction", "adult-anatomy", "adult-wardrobe", "adult-mood", "adult-pose", "adult-scene"]],
].forEach(([group, ids]) => (ids as string[]).forEach((id) => { groupByCategory[id] = group as keyof typeof groupFallbackRules; }));

function buildRuleSections(category: PromptCategory, categoryRules: Rule[]): DictionarySection[] {
  const used = new Set<string>();
  const sections = categoryRules
    .map((rule) => {
      const optionIds = category.options
        .filter((option) => {
          if (used.has(option.id)) return false;
          const haystack = `${option.id} ${option.en} ${option.ja}`.toLowerCase();
          const matched = rule.keywords.some((keyword) => haystack.includes(keyword.toLowerCase()));
          if (matched) used.add(option.id);
          return matched;
        })
        .map((option) => option.id);
      return { id: rule.id, ja: rule.ja, en: rule.en, optionIds };
    })
    .filter((section) => section.optionIds.length > 0);

  const other = category.options.filter((option) => !used.has(option.id)).map((option) => option.id);
  if (other.length) sections.push({ id: "other", ja: "その他", en: "Other", optionIds: other });
  return sections;
}

function buildChunkSections(category: PromptCategory): DictionarySection[] {
  if (category.options.length <= 12) {
    return [{ id: "all", ja: "すべて", en: "All", optionIds: category.options.map((option) => option.id) }];
  }
  const chunkSize = category.options.length > 64 ? 16 : category.options.length > 36 ? 14 : 12;
  const labels = [
    ["basic", "基本", "Core"],
    ["detail", "詳細", "Details"],
    ["variation", "バリエーション", "Variations"],
    ["extended", "拡張", "Extended"],
    ["more", "その他", "More"],
  ] as const;
  const chunks: DictionarySection[] = [];
  for (let index = 0; index < category.options.length; index += chunkSize) {
    const [id, ja, en] = labels[Math.min(chunks.length, labels.length - 1)];
    const suffix = chunks.length >= labels.length ? `-${chunks.length + 1}` : "";
    chunks.push({ id: `${id}${suffix}`, ja: chunks.length >= labels.length ? `${ja}${chunks.length + 1}` : ja, en: chunks.length >= labels.length ? `${en} ${chunks.length + 1}` : en, optionIds: category.options.slice(index, index + chunkSize).map((option) => option.id) });
  }
  return chunks;
}

export function buildDictionarySections(category?: PromptCategory): DictionarySection[] {
  if (!category || !category.options.length) return [];
  const specific = rules[category.id];
  if (specific?.length) {
    const sections = buildRuleSections(category, specific);
    if (sections.length >= 2 || category.options.length <= 12) return sections;
  }

  const group = groupByCategory[category.id];
  if (group) {
    const sections = buildRuleSections(category, groupFallbackRules[group]);
    if (sections.length >= 2) return sections;
  }

  return buildChunkSections(category);
}
