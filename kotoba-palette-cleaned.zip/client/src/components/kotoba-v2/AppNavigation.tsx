import { BookOpenText, Home, Library, WandSparkles } from "lucide-react";
import type { KotobaTab, UiLanguage } from "./types";
import { kotobaTabs } from "./types";

const icons = {
  recipes: WandSparkles,
  home: Home,
  dictionary: BookOpenText,
  library: Library,
} as const;

type AppNavigationProps = {
  activeTab: KotobaTab;
  language: UiLanguage;
  onChange: (tab: KotobaTab) => void;
  variant?: "mobile" | "desktop";
};

export function AppNavigation({ activeTab, language, onChange, variant = "mobile" }: AppNavigationProps) {
  const isMobile = variant === "mobile";

  return (
    <nav
      className={isMobile ? "kp-v2-mobile-nav" : "kp-v2-desktop-nav"}
      aria-label={language === "ja" ? "メインナビゲーション" : "Main navigation"}
    >
      {kotobaTabs.map((tab) => {
        const Icon = icons[tab.id];
        const active = activeTab === tab.id;
        const label = language === "ja" ? tab.labelJa : tab.labelEn;
        const secondaryLabel = language === "ja" ? tab.labelEn : tab.labelJa;
        return (
          <button
            key={tab.id}
            type="button"
            className={`kotoba-v2-nav-item ${active ? "is-active" : ""} ${tab.id === "home" ? "is-home" : ""}`}
            aria-current={active ? "page" : undefined}
            onClick={() => onChange(tab.id)}
          >
            <Icon className="kotoba-v2-nav-icon" aria-hidden="true" />
            <span className="kotoba-v2-nav-copy">
              <strong>{label}</strong>
              {!isMobile && <small>{secondaryLabel}</small>}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
