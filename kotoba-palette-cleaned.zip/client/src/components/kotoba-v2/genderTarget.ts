import type { PromptCategory, PromptOption } from "@/lib/prompt-data";

export type GenderTarget = "male" | "female" | "unisex" | "other";
type PromptOptionWithGender = PromptOption & { genderTarget?: GenderTarget };

const maleTokens = [
  "man", "male", "male focus", "manly", "gentleman", "boy", "masculine", "king", "prince", "emperor", "incubus",
  "briefs", "boxers", "pectorals", "broadshoulders",
];

const femaleTokens = [
  "woman", "female", "lady", "girl", "feminine", "queen", "princess", "empress", "nun",
  "bra", "panties", "balconette", "demi", "fullcup", "pushup", "lingerie", "babydoll",
];

const otherTokens = ["other", "nonbinary", "androgynous", "genderless", "agender"];

const genderRelevantCategories = new Set([
  "subject", "demographics", "physique", "skin", "face-detail", "brows", "eye-color", "eye-shape",
  "hair-color", "hair-style", "hair", "hair-detail", "expression", "role", "clothing", "clothing-detail",
  "headwear", "accessory", "accessory-detail", "footwear", "adult-body", "adult-chest", "adult-genitals",
  "adult-skin", "adult-reaction", "adult-anatomy", "adult-wardrobe", "adult-mood", "adult-pose", "adult-scene",
]);

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function hasToken(value: string, token: string): boolean {
  const escaped = escapeRegExp(token.toLowerCase());
  return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, "i").test(value);
}

function getSubjectCountTarget(value: string): GenderTarget | null {
  if (/(^|[^a-z0-9])\d+\+?\s*girls?([^a-z0-9]|$)/i.test(value)) return "female";
  if (/(^|[^a-z0-9])\d+\+?\s*boys?([^a-z0-9]|$)/i.test(value)) return "male";
  if (/(^|[^a-z0-9])\d+\+?\s*others?([^a-z0-9]|$)/i.test(value)) return "other";
  return null;
}

export function isGenderFilterRelevant(category?: PromptCategory): boolean {
  return Boolean(category && genderRelevantCategories.has(category.id));
}

export function deriveGenderTarget(option: PromptOption, category?: PromptCategory): GenderTarget {
  const value = `${option.id} ${option.en} ${option.ja}`.toLowerCase();
  const subjectTarget = getSubjectCountTarget(value);
  if (subjectTarget) return subjectTarget;
  if (otherTokens.some((token) => hasToken(value, token))) return "other";
  if (femaleTokens.some((token) => hasToken(value, token))) return "female";
  if (maleTokens.some((token) => hasToken(value, token))) return "male";
  if (!isGenderFilterRelevant(category)) return "other";
  return "unisex";
}

export function withGenderTarget(category: PromptCategory): PromptCategory {
  return {
    ...category,
    options: category.options.map((option) => ({
      ...option,
      genderTarget: (option as PromptOptionWithGender).genderTarget ?? deriveGenderTarget(option, category),
    })),
  };
}

export function getGenderTarget(option: PromptOption, category?: PromptCategory): GenderTarget {
  return (option as PromptOptionWithGender).genderTarget ?? deriveGenderTarget(option, category);
}
