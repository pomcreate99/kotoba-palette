import { useEffect, useMemo, useState } from "react";
import { ChevronDown, SlidersHorizontal } from "lucide-react";
import type { PromptCategory } from "@/lib/prompt-data";
import { getUsefulGenderTargets, hasUsefulGenderFilter } from "./dictionaryUx";
import type { GenderTarget } from "./genderTarget";
import type { UiLanguage } from "./types";

type Props = {
  category?: PromptCategory;
  value: "all" | GenderTarget;
  language: UiLanguage;
  onChange: (value: "all" | GenderTarget) => void;
};

const labelsJa = { all: "すべて", male: "男性向け", female: "女性向け", unisex: "ユニセックス", other: "その他" } as const;
const labelsEn = { all: "All", male: "Male", female: "Female", unisex: "Unisex", other: "Other" } as const;

export function DictionaryAttributeFilter({ category, value, language, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const targets = useMemo(() => getUsefulGenderTargets(category), [category]);
  const useful = hasUsefulGenderFilter(category);

  useEffect(() => setOpen(false), [category?.id]);
  useEffect(() => {
    if (value !== "all" && !targets.includes(value)) onChange("all");
  }, [onChange, targets, value]);

  if (!useful) return null;
  const labels = language === "ja" ? labelsJa : labelsEn;

  return (
    <div className={`kp-v2-smart-filter ${open ? "is-open" : ""}`}>
      <button type="button" className="kp-v2-smart-filter-toggle" aria-expanded={open} onClick={() => setOpen((current) => !current)}>
        <span><SlidersHorizontal />{language === "ja" ? "絞り込み" : "Filter"}</span>
        <small>{language === "ja" ? `対象：${labels[value]}` : `Target: ${labels[value]}`}</small>
        <ChevronDown aria-hidden="true" />
      </button>
      {open && (
        <div className="kp-v2-smart-filter-options">
          <button type="button" className={value === "all" ? "is-active" : ""} aria-pressed={value === "all"} onClick={() => onChange("all")}>{labels.all}</button>
          {targets.map((target) => <button type="button" key={target} className={value === target ? "is-active" : ""} aria-pressed={value === target} onClick={() => onChange(target)}>{labels[target]}</button>)}
        </div>
      )}
    </div>
  );
}
