export function PaletteMark({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 64 64" role="img" aria-label="ことばパレット">
      <path d="M32 7C18 7 7 17 7 31c0 14 10 25 24 25 5 0 8-2 8-6 0-3-2-5-2-8 0-4 3-7 8-7h4c5 0 8-4 8-9C57 15 46 7 32 7Z" fill="currentColor" opacity=".13" />
      <path d="M32 8C18.7 8 8 17.6 8 30.4c0 13.3 10.2 24.1 23.2 24.1 4.8 0 7.4-1.8 7.4-5.2 0-2.8-2.2-4.7-2.2-8 0-4.7 3.7-8.1 8.8-8.1h4c4.7 0 7.8-3.3 7.8-8C57 15.4 46.2 8 32 8Z" fill="#EFE8DF" stroke="#362F8E" strokeWidth="2" />
      <circle cx="20" cy="27" r="4.2" fill="#E99E99" />
      <circle cx="27" cy="18" r="4.2" fill="#F0CC74" />
      <circle cx="38" cy="18" r="4.2" fill="#51A2CB" />
      <circle cx="45" cy="26" r="4.2" fill="#362F8E" />
      <path d="M39 48 55 31" stroke="#7A5A46" strokeWidth="5" strokeLinecap="round" />
      <path d="m50 28 7-6 2 2-6 7Z" fill="#51A2CB" stroke="#362F8E" strokeWidth="1.4" />
    </svg>
  );
}
