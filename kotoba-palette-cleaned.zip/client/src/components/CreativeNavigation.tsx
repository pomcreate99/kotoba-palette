import { BookOpen, FileText, Menu, ScrollText, Sparkles, StickyNote, UserRound, X, type LucideIcon } from "lucide-react";
import { useState, type ReactNode } from "react";
import { createPortal } from "react-dom";

type ToolId = "world-notebook" | "oc-setting-sheet" | "prompt-atlas" | "memo-to-markdown" | "infinite-scroll-memo" | "japanese-name-maker";

type Tool = {
  id: ToolId;
  name: string;
  description: string;
  href: string;
  accent: string;
  icon: LucideIcon;
};

const tools: Tool[] = [
  { id: "world-notebook", name: "世界観ノート", description: "物語の世界をつなぐ", href: "https://world.tkblab.jp/", accent: "#6c9272", icon: BookOpen },
  { id: "oc-setting-sheet", name: "キャラ設定帳", description: "創作キャラクターを整理", href: "https://chara.tkblab.jp/", accent: "#d76d52", icon: UserRound },
  { id: "prompt-atlas", name: "ことばパレット", description: "英日タグから指示を組み立てる", href: "https://kotoba.tkblab.jp/", accent: "#6faee8", icon: Sparkles },
  { id: "memo-to-markdown", name: "メモ整形", description: "メモをMarkdownへ整える", href: "https://markdown.tkblab.jp/", accent: "#c57566", icon: FileText },
  { id: "infinite-scroll-memo", name: "無限メモ", description: "思いつきをすぐ残す", href: "https://memo.tkblab.jp/", accent: "#7d8dc4", icon: StickyNote },
  { id: "japanese-name-maker", name: "なまえ帳", description: "物語に合う名前を探す", href: "https://name.tkblab.jp/", accent: "#bd5541", icon: ScrollText },
];

type CreativeNavigationProps = {
  current: ToolId;
  utilities?: ReactNode;
};

export function CreativeNavigation({ current, utilities }: CreativeNavigationProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const toolLinks = (mobile = false) => tools.map((tool) => {
    const Icon = tool.icon;
    const isCurrent = tool.id === current;
    const className = mobile ? "creative-nav-mobile-link" : "creative-nav-link";
    const content = <><span className="creative-nav-icon" style={{ color: tool.accent }}><Icon size={17} strokeWidth={2} /></span><span className="creative-nav-copy"><strong>{tool.name}</strong><small>{tool.description}</small></span>{isCurrent && <span className="creative-nav-current">使用中</span>}</>;
    return isCurrent ? <div key={tool.id} className={`${className} is-current`} aria-current="page">{content}</div> : <a key={tool.id} className={className} href={tool.href}>{content}</a>;
  });

  return <>
    <button type="button" className="creative-nav-menu-trigger" onClick={() => setMobileOpen(true)} aria-label="サイドメニューを開く" title="サイドメニューを開く"><Menu size={21} strokeWidth={2.4} /></button>
    {mobileOpen && createPortal(<div className="creative-nav-mobile-overlay" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setMobileOpen(false); }}>
      <aside className="creative-nav-mobile-panel" role="dialog" aria-modal="true" aria-label="POM TOOLS サイドメニュー">
        <div className="creative-nav-mobile-heading"><div className="creative-nav-heading"><span className="creative-nav-grid" aria-hidden="true"><i /><i /><i /><i /></span><span><strong>POM TOOLS</strong><small>CREATIVE WEB TOOLS</small></span></div><button type="button" onClick={() => setMobileOpen(false)} aria-label="サイドメニューを閉じる"><X size={19} /></button></div>
        <p className="creative-nav-caption">創作のための道具を、ひとつの場所に。</p>
        <nav className="creative-nav-mobile-list" aria-label="ツール一覧">{toolLinks(true)}</nav>
        {utilities && <div className="creative-nav-mobile-utilities"><p className="creative-nav-support-heading">TOOLS & SUPPORT</p><div className="creative-nav-support-list">{utilities}</div></div>}
      </aside>
    </div>, document.body)}
  </>;
}
