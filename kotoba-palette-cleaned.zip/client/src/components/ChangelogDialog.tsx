import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { X, ScrollText } from "lucide-react";
import { changelog } from "@/data/changelog";

export function ChangelogDialog() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <>
      <button
        type="button"
        className="changelog-trigger"
        onClick={() => setOpen(true)}
        aria-label="更新履歴を表示"
        title="更新履歴"
      >
        <ScrollText className="h-4 w-4" /><span>更新履歴</span>
      </button>
      {open && createPortal(
        <div className="changelog-overlay" role="dialog" aria-modal="true" aria-label="更新履歴">
          <div className="changelog-dialog">
            <header className="changelog-header">
              <div>
                <div className="flex items-center gap-2 text-[11px] font-bold tracking-[0.1em] text-[#6b6b6b]">
                  <ScrollText className="h-3.5 w-3.5" /> UPDATE HISTORY
                </div>
                <h2 className="mt-1 text-[22px] font-extrabold tracking-tight">更新履歴</h2>
                <p className="mt-1 text-xs text-[#6b6b6b]">ことばパレットの変更点をまとめています。</p>
              </div>
              <button type="button" onClick={() => setOpen(false)} aria-label="閉じる" className="rounded-full bg-[#f0eee9] p-2 transition-colors hover:bg-[#e5e2dc]">
                <X className="h-4 w-4" />
              </button>
            </header>
            <div className="changelog-body">
              {changelog.map((entry, i) => (
                <article className="changelog-entry" key={i}>
                  <div className="changelog-date">
                    <time>{entry.date}</time>
                  </div>
                  <div className="changelog-content">
                    <h3>{entry.title}</h3>
                    <ul>
                      {entry.changes.map((change, j) => (
                        <li key={j}>{change}</li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
            <footer className="changelog-footer">
              <button type="button" onClick={() => setOpen(false)} className="w-full rounded-full bg-[#111111] px-4 py-3 text-sm font-bold text-white sm:w-auto">閉じる</button>
            </footer>
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
