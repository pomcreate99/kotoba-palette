import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { MessageSquarePlus, X, Heart, Bug, Lightbulb, HelpCircle } from "lucide-react";

type Category = "感想" | "不具合" | "要望" | "その他";

const cats: { id: Category; Icon: typeof Bug }[] = [
  { id: "感想", Icon: Heart },
  { id: "不具合", Icon: Bug },
  { id: "要望", Icon: Lightbulb },
  { id: "その他", Icon: HelpCircle },
];

const API = "https://neo-butler-notify.neo-butler.workers.dev";

export function FeedbackDialog() {
  const [open, setOpen] = useState(false);
  const [category, setCategory] = useState<Category>("感想");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const handleOpen = () => { setOpen(true); setStatus("idle"); };

  const handleSubmit = async () => {
    if (!message.trim() || status === "sending") return;
    setStatus("sending");
    try {
      const res = await fetch(`${API}/feedback`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ category, message: message.trim(), sourceSiteId: "prompt-atlas", includeUserId: false }),
      });
      if (res.ok) {
        setStatus("sent");
        setTimeout(() => { setOpen(false); setStatus("idle"); setMessage(""); setCategory("感想"); }, 2000);
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };

  return (
    <>
      <button type="button" className="feedback-trigger" onClick={handleOpen} aria-label="問い合わせフォームを開く" title="問い合わせフォーム">
        <MessageSquarePlus className="h-4 w-4" /><span>問い合わせフォーム</span>
      </button>
      {open && createPortal(
        <div className="feedback-overlay" role="dialog" aria-modal="true" aria-label="問い合わせフォーム">
          <div className="feedback-dialog">
            {status === "sent" ? (
              <div className="feedback-sent">
                <Heart size={32} />
                <p>送信しました。<br />ありがとうございます！</p>
              </div>
            ) : (
              <>
                <header className="feedback-header">
                  <div>
                    <div className="flex items-center gap-2 text-[11px] font-bold tracking-[0.1em] text-[#6b6b6b]">
                      <MessageSquarePlus className="h-3.5 w-3.5" /> FEEDBACK
                    </div>
                    <h2 className="mt-1 text-[22px] font-extrabold tracking-tight">問い合わせフォーム</h2>
                    <p className="mt-1 text-xs text-[#6b6b6b]">名前・メールアドレスは不要です。</p>
                  </div>
                  <button type="button" onClick={() => setOpen(false)} aria-label="閉じる" className="rounded-full bg-[#f0eee9] p-2 transition-colors hover:bg-[#e5e2dc]">
                    <X className="h-4 w-4" />
                  </button>
                </header>
                <div className="feedback-body">
                  <div className="feedback-categories">
                    {cats.map(({ id, Icon }) => (
                      <button key={id} type="button" className={`feedback-cat${category === id ? " active" : ""}`} onClick={() => setCategory(id)}>
                        <Icon size={14} />{id}
                      </button>
                    ))}
                  </div>
                  <textarea
                    className="feedback-textarea"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="気づいたこと、困ったこと、追加してほしいこと…"
                    maxLength={2000}
                    rows={5}
                  />
                  {status === "error" && <p className="feedback-error">送信に失敗しました。少ししてから再試行してください。</p>}
                </div>
                <footer className="feedback-footer">
                  <button type="button" onClick={() => setOpen(false)} className="rounded-full bg-[#f0eee9] px-5 py-2.5 text-sm font-bold text-[#6b6b6b] transition-colors hover:bg-[#e5e2dc]">キャンセル</button>
                  <button type="button" onClick={handleSubmit} disabled={message.trim().length < 2 || status === "sending"} className="feedback-submit rounded-full bg-[#111111] px-5 py-2.5 text-sm font-bold text-white transition-opacity disabled:opacity-40">
                    {status === "sending" ? "送信中…" : "匿名で送信"}
                  </button>
                </footer>
              </>
            )}
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
