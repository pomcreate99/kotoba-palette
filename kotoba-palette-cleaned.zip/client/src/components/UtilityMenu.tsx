import { useEffect, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { Menu, X } from "lucide-react";

type UtilityMenuProps = { children: ReactNode };

export function UtilityMenu({ children }: UtilityMenuProps) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <div className="utility-menu">
      <button
        type="button"
        className="utility-menu-trigger"
        onClick={() => setOpen((current) => !current)}
        aria-expanded={open}
        aria-haspopup="menu"
        aria-label={open ? "メニューを閉じる" : "メニューを開く"}
        title={open ? "メニューを閉じる" : "メニュー"}
      >
        {open ? <X size={18} /> : <Menu size={18} />}
        <span>メニュー</span>
      </button>
      {open && createPortal(
        <div
          className="utility-menu-overlay"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setOpen(false);
          }}
        >
          <div className="utility-menu-panel" role="menu">
            <div className="utility-menu-heading">
              <strong>アプリメニュー</strong>
              <button type="button" className="utility-menu-close" onClick={() => setOpen(false)} aria-label="メニューを閉じる">
                <X size={16} />
              </button>
            </div>
            <div className="utility-menu-items">{children}</div>
          </div>
        </div>,
        document.body,
      )}
    </div>
  );
}
