/**
 * Kotoba Palette — soft pastel UI
 */
import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Bookmark,
  Check,
  ChevronDown,
  Clipboard,
  Copy,
  Dices,
  CircleHelp,
  Layers3,
  Plus,
  PlusCircle,
  RotateCcw,
  Search,
  ShieldCheck,
  Sparkles,
  Star,
  Trash2,
  X,
} from "lucide-react";
import { categories as baseCategories, youthOptionIds, type ContentMode, type PromptCategory, type PromptOption } from "@/lib/prompt-data";
import { mergeExtraCategories } from "@/lib/prompt-data-merge";
import { generateCuratedRandom } from "@/lib/prompt-random-recipes";
import { findPromptMatches } from "@/lib/prompt-search";
import { shouldOpenSearch } from "@/lib/searchShortcut";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const categories = mergeExtraCategories(baseCategories);
const nsfwOptionIds = new Set(
  categories
    .filter((category) => category.mode === "nsfw")
    .flatMap((category) => category.options.map((option) => option.id)),
);

type CategoryGroup = {
  id: string;
  label: string;
  labelEn: string;
  categoryIds: string[];
};

type HistoryItem = {
  id: string;
  prompt: string;
  negativePrompt?: string;
  options: PromptOption[];
  createdAt: string;
  favorite?: boolean;
};

function PromptAtlasLogo({ className = "h-11 w-11" }: { className?: string }) {
  return (
    <svg viewBox="0 0 56 44" className={className} fill="none" aria-hidden="true">
      <path d="M8 25.5C8 13.2 16.3 6 28.4 6c11.2 0 19.6 6.5 19.6 17.1 0 10.1-7.1 14.9-16.9 14.9-5.2 0-8.2-1.4-12.5-.4C11.9 39.2 8 34 8 25.5Z" fill="#A5D3FF" />
      <circle cx="25" cy="23" r="1.7" fill="#171717" />
      <circle cx="32" cy="23" r="1.7" fill="#171717" />
    </svg>
  );
}

const storageKeys = {
  favorites: "prompt-atlas:favorites",
  customTags: "prompt-atlas:custom-tags",
  history: "prompt-atlas:history",
};

function loadStored<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

const categoryGroups: CategoryGroup[] = [
  { id: "recipes", label: "レシピ", labelEn: "Recipes", categoryIds: ["recipe-style"] },
  { id: "person", label: "人物", labelEn: "People", categoryIds: ["subject", "demographics", "count", "relationships", "physique", "skin", "face-detail", "brows", "eye-color", "eye-shape", "hair-color", "hair-style", "expression", "role"] },
  { id: "creatures", label: "動物・幻獣", labelEn: "Creatures", categoryIds: ["animals", "species", "creature-features", "mascot"] },
  { id: "objects", label: "機械・物", labelEn: "Machines & things", categoryIds: ["machines", "transport", "object", "school-hobby-props", "food", "dessert", "drinks"] },
  { id: "wardrobe", label: "衣装", labelEn: "Wardrobe", categoryIds: ["clothing", "clothing-detail", "headwear", "accessory", "accessory-detail", "footwear"] },
  { id: "motion", label: "動き", labelEn: "Motion", categoryIds: ["action", "pose", "gesture", "interaction", "hobby-sport"] },
  { id: "scene", label: "背景・場所", labelEn: "Backgrounds", categoryIds: ["setting", "school-background", "interior", "architecture", "nature", "water", "sky", "time", "scenery", "places"] },
  { id: "frame", label: "画面", labelEn: "Framing", categoryIds: ["camera", "shot-distance", "camera-tech", "angle", "placement", "composition", "comic-meta"] },
  { id: "finish", label: "仕上げ", labelEn: "Finish", categoryIds: ["quality", "design", "coloring", "light", "lighting-detail", "color", "tone", "medium", "style", "world", "material", "patterns", "surface", "art-materials", "mood", "effect", "optics", "anime-detail"] },
  { id: "exclude", label: "除外候補", labelEn: "Negative", categoryIds: ["avoid"] },
  { id: "adult", label: "NSFW", labelEn: "Adult", categoryIds: ["adult-body", "adult-chest", "adult-genitals", "adult-skin", "adult-reaction", "adult-wardrobe", "adult-mood", "adult-pose", "adult-scene"] },
  { id: "custom", label: "自作タグ", labelEn: "Custom", categoryIds: ["custom"] },
];

export default function Home() {
  const [activeCategory, setActiveCategory] = useState("recipe-style");
  const [selected, setSelected] = useState<PromptOption[]>([]);
  const [query, setQuery] = useState("");
  const searchInputRef = useRef<HTMLInputElement | null>(null);
  const [copied, setCopied] = useState<"positive" | "negative" | "both" | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>(() => loadStored<HistoryItem[]>(storageKeys.history, []));
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => loadStored<string[]>(storageKeys.favorites, []));
  const [customTags, setCustomTags] = useState<PromptOption[]>(() => loadStored<PromptOption[]>(storageKeys.customTags, []));
  const [contentMode, setContentMode] = useState<ContentMode>("sfw");
  const [nsfwConfirmed, setNsfwConfirmed] = useState(false);
  const [showNsfwDialog, setShowNsfwDialog] = useState(false);
  const [showHelpDialog, setShowHelpDialog] = useState(false);
  const [activeGroup, setActiveGroup] = useState("recipes");
  const [isTagPanelOpen, setIsTagPanelOpen] = useState(false);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [libraryTab, setLibraryTab] = useState<"favorites" | "history" | "custom">("favorites");
  const [historyView, setHistoryView] = useState<"all" | "favorites">("all");
  const [isCustomTagDialogOpen, setIsCustomTagDialogOpen] = useState(false);
  const [customTagEn, setCustomTagEn] = useState("");
  const [customTagJa, setCustomTagJa] = useState("");
  const [expandedHistoryIds, setExpandedHistoryIds] = useState<string[]>([]);
  const [lastRandomRecipe, setLastRandomRecipe] = useState<string | null>(null);
  const [selectionTarget, setSelectionTarget] = useState<"positive" | "negative">("positive");

  const dynamicCategories = useMemo<PromptCategory[]>(() => customTags.length ? [...categories, { id: "custom", label: "自作タグ", labelEn: "Custom tags", hint: "端末に保存した自分だけのタグ", options: customTags }] : categories, [customTags]);
  const availableOptions = useMemo(() => {
    const merged = categories.flatMap((category) => category.options);
    return [...merged, ...customTags];
  }, [customTags]);

  const visibleCategories = useMemo(
    () => dynamicCategories.filter((category) => (category.mode !== "nsfw" || contentMode === "nsfw") && (contentMode !== "nsfw" || category.audience !== "youth")),
    [contentMode, dynamicCategories],
  );
  const selectableCategories = useMemo(
    () => visibleCategories.filter((category) => selectionTarget === "negative" ? category.id !== "recipe-style" : category.id !== "avoid"),
    [selectionTarget, visibleCategories],
  );
  const optionsForMode = (options: PromptOption[]) => options.filter((option) => contentMode !== "nsfw" || option.audience !== "youth");
  const active = selectableCategories.find((category) => category.id === activeCategory) ?? selectableCategories[0];
  const availableGroups = useMemo(
    () => categoryGroups.filter((group) => selectableCategories.some((category) => group.categoryIds.includes(category.id))),
    [selectableCategories],
  );
  const groupedCategories = useMemo(
    () => {
      const categoryIds = categoryGroups.find((group) => group.id === activeGroup)?.categoryIds ?? [];
      return categoryIds
        .map((categoryId) => selectableCategories.find((category) => category.id === categoryId))
        .filter((category): category is PromptCategory => Boolean(category));
    },
    [activeGroup, selectableCategories],
  );
  const positivePromptText = useMemo(
    () => selected.filter((option) => !option.negative).map((option) => option.en).join(", "),
    [selected],
  );
  const negativePromptText = useMemo(
    () => selected.filter((option) => option.negative).map((option) => option.en).join(", "),
    [selected],
  );
  const positiveSelected = useMemo(() => selected.filter((option) => !option.negative), [selected]);
  const negativeSelected = useMemo(() => selected.filter((option) => option.negative), [selected]);
  const isSelected = (option: PromptOption) => selected.some((item) => item.id === option.id);
  const isFavorite = (option: PromptOption) => favoriteIds.includes(option.id);
  const favoriteOptions = useMemo(() => availableOptions.filter((option) => favoriteIds.includes(option.id)), [availableOptions, favoriteIds]);
  const favoriteHistory = useMemo(() => history.filter((item) => item.favorite), [history]);
  const visibleHistory = useMemo(() => historyView === "favorites" ? favoriteHistory : history, [favoriteHistory, history, historyView]);

  useEffect(() => { window.localStorage.setItem(storageKeys.favorites, JSON.stringify(favoriteIds)); }, [favoriteIds]);
  useEffect(() => { window.localStorage.setItem(storageKeys.customTags, JSON.stringify(customTags)); }, [customTags]);
  useEffect(() => { window.localStorage.setItem(storageKeys.history, JSON.stringify(history)); }, [history]);

  useEffect(() => {
    if (!selectableCategories.some((category) => category.id === activeCategory)) setActiveCategory(selectableCategories[0]?.id ?? "quality");
  }, [activeCategory, selectableCategories]);

  useEffect(() => {
    if (!availableGroups.some((group) => group.id === activeGroup)) setActiveGroup(availableGroups[0]?.id ?? "person");
  }, [activeGroup, availableGroups]);

  const searchResult = useMemo(() => {
    if (!query.trim()) {
      return { matches: optionsForMode(active?.options ?? []), isSentence: false };
    }
    const searchableOptions = selectableCategories
      .flatMap((category) => category.options)
      .filter((option) => option.audience !== "youth" || contentMode !== "nsfw");
    return findPromptMatches(query, searchableOptions);
  }, [active, query, selectableCategories, contentMode]);
  const visibleOptions = searchResult.matches;

  const toggleOption = (option: PromptOption) => {
    const isStyleRecipe = option.id.startsWith("recipe-style-");
    const shouldBeNegative = !isStyleRecipe && selectionTarget === "negative";
    setSelected((current) => {
      const existing = current.find((item) => item.id === option.id);
      if (existing && Boolean(existing.negative) === shouldBeNegative) {
        return current.filter((item) => item.id !== option.id);
      }
      return [
        ...current.filter((item) => item.id !== option.id && (!isStyleRecipe || !item.id.startsWith("recipe-style-"))),
        { ...option, negative: shouldBeNegative },
      ];
    });
  };

  const removeOption = (optionId: string) => {
    setSelected((current) => current.filter((option) => option.id !== optionId));
  };

  const clearAll = () => {
    setSelected([]);
    setCopied(null);
  };

  const clearCategory = () => {
    if (!active) return;
    const optionIds = new Set(active.options.map((option) => option.id));
    setSelected((current) => current.filter((option) => !optionIds.has(option.id)));
  };

  const randomize = () => {
    const generated = generateCuratedRandom(dynamicCategories, contentMode);
    setSelected(generated.options);
    setLastRandomRecipe(generated.label);
    setCopied(null);
  };

  const copyText = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const textArea = document.createElement("textarea");
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      textArea.remove();
    }
  };

  // "/" や Ctrl/Cmd+K で検索ボックスへフォーカスする
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (!shouldOpenSearch(event)) return;
      event.preventDefault();
      searchInputRef.current?.focus();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const copyPrompt = async (target: "positive" | "negative" | "both") => {
    const combinedPrompt = [
      positivePromptText && `Positive prompt:\n${positivePromptText}`,
      negativePromptText && `Negative prompt:\n${negativePromptText}`,
    ].filter(Boolean).join("\n\n");
    const text = target === "positive" ? positivePromptText : target === "negative" ? negativePromptText : combinedPrompt;
    if (!text) return;

    await copyText(text);
    setCopied(target);
    const historyKey = `${positivePromptText}\u0000${negativePromptText}`;
    setHistory((current) => {
      const previous = current.find((item) => `${item.prompt}\u0000${item.negativePrompt ?? ""}` === historyKey);
      const next: HistoryItem[] = [{
        id: previous?.id ?? `${Date.now()}`,
        prompt: positivePromptText,
        negativePrompt: negativePromptText,
        options: selected.map((option) => ({ ...option })),
        createdAt: new Date().toLocaleString("ja-JP"),
        favorite: previous?.favorite ?? false,
      }, ...current.filter((item) => `${item.prompt}\u0000${item.negativePrompt ?? ""}` !== historyKey)];

      let regularCount = 0;
      return next.filter((item) => item.favorite || regularCount++ < 12);
    });
    window.setTimeout(() => setCopied(null), 1800);
  };

  const enableNsfw = () => {
    setNsfwConfirmed(true);
    setContentMode("nsfw");
    setSelected((current) => current.filter((option) => !youthOptionIds.has(option.id)));
    setActiveCategory("adult-body");
    setActiveGroup("adult");
    setShowNsfwDialog(false);
  };

  const enableSfw = () => {
    setContentMode("sfw");
    setSelected((current) => current.filter((option) => !nsfwOptionIds.has(option.id)));
    setActiveCategory("quality");
    setActiveGroup("person");
  };

  const toggleFavorite = (option: PromptOption) => {
    setFavoriteIds((current) => current.includes(option.id) ? current.filter((id) => id !== option.id) : [...current, option.id]);
  };

  const toggleHistoryFavorite = (historyId: string) => {
    setHistory((current) => current.map((item) => item.id === historyId ? { ...item, favorite: !item.favorite } : item));
  };

  const addCustomTag = () => {
    const en = customTagEn.trim().replace(/\s+/g, "");
    const ja = customTagJa.trim() || en;
    if (!en) return;
    const newTag: PromptOption = { id: `custom-${Date.now()}`, en, ja };
    setCustomTags((current) => [newTag, ...current]);
    setFavoriteIds((current) => [newTag.id, ...current]);
    setCustomTagEn("");
    setCustomTagJa("");
    setIsCustomTagDialogOpen(false);
    setLibraryTab("custom");
    setIsLibraryOpen(true);
  };

  const removeCustomTag = (id: string) => {
    setCustomTags((current) => current.filter((option) => option.id !== id));
    setFavoriteIds((current) => current.filter((favoriteId) => favoriteId !== id));
    setSelected((current) => current.filter((option) => option.id !== id));
  };

  const restoreHistory = (item: HistoryItem) => {
    setSelected(item.options.filter((option) => (contentMode === "nsfw" || !nsfwOptionIds.has(option.id)) && (contentMode !== "nsfw" || !youthOptionIds.has(option.id))));
  };

  const openTagCategory = (categoryId: string) => {
    setActiveCategory(categoryId);
    if (categoryId === "avoid") setSelectionTarget("negative");
    setQuery("");
    setIsTagPanelOpen(true);
  };

  return (
    <div className="soft-studio with-creative-navigation min-h-screen text-[#111111]">
      <header className="soft-header sticky top-0 z-30">
        <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3"><a className="site-brand flex min-w-0 items-center gap-3" href="#top" aria-label="ことばパレット ホーム">
            <span className="brand-logo hidden h-11 w-14 items-center justify-center sm:flex"><PromptAtlasLogo /></span>
            <span className="site-brand-text">
              <span className="site-title">ことばパレット</span>
              <span className="site-subtitle">-AI画像プロンプト単語帳-</span>
            </span>
          </a></div>
          <div className="flex items-center gap-2">
            <div className="flex rounded-full bg-[#f0eee9] p-1 font-bold text-[11px]">
              <button type="button" onClick={enableSfw} className={`rounded-full px-3 py-2 transition-colors ${contentMode === "sfw" ? "bg-[#111111] text-white" : "text-[#6b6b6b]"}`}>SFW</button>
              <button type="button" onClick={() => (nsfwConfirmed ? setContentMode("nsfw") : setShowNsfwDialog(true))} className={`rounded-full px-3 py-2 transition-colors ${contentMode === "nsfw" ? "bg-[#e85d75] text-white" : "text-[#6b6b6b]"}`}>NSFW 18+</button>
            </div>
          </div>
        </div>
      </header>

      <main id="top" className="soft-main mx-auto max-w-[1400px] px-4 pb-14 sm:px-6 lg:px-8">
        <section className="soft-hero relative mt-5 overflow-hidden rounded-[28px] px-6 py-8 sm:px-8 sm:py-10">
          <div className="hero-mascot" aria-hidden="true">
            <div className="hero-mascot-head"><span /><span /></div>
            <div className="hero-mascot-accent hero-mascot-accent-pink" />
            <div className="hero-mascot-accent hero-mascot-accent-yellow" />
          </div>
          <div className="relative z-10 max-w-xl">
            <p className="text-[11px] font-bold tracking-[0.14em] text-[#6b6b6b]">BILINGUAL PROMPT INDEX</p>
            <h1 className="mt-3 text-[1.85rem] font-extrabold leading-[1.25] tracking-tight sm:text-[2.35rem]">
              単語を選んで、<br />画像の指示をつくる。
            </h1>
            <p className="mt-3 text-sm leading-6 text-[#5c5c5c] sm:text-[15px]">
              英語キーワードと日本語の意味を、カテゴリからサクッと選んでコピー。SFW / NSFW を切り替えながら組み立てられます。
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <span className="rounded-full bg-[#ffe59a] px-3 py-1 text-[11px] font-bold text-[#111]">タグ選択</span>
              <span className="rounded-full bg-[#b7e1d1] px-3 py-1 text-[11px] font-bold text-[#111]">日英対応</span>
              <span className="rounded-full bg-[#a5d3ff] px-3 py-1 text-[11px] font-bold text-[#111]">コピーすぐ</span>
            </div>
          </div>
        </section>

        {contentMode === "nsfw" && (
          <section className="mt-5 flex items-start gap-3 rounded-2xl bg-[#fff0f3] px-4 py-3 text-sm leading-6 text-[#7a3040]">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0" />
            <p><strong>NSFWモード</strong>が有効です。成人（18歳以上）の架空人物のみを対象にします。</p>
          </section>
        )}

        <section className="soft-workbench mt-5 grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_400px]">
          <div id="atlas" className="atlas-surface soft-card keyword-atlas order-1 lg:order-none">
            <div className="flex flex-col gap-4 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <div>
                <div className="flex items-center gap-2 text-[11px] font-bold text-[#6b6b6b]"><Layers3 className="h-3.5 w-3.5" /> Word index</div>
                <div className="mt-1 flex items-center gap-2">
                  <h2 className="text-xl font-bold tracking-tight">プロンプトの単語を選ぶ</h2>
                  <button
                    type="button"
                    onClick={() => setShowHelpDialog(true)}
                    className="inline-flex h-8 items-center gap-1 rounded-full bg-[#f0eee9] px-2.5 text-[11px] font-bold text-[#555555] transition-colors hover:bg-[#e5e2dc]"
                    aria-label="使い方を開く"
                  >
                    <CircleHelp className="h-4 w-4" />
                    使い方
                  </button>
                </div>
              </div>
              <div className="text-center sm:text-right">
                <button type="button" onClick={randomize} className="catalog-action inline-flex items-center justify-center gap-2 text-sm font-bold">
                  <Dices className="h-4 w-4" /> きれいにランダム
                  <span className="ml-1 flex h-6 w-6 items-center justify-center rounded-full bg-[#ffe59a] text-[#111111]"><Plus className="h-3.5 w-3.5" /></span>
                </button>
                {lastRandomRecipe && <p className="mt-1.5 text-[10px] font-bold text-[#6b6b6b]">今回のレシピ：{lastRandomRecipe}</p>}
              </div>
            </div>

            <div className="px-5 pb-4 sm:px-6">
              <label className="relative block">
                <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#9a9a9a]" />
                <input ref={searchInputRef} type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="単語または文章を入力（例：雨の夜の街で振り返る人物）" className="w-full rounded-full border border-[#e8e6e1] bg-[#fafaf8] py-3 pl-11 pr-4 text-sm outline-none focus:border-[#a5d3ff] focus:ring-4 focus:ring-[#a5d3ff]/25" />
              </label>
              <div className="mt-3 flex items-center justify-between gap-3">
                <span className="text-[11px] font-bold text-[#6b6b6b]">タグの追加先</span>
                <div className="flex rounded-full bg-[#f0eee9] p-1 text-[11px] font-bold">
                  <button
                    type="button"
                    onClick={() => setSelectionTarget("positive")}
                    className={`rounded-full px-3 py-2 transition-colors ${selectionTarget === "positive" ? "bg-[#111111] text-white" : "text-[#6b6b6b]"}`}
                  >
                    ポジティブ
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectionTarget("negative")}
                    className={`rounded-full px-3 py-2 transition-colors ${selectionTarget === "negative" ? "bg-[#e85d75] text-white" : "text-[#6b6b6b]"}`}
                  >
                    ネガティブ
                  </button>
                </div>
              </div>
            </div>

            <div className="min-w-0">
              <div className="px-4 pb-2 sm:px-5">
                <div className="group-tabs flex gap-2 overflow-x-auto pb-1">
                  {availableGroups.map((group) => {
                    const current = activeGroup === group.id;
                    const adultGroup = group.id === "adult";
                    return (
                      <button key={group.id} type="button" onClick={() => { setActiveGroup(group.id); if (group.id === "exclude") setSelectionTarget("negative"); setQuery(""); }} className={`index-tab min-w-max text-left ${current ? (adultGroup || group.id === "exclude") ? "bg-[#e85d75] text-white" : "bg-[#111111] text-white" : ""}`}>
                        <span className="block text-sm font-bold">{group.label}</span>
                        <span className={`block text-[10px] ${current ? "text-white/70" : "text-[#8a8a8a]"}`}>{group.labelEn}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="min-w-0 p-4 sm:p-6">
                <h3 className="mb-1 text-2xl font-bold tracking-tight">
                  {query ? (searchResult.isSentence ? "文章から抽出した候補" : "検索結果") : "カテゴリを選ぶ"}
                </h3>
                <p className="mb-4 text-xs text-[#6b6b6b]">
                  {query
                    ? searchResult.isSentence
                      ? `${visibleOptions.length}件の候補を抽出しました。長い一致を優先して表示しています。`
                      : "一致する単語をタップして追加"
                    : "カードを押すと単語一覧が開きます"}
                </p>

                {query ? (
                  visibleOptions.length ? (
                    <div className="grid gap-2 sm:grid-cols-2">
                      {visibleOptions.map((option) => {
                        const activeOption = isSelected(option);
                        const adultOption = nsfwOptionIds.has(option.id);
                        return (
                          <div key={option.id} className={`keyword-slip group relative flex min-h-[72px] items-stretch ${activeOption ? adultOption ? "border-[#e85d75] bg-[#fff0f3]" : "is-selected" : ""}`}>
                            <button type="button" onClick={() => toggleOption(option)} className="flex min-w-0 flex-1 items-center justify-between gap-3 p-3 text-left">
                              <span className="min-w-0">
                                <span className="block truncate text-sm font-bold">{option.en}</span>
                                <span className="mt-1 block text-xs text-[#6b6b6b]">{option.ja}</span>
                              </span>
                              <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${activeOption ? adultOption ? "bg-[#e85d75] text-white" : "bg-[#111111] text-[#ffe59a]" : "bg-[#f0eee9] text-[#bbb]"}`}>{activeOption ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}</span>
                            </button>
                            <button type="button" onClick={() => toggleFavorite(option)} className={`keyword-favorite px-2 ${isFavorite(option) ? "text-[#e8a317]" : "text-[#c4c4c4]"}`}>
                              <Star className={`h-4 w-4 ${isFavorite(option) ? "fill-current" : ""}`} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-sm text-[#6b6b6b]">一致する単語が見つかりません。</p>
                  )
                ) : (
                  <div className="grid gap-2.5 sm:grid-cols-2">
                    {groupedCategories.map((category) => {
                      const count = selected.filter((option) => category.options.some((item) => item.id === option.id)).length;
                      const adultCategory = category.mode === "nsfw";
                      return (
                        <button type="button" key={category.id} onClick={() => openTagCategory(category.id)} className="pop-category-card flex min-h-[76px] items-center justify-between gap-3 px-4 py-4 text-left">
                          <span>
                            <span className="block text-sm font-bold">{category.label}</span>
                            <span className="mt-0.5 block text-[10px] text-[#8a8a8a]">{category.labelEn} · {category.options.length}</span>
                          </span>
                          {count > 0 && <span className={`flex h-7 min-w-7 items-center justify-center rounded-full px-2 text-[11px] font-bold text-white ${adultCategory ? "bg-[#e85d75]" : "bg-[#111111]"}`}>{count}</span>}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>

          <aside id="composer" className="soft-composer order-2 lg:sticky lg:top-20 lg:order-none">
            <div className="editorial-proof text-white">
              <div className="flex items-center justify-between px-5 py-4">
                <div className="flex items-center gap-2 text-[11px] font-bold text-[#ffe59a]"><Sparkles className="h-4 w-4" /> Composed</div>
                <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${contentMode === "nsfw" ? "bg-[#e85d75]" : "bg-white/10"}`}>{contentMode === "nsfw" ? "NSFW" : "SFW"} · {selected.length}</span>
              </div>
              <div className="px-5 pb-5">
                <h2 className="text-2xl font-bold leading-tight tracking-tight">選んだ単語を、<br />ひとつの指示に。</h2>
                <div className="composer-prompt-box mt-5 p-4">
                  <div className="mb-2 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-[#8a8a8a]">
                    <span>Positive prompt</span>
                    <Clipboard className="h-3.5 w-3.5" />
                  </div>
                  <p className={`composer-prompt-text text-[15px] leading-7 ${positivePromptText ? "text-white" : "text-[#6b6b6b]"}`}>{positivePromptText || "通常の単語を選んでください。"}</p>
                </div>
                <div className="composer-prompt-box composer-negative-box mt-3 p-4">
                  <div className="mb-2 flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-[#ffb5c3]">
                    <span>Negative prompt</span>
                    <Clipboard className="h-3.5 w-3.5" />
                  </div>
                  <p className={`composer-prompt-text text-[14px] leading-6 ${negativePromptText ? "text-[#ffdbe2]" : "text-[#6b6b6b]"}`}>{negativePromptText || "追加先を「ネガティブ」にして選んだ単語がここに入ります。"}</p>
                </div>
                <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.04] p-3.5">
                  <div className="mb-3 flex items-center justify-between">
                    <p className="text-xs font-bold text-white">選択済みタグ</p>
                    <span className="rounded-full bg-white/10 px-2 py-1 text-[10px] font-bold text-[#c7c7c7]">{selected.length}件</span>
                  </div>
                  <div>
                    <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[#ffe59a]">Positive · {positiveSelected.length}</p>
                    <div className="composer-annotations flex min-h-10 flex-wrap content-start gap-2 rounded-xl bg-black/15 p-2.5">
                      {positiveSelected.length ? positiveSelected.map((option) => (
                        <button type="button" key={option.id} onClick={() => removeOption(option.id)} className="inline-flex items-center gap-1.5 rounded-full px-3 py-2 text-xs">
                          {option.ja}<X className="h-3.5 w-3.5 opacity-60" />
                        </button>
                      )) : <span className="self-center text-xs text-[#6b6b6b]">まだ選択されていません</span>}
                    </div>
                  </div>
                  <div className="mt-3">
                    <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-[#ffb5c3]">Negative · {negativeSelected.length}</p>
                    <div className="composer-annotations flex min-h-10 flex-wrap content-start gap-2 rounded-xl bg-[#5a2530]/35 p-2.5">
                      {negativeSelected.length ? negativeSelected.map((option) => (
                        <button type="button" key={option.id} onClick={() => removeOption(option.id)} className="is-negative inline-flex items-center gap-1.5 rounded-full px-3 py-2 text-xs">
                          {option.ja}<X className="h-3.5 w-3.5 opacity-60" />
                        </button>
                      )) : <span className="self-center text-xs text-[#8c6a71]">まだ選択されていません</span>}
                    </div>
                  </div>
                </div>
                <div className="mt-6 grid gap-2">
                  <button type="button" disabled={!positivePromptText} onClick={() => copyPrompt("positive")} className="composer-copy-button flex w-full items-center justify-center gap-2 py-3.5 text-sm font-bold">
                    {copied === "positive" ? <><Check className="h-4 w-4" /> コピーしました</> : <><Copy className="h-4 w-4" /> ポジティブをコピー</>}
                  </button>
                  <button type="button" disabled={!negativePromptText} onClick={() => copyPrompt("negative")} className="composer-copy-button composer-negative-copy flex w-full items-center justify-center gap-2 py-3 text-sm font-bold">
                    {copied === "negative" ? <><Check className="h-4 w-4" /> コピーしました</> : <><Copy className="h-4 w-4" /> ネガティブをコピー</>}
                  </button>
                  <button type="button" disabled={!positivePromptText && !negativePromptText} onClick={() => copyPrompt("both")} className="composer-copy-both flex w-full items-center justify-center gap-2 rounded-full py-2.5 text-xs font-bold">
                    {copied === "both" ? <><Check className="h-3.5 w-3.5" /> 両方コピーしました</> : <><Copy className="h-3.5 w-3.5" /> 見出し付きで両方コピー</>}
                  </button>
                </div>
                <button type="button" onClick={clearAll} className="mt-3 flex w-full items-center justify-center gap-1.5 py-2 text-xs font-bold text-[#8a8a8a]">
                  <RotateCcw className="h-3.5 w-3.5" /> リセット
                </button>
              </div>
            </div>

            <section className="my-library mt-4">
              <button type="button" onClick={() => setIsLibraryOpen(true)} className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left">
                <span className="flex items-center gap-2.5">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#fff4d1]"><Bookmark className="h-4 w-4 text-[#111111]" /></span>
                  <span>
                    <span className="block text-sm font-bold">マイライブラリ</span>
                    <span className="block text-[11px] text-[#8a8a8a]">お気に入り・自作・履歴</span>
                  </span>
                </span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#111111] text-[#ffe59a]"><Plus className="h-4 w-4" /></span>
              </button>
            </section>
          </aside>
        </section>
      </main>

      <footer className="app-footer">
        <span>ことばパレット © 2026</span>
      </footer>

      <Dialog open={showHelpDialog} onOpenChange={setShowHelpDialog}>
        <DialogContent className="pop-overlay-dialog max-h-[85dvh] max-w-[calc(100%-1.5rem)] overflow-y-auto p-5 sm:max-w-lg sm:p-7">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl font-bold">
              <CircleHelp className="h-6 w-6 text-[#5b91bd]" />
              ことばパレットの使い方
            </DialogTitle>
            <DialogDescription>レシピを使う方法と、単語だけで自由に組み立てる方法があります。</DialogDescription>
          </DialogHeader>
          <div className="mt-3 space-y-3">
            <div className="rounded-2xl bg-[#fff8df] p-4">
              <div className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#ffe59a] text-xs font-bold">1</span>
                <div>
                  <p className="text-sm font-bold">レシピは使っても、使わなくてもOK</p>
                  <p className="mt-1 text-xs leading-5 text-[#6b6b6b]">すぐ画風を整えたいときは「レシピ」からひとつ選びます。レシピを使わない場合は、人物・品質・スタイル・背景などのカテゴリから必要な単語だけを選んでください。レシピは必須ではありません。</p>
                </div>
              </div>
            </div>
            <div className="rounded-2xl bg-[#edf7ff] p-4">
              <div className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#a5d3ff] text-xs font-bold">2</span>
                <div>
                  <p className="text-sm font-bold">カテゴリを開いて単語を選ぶ</p>
                  <p className="mt-1 text-xs leading-5 text-[#6b6b6b]">人物、衣装、ポーズ、背景、品質などを開き、使いたい単語をタップします。もう一度タップすると解除できます。検索欄には単語だけでなく「雨の夜に立つ男性」のような文章も入力できます。</p>
                </div>
              </div>
            </div>
            <div className="rounded-2xl bg-[#edf8f3] p-4">
              <div className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#b7e1d1] text-xs font-bold">3</span>
                <div>
                  <p className="text-sm font-bold">ポジティブとネガティブを使い分ける</p>
                  <p className="mt-1 text-xs leading-5 text-[#6b6b6b]">出したい要素は「ポジティブ」、出したくない要素は「ネガティブ」に切り替えてから選びます。最後にそれぞれを個別、またはまとめてコピーできます。</p>
                </div>
              </div>
            </div>
            <div className="rounded-2xl bg-[#f4efff] p-4">
              <div className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#d8c8ff] text-xs font-bold">4</span>
                <div>
                  <p className="text-sm font-bold">自作タグを追加する</p>
                  <p className="mt-1 text-xs leading-5 text-[#6b6b6b]">「マイライブラリ」を開き、「自作」タブの「自作タグを追加」を押します。画像生成に使う英語タグと、分かりやすい日本語の意味を入力して保存してください。保存したタグは自作タグカテゴリやマイライブラリから選べます。</p>
                </div>
              </div>
            </div>
            <div className="rounded-2xl bg-[#f3f3f1] p-4">
              <div className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white text-xs font-bold shadow-sm">5</span>
                <div>
                  <p className="text-sm font-bold">お気に入り・履歴・ランダムを使う</p>
                  <p className="mt-1 text-xs leading-5 text-[#6b6b6b]">星を押したタグはお気に入りに保存されます。コピーした組み合わせは履歴から復元でき、大切な履歴には星を付けられます。「きれいにランダム」は品質や画風を含む組み合わせを自動で作ります。</p>
                </div>
              </div>
            </div>
            <div className="rounded-2xl border border-[#f3c4ce] bg-[#fff4f6] p-4 text-xs leading-5 text-[#7a3040]">
              例：男性を描きたい場合は「男性」をポジティブへ、「女性」をネガティブへ追加できます。ネガティブ選択中だけ「除外候補」カテゴリが表示されます。
            </div>
          </div>
          <DialogFooter className="mt-4">
            <button type="button" onClick={() => setShowHelpDialog(false)} className="w-full rounded-full bg-[#111111] px-4 py-3.5 text-sm font-bold text-white">わかりました</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isTagPanelOpen} onOpenChange={setIsTagPanelOpen}>
        <DialogContent className="pop-overlay-dialog max-h-[85dvh] max-w-[calc(100%-1.5rem)] overflow-y-auto overflow-x-hidden p-5 sm:max-w-2xl sm:p-7">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold tracking-tight">{active?.label ?? "単語を選ぶ"}</DialogTitle>
            <DialogDescription>{active?.hint ?? "タップして追加・解除"} · {active?.labelEn}</DialogDescription>
          </DialogHeader>
          <div className="mt-2 flex items-center justify-between gap-2">
            <span className="text-[11px] font-bold text-[#8a8a8a]">{optionsForMode(active?.options ?? []).length} words</span>
            <button type="button" onClick={clearCategory} className="inline-flex items-center gap-1.5 text-xs font-bold text-[#6b6b6b]"><RotateCcw className="h-3.5 w-3.5" /> このカテゴリを解除</button>
          </div>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {optionsForMode(active?.options ?? []).map((option) => {
              const activeOption = isSelected(option);
              const adultOption = nsfwOptionIds.has(option.id);
              return (
                <div key={option.id} className={`keyword-slip flex min-h-[68px] items-stretch ${activeOption ? adultOption ? "border-[#e85d75] bg-[#fff0f3]" : "is-selected" : ""}`}>
                  <button type="button" onClick={() => toggleOption(option)} className="flex min-w-0 flex-1 items-center justify-between gap-3 p-3 text-left">
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-bold">{option.en}</span>
                      <span className="mt-1 block text-xs text-[#6b6b6b]">{option.ja}</span>
                    </span>
                    <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${activeOption ? adultOption ? "bg-[#e85d75] text-white" : "bg-[#111111] text-[#ffe59a]" : "bg-[#f0eee9] text-[#bbb]"}`}>{activeOption ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}</span>
                  </button>
                  <button type="button" onClick={() => toggleFavorite(option)} className={`keyword-favorite px-2 ${isFavorite(option) ? "text-[#e8a317]" : "text-[#c4c4c4]"}`}>
                    <Star className={`h-4 w-4 ${isFavorite(option) ? "fill-current" : ""}`} />
                  </button>
                </div>
              );
            })}
          </div>
          <DialogFooter className="mt-5">
            <button type="button" onClick={() => setIsTagPanelOpen(false)} className="w-full rounded-full bg-[#111111] px-4 py-3.5 text-sm font-bold text-white sm:w-auto">閉じる</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isLibraryOpen} onOpenChange={setIsLibraryOpen}>
        <DialogContent className="pop-overlay-dialog max-h-[85dvh] max-w-[calc(100%-1.5rem)] overflow-y-auto overflow-x-hidden p-5 sm:max-w-xl sm:p-7">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl font-bold"><Bookmark className="h-5 w-5" /> マイライブラリ</DialogTitle>
            <DialogDescription>お気に入り・自作タグ・コピー履歴</DialogDescription>
          </DialogHeader>
          <div className="mt-4 grid grid-cols-3 gap-1.5 rounded-2xl bg-[#f0eee9] p-1.5">
            {(["favorites", "history", "custom"] as const).map((tab) => (
              <button type="button" key={tab} onClick={() => setLibraryTab(tab)} className={`rounded-xl px-2 py-2.5 text-xs font-bold ${libraryTab === tab ? "bg-white text-[#111111] shadow-sm" : "text-[#6b6b6b]"}`}>
                {tab === "favorites" ? `タグ ${favoriteOptions.length}` : tab === "history" ? `履歴 ${history.length}` : `自作 ${customTags.length}`}
              </button>
            ))}
          </div>
          {libraryTab === "favorites" && (
            <div className="mt-4 max-w-full space-y-2 overflow-x-hidden">
              {favoriteOptions.length ? favoriteOptions.map((option) => (
                <div key={option.id} className="flex max-w-full items-center gap-2 overflow-hidden rounded-2xl border border-[#eceae4] px-3 py-2.5">
                  <button type="button" onClick={() => toggleOption(option)} className="min-w-0 flex-1 overflow-hidden text-left">
                    <span className="block truncate text-sm font-bold">{option.en}</span>
                    <span className="block truncate text-xs text-[#6b6b6b]">{option.ja}</span>
                  </button>
                  <button type="button" onClick={() => toggleFavorite(option)} className="shrink-0 text-[#e8a317]"><Star className="h-4 w-4 fill-current" /></button>
                </div>
              )) : <p className="text-sm text-[#6b6b6b]">お気に入りはまだありません。</p>}
            </div>
          )}
          {libraryTab === "history" && (
            <div className="mt-4 max-w-full space-y-2 overflow-x-hidden">
              <div className="grid grid-cols-2 gap-1 rounded-2xl bg-[#f0eee9] p-1">
                <button type="button" onClick={() => setHistoryView("all")} className={`rounded-xl px-3 py-2 text-xs font-bold ${historyView === "all" ? "bg-white shadow-sm" : "text-[#6b6b6b]"}`}>すべて {history.length}</button>
                <button type="button" onClick={() => setHistoryView("favorites")} className={`flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold ${historyView === "favorites" ? "bg-white text-[#b37a00] shadow-sm" : "text-[#6b6b6b]"}`}><Star className={`h-3.5 w-3.5 ${historyView === "favorites" ? "fill-current" : ""}`} />お気に入り {favoriteHistory.length}</button>
              </div>
              {visibleHistory.length ? visibleHistory.map((item) => {
                const expanded = expandedHistoryIds.includes(item.id);
                return (
                  <div key={item.id} className={`history-entry rounded-2xl border ${expanded ? "is-expanded" : ""} ${item.favorite ? "is-favorite" : ""}`}>
                    <div className="history-entry-row">
                      <button
                        type="button"
                        onClick={() => setExpandedHistoryIds((ids) => expanded ? ids.filter((id) => id !== item.id) : [...ids, item.id])}
                        className="history-toggle"
                        aria-expanded={expanded}
                        aria-label={expanded ? "履歴を折りたたむ" : "履歴を展開する"}
                      >
                        <span className={`history-prompt ${expanded ? "is-expanded" : ""}`}>{item.prompt || item.negativePrompt || "選択済みプロンプト"}</span>
                        <span className="history-toggle-meta">
                          <span>{item.createdAt}</span>
                          <ChevronDown className={`h-4 w-4 shrink-0 transition-transform ${expanded ? "rotate-180" : ""}`} />
                        </span>
                      </button>
                      <button type="button" onClick={() => toggleHistoryFavorite(item.id)} className={`history-favorite ${item.favorite ? "is-active" : ""}`} aria-label={item.favorite ? "履歴のお気に入りを解除" : "履歴をお気に入りに追加"}>
                        <Star className={`h-4 w-4 ${item.favorite ? "fill-current" : ""}`} />
                      </button>
                      <button type="button" onClick={() => setHistory((current) => current.filter((h) => h.id !== item.id))} className="history-delete" aria-label="履歴を削除">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    {expanded && (
                      <div className="history-actions">
                        {item.negativePrompt && <p className="mb-2 break-words text-[11px] leading-5 text-[#a34359]"><strong>Negative:</strong> {item.negativePrompt}</p>}
                        <button type="button" onClick={() => { restoreHistory(item); setIsLibraryOpen(false); }} className="history-restore">
                          この履歴を復元
                        </button>
                      </div>
                    )}
                  </div>
                );
              }) : <p className="py-3 text-sm text-[#6b6b6b]">{historyView === "favorites" ? "お気に入りの履歴はまだありません。" : "履歴はまだありません。"}</p>}
            </div>
          )}
          {libraryTab === "custom" && (
            <div className="mt-4 max-w-full overflow-x-hidden">
              <button type="button" onClick={() => { setIsLibraryOpen(false); setIsCustomTagDialogOpen(true); }} className="flex w-full items-center justify-center gap-2 rounded-full bg-[#111111] px-3 py-3.5 text-sm font-bold text-white">
                <PlusCircle className="h-4 w-4 text-[#ffe59a]" /> 自作タグを追加
              </button>
              <div className="mt-3 space-y-2">
                {customTags.length ? customTags.map((option) => (
                  <div key={option.id} className="flex max-w-full items-center gap-2 overflow-hidden rounded-2xl border border-[#eceae4] px-3 py-2.5">
                    <button type="button" onClick={() => toggleOption(option)} className="min-w-0 flex-1 overflow-hidden text-left">
                      <span className="block truncate text-sm font-bold">{option.en}</span>
                      <span className="block truncate text-xs text-[#6b6b6b]">{option.ja}</span>
                    </button>
                    <button type="button" onClick={() => removeCustomTag(option.id)} className="shrink-0 text-[#8a8a8a]"><Trash2 className="h-4 w-4" /></button>
                  </div>
                )) : <p className="text-sm text-[#6b6b6b]">自作タグはまだありません。</p>}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isCustomTagDialogOpen} onOpenChange={setIsCustomTagDialogOpen}>
        <DialogContent className="max-w-[calc(100%-1.5rem)] rounded-3xl border-0 bg-white p-5 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">自作タグを保存</DialogTitle>
            <DialogDescription>英語タグと日本語の意味を入れてください。</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <input value={customTagEn} onChange={(e) => setCustomTagEn(e.target.value)} placeholder="例: cozy room" className="w-full rounded-full border border-[#e8e6e1] bg-[#fafaf8] px-4 py-3 text-sm outline-none focus:border-[#a5d3ff]" />
            <input value={customTagJa} onChange={(e) => setCustomTagJa(e.target.value)} placeholder="例: 居心地のよい部屋" className="w-full rounded-full border border-[#e8e6e1] bg-[#fafaf8] px-4 py-3 text-sm outline-none focus:border-[#a5d3ff]" />
          </div>
          <DialogFooter className="gap-2">
            <button type="button" onClick={() => setIsCustomTagDialogOpen(false)} className="rounded-full border border-[#e8e6e1] px-4 py-2.5 text-sm font-bold">キャンセル</button>
            <button type="button" disabled={!customTagEn.trim()} onClick={addCustomTag} className="rounded-full bg-[#111111] px-4 py-2.5 text-sm font-bold text-white disabled:opacity-40">保存</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {showNsfwDialog && (
        <div role="dialog" aria-modal="true" className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-[11px] font-bold text-[#e85d75]"><AlertTriangle className="h-4 w-4" /> Adult content</div>
                <h2 className="mt-2 text-2xl font-bold">NSFWの単語を表示しますか？</h2>
              </div>
              <button type="button" onClick={() => setShowNsfwDialog(false)} aria-label="閉じる" className="rounded-full bg-[#f0eee9] p-2"><X className="h-4 w-4" /></button>
            </div>
            <p className="mt-4 text-sm leading-6 text-[#6b6b6b]">このモードは、成人（18歳以上）の架空人物だけを対象にした成人向けキーワードを表示します。</p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button type="button" onClick={() => setShowNsfwDialog(false)} className="rounded-full border border-[#e8e6e1] px-4 py-3 text-sm font-bold">戻る</button>
              <button type="button" onClick={enableNsfw} className="flex items-center justify-center gap-2 rounded-full bg-[#e85d75] px-4 py-3 text-sm font-bold text-white"><ShieldCheck className="h-4 w-4" /> 18歳以上</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
