import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, Home, Search } from "lucide-react";
import { useLocation } from "wouter";

export default function NotFound() {
  const [, setLocation] = useLocation();

  const handleGoHome = () => {
    setLocation("/");
  };

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-[#faf9f6] to-[#f0f4ec]">
      <Card className="mx-4 w-full max-w-lg border-0 bg-white/80 shadow-lg backdrop-blur-sm">
        <CardContent className="pb-8 pt-8 text-center">
          <div className="mb-6 flex justify-center">
            <div className="relative">
              <div className="absolute inset-0 animate-pulse rounded-full bg-[#ffe59a]/60" />
              <AlertCircle className="relative h-16 w-16 text-[#d3a84b]" />
            </div>
          </div>

          <h1 className="mb-2 text-4xl font-bold text-[#243126]">404</h1>

          <h2 className="mb-4 text-xl font-semibold text-[#4a5548]">
            ページが見つかりません
          </h2>

          <p className="mb-8 leading-relaxed text-[#5f655e]">
            お探しのページは移動または削除された可能性があります。
            <br />
            URL を今一度ご確認ください。
          </p>

          <div className="flex flex-col justify-center gap-3 sm:flex-row">
            <Button
              onClick={handleGoHome}
              className="rounded-lg bg-[#789462] px-6 py-2.5 text-white shadow-md transition-all duration-200 hover:bg-[#68854f] hover:shadow-lg"
            >
              <Home className="mr-2 h-4 w-4" />
              ホームに戻る
            </Button>
            <Button
              variant="outline"
              onClick={handleGoHome}
              className="rounded-lg border-[#789462]/40 bg-transparent px-6 py-2.5 text-[#4a5548] transition-all duration-200 hover:bg-[#edf3e9]"
            >
              <Search className="mr-2 h-4 w-4" />
              単語帳を使う
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
