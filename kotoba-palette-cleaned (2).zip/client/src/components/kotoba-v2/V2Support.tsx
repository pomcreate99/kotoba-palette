import { useState } from "react";
import { CircleHelp, X } from "lucide-react";

export function V2Support() {
  const [helpOpen, setHelpOpen] = useState(false);

  return (
    <>
      <section className="kp-v2-support" aria-label="サポート">
        <div className="kp-v2-support-actions">
          <button type="button" className="kp-v2-help-trigger" onClick={() => setHelpOpen(true)}><CircleHelp />使い方</button>
        </div>
        <footer className="kp-v2-footer">
          <span>ことばパレット © 2026</span>
        </footer>
      </section>

      {helpOpen && <div className="kp-v2-modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="kp-help-title">
        <div className="kp-v2-modal kp-v2-help-modal">
          <button className="kp-v2-modal-close" type="button" onClick={() => setHelpOpen(false)} aria-label="閉じる"><X /></button>
          <CircleHelp className="kp-v2-modal-icon" />
          <p className="kp-v2-eyebrow">HOW TO USE</p>
          <h2 id="kp-help-title">ことばパレットの使い方</h2>
          <div className="kp-v2-help-list">
            <article><strong>1. ホーム</strong><p>生成したい内容を日本語・英語で検索し、サジェストからタグを追加できます。ランダムガチャもここから使えます。</p></article>
            <article><strong>2. 単語帳</strong><p>大カテゴリと小カテゴリを切り替えてタグを探します。日本語訳と英語タグをセットで確認できます。</p></article>
            <article><strong>3. レシピ</strong><p>画風レシピを選ぶか、現在の選択内容を自作プリセットとして保存して再利用できます。</p></article>
            <article><strong>4. マイライブラリ</strong><p>お気に入りタグ、生成履歴、お気に入り履歴、自作タグを管理できます。</p></article>
            <article><strong>5. プロンプト</strong><p>ポジティブ・ネガティブを個別またはまとめてコピーできます。選択内容はタブを移動しても維持されます。</p></article>
          </div>
          <button type="button" className="kp-v2-help-close" onClick={() => setHelpOpen(false)}>閉じる</button>
        </div>
      </div>}
    </>
  );
}
