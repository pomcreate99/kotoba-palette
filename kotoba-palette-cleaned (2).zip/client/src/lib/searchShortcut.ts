type ShortcutEvent = {
  key: string;
  ctrlKey?: boolean;
  metaKey?: boolean;
  target?: unknown;
};

type TypingTarget = { tagName?: string; isContentEditable?: boolean };

/**
 * 検索ボックスへフォーカスを移すショートカット判定。
 * "/" または Ctrl+K（Cmd+K）で発火する。入力欄・テキストエリアでの通常入力は妨害しない。
 * DOM に依存しない純粋関数なので、node 環境の vitest でもテストできる。
 */
export function shouldOpenSearch(event: ShortcutEvent): boolean {
  const target = event.target as TypingTarget | null | undefined;
  const isTyping =
    !!target &&
    (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable === true);
  if (isTyping) return false;
  if (event.key === "/") return true;
  return event.key.toLowerCase() === "k" && (event.ctrlKey === true || event.metaKey === true);
}
