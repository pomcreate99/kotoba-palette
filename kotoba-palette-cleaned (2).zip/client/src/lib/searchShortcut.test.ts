import { describe, expect, it } from "vitest";
import { shouldOpenSearch } from "./searchShortcut";

type FakeTarget = { tagName?: string; isContentEditable?: boolean };

const makeEvent = (overrides: {
  key?: string;
  ctrlKey?: boolean;
  metaKey?: boolean;
  target?: FakeTarget;
} = {}) => ({
  key: "",
  ctrlKey: false,
  metaKey: false,
  target: { tagName: "BODY" } as FakeTarget,
  ...overrides,
});

describe("shouldOpenSearch", () => {
  it("「/」で発火する", () => {
    expect(shouldOpenSearch(makeEvent({ key: "/" }))).toBe(true);
  });

  it("Ctrl+K で発火する", () => {
    expect(shouldOpenSearch(makeEvent({ key: "k", ctrlKey: true }))).toBe(true);
  });

  it("Cmd+K で発火する", () => {
    expect(shouldOpenSearch(makeEvent({ key: "k", metaKey: true }))).toBe(true);
  });

  it("K キー単独では発火しない", () => {
    expect(shouldOpenSearch(makeEvent({ key: "k" }))).toBe(false);
    expect(shouldOpenSearch(makeEvent({ key: "a" }))).toBe(false);
  });

  it("入力欄・テキストエリア内では発火しない", () => {
    expect(shouldOpenSearch(makeEvent({ key: "/", target: { tagName: "INPUT" } }))).toBe(false);
    expect(shouldOpenSearch(makeEvent({ key: "/", target: { tagName: "TEXTAREA" } }))).toBe(false);
    expect(
      shouldOpenSearch(makeEvent({ key: "k", ctrlKey: true, target: { tagName: "TEXTAREA" } })),
    ).toBe(false);
    expect(
      shouldOpenSearch(makeEvent({ key: "/", target: { tagName: "DIV", isContentEditable: true } })),
    ).toBe(false);
  });

  it("スラッシュ以外の記号では発火しない", () => {
    expect(shouldOpenSearch(makeEvent({ key: "Enter" }))).toBe(false);
    expect(shouldOpenSearch(makeEvent({ key: "?" }))).toBe(false);
  });

  it("target が不明な場合も「/」で発火する", () => {
    expect(shouldOpenSearch({ key: "/", ctrlKey: false, metaKey: false, target: undefined })).toBe(true);
  });
});
