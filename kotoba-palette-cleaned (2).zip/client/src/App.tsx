import { Suspense, lazy } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Router as WouterRouter, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { KotobaV2Workspace } from "./components/kotoba-v2/KotobaV2Workspace";
import { V2Support } from "./components/kotoba-v2/V2Support";
import { ThemeProvider } from "./contexts/ThemeContext";
const Home = lazy(() => import("./pages/Home"));
import "./kotoba-v2.css";
import "./kotoba-v2-library.css";
import "./kotoba-v2-controls.css";
import "./kotoba-v2-dictionary.css";
import "./kotoba-v2-support.css";
import "./kotoba-v2-final-palette.css";
import "./kotoba-v2-recipes.css";
import "./kotoba-v2-ux.css";

// Vite sets BASE_URL from `base` in vite.config (e.g. "/prompt-atlas/" on GitHub Pages)
const base = (import.meta.env.BASE_URL || "/").replace(/\/$/, "") || "";

function KotobaV2Page() {
  return <><KotobaV2Workspace /><V2Support /></>;
}

function Routes() {
  // CI artifact previews are served from a deep GitLab URL, so render v2 directly
  // when the dedicated preview build flag is present.
  if (import.meta.env.VITE_PREVIEW_V2 === "1") return <KotobaV2Page />;

  return (
    <Suspense fallback={<div className="min-h-screen bg-[#fcfaf3]" />}>
      <Switch>
        <Route path="/" component={KotobaV2Page} />
        <Route path="/v2" component={KotobaV2Page} />
        <Route path="/legacy" component={Home} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <WouterRouter base={base}>
            <Routes />
          </WouterRouter>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
