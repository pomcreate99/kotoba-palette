import path from "node:path";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const PROJECT_ROOT = import.meta.dirname;

/**
 * Standalone Vite configuration.
 * This file uses only standard Vite, React and Tailwind packages and can run
 * outside Manus. Set VITE_PUBLIC_BASE=/ when publishing at a custom-domain root.
 */
export default defineConfig({
  base:
    process.env.VITE_PUBLIC_BASE ||
    (process.env.GITHUB_ACTIONS === "true" && process.env.GITHUB_REPOSITORY
      ? `/${process.env.GITHUB_REPOSITORY.split("/")[1]}/`
      : "/"),
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(PROJECT_ROOT, "client", "src"),
      "@shared": path.resolve(PROJECT_ROOT, "shared"),
      "@assets": path.resolve(PROJECT_ROOT, "attached_assets"),
    },
  },
  envDir: PROJECT_ROOT,
  root: path.resolve(PROJECT_ROOT, "client"),
  publicDir: path.resolve(PROJECT_ROOT, "client", "public"),
  build: {
    outDir: path.resolve(PROJECT_ROOT, "dist/public"),
    emptyOutDir: true,
    rollupOptions: {
      output: {
        // アイコンライブラリとReact系を別チャンクへ分離し、初回読み込みを軽くする
        manualChunks: {
          react: ["react", "react-dom"],
          "lucide-icons": ["lucide-react"],
        },
      },
    },
  },
  server: { host: true },
});
